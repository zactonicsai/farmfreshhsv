# =============================================================================
#  main.tf  -  the front door and the storage, installed with Helm
#
#  These are steps 8 and 9 of create-aks.sh. They use the very same Helm
#  files as the script (the helm/ folder next to terraform/), so there is
#  one place to change a setting, whichever way you build.
# =============================================================================

locals {
  base = "${var.name}-${var.env}"

  # The same naming rule as ../1-cluster/locals.tf. Keep the two in step.
  resource_group_name = "rg-${local.base}"
  cluster_name        = "aks-${local.base}"
  public_ip_name      = "pip-${local.base}-ingress"

  # Where the kit's Helm files are, seen from this folder.
  helm_dir = "${path.module}/../../helm"

  # Where the official Istio charts live (they moved here in 2026).
  istio_chart_repo = "https://blob.istio.io/istio-release/charts"

  # Does the real cluster spread its nodes over zones?
  cluster_zones = flatten([
    for pool in data.azurerm_kubernetes_cluster.this.agent_pool_profile :
    pool.zones == null ? [] : pool.zones
  ])

  # Disks: with zones we want copies in three buildings (ZRS), so a disk can
  # follow its app to another zone. Without zones, three copies in one
  # building (LRS). Your own choice (disk_sku) wins.
  disk_sku = var.disk_sku != null ? var.disk_sku : (length(local.cluster_zones) > 0 ? "Premium_ZRS" : "Premium_LRS")

  # A "fingerprint" of our own chart: one short code worked out from every
  # file in helm/platform. Change any file, even by one letter, and the code
  # changes. Step 9 uses it so Terraform can tell that the chart was edited.
  # (Hidden files that computers add by themselves, like .DS_Store on a Mac,
  # are skipped, so they never cause a pointless update.)
  platform_chart_dir = "${local.helm_dir}/platform"
  platform_chart_fingerprint = substr(sha256(join("\n", [
    for f in sort(fileset(local.platform_chart_dir, "**")) :
    "${f} ${filesha256("${local.platform_chart_dir}/${f}")}"
    if !startswith(basename(f), ".")
  ])), 0, 12)
}

# ---- Look up what stage 1 built ---------------------------------------------
# "data" blocks only read. If stage 1 has not been applied yet, these stop
# with "not found", and nothing is changed.
data "azurerm_kubernetes_cluster" "this" {
  name                = local.cluster_name
  resource_group_name = local.resource_group_name
}

data "azurerm_public_ip" "ingress" {
  name                = local.public_ip_name
  resource_group_name = local.resource_group_name
}

# ---- Step 8, part 1: the rule book ------------------------------------------
# Teaches Kubernetes the new words Istio uses, like "Gateway".
resource "helm_release" "istio_base" {
  name             = "istio-base"
  repository       = local.istio_chart_repo
  chart            = "base"
  version          = var.istio_version
  namespace        = "istio-system"
  create_namespace = true
  timeout          = 300 # seconds
}

# ---- Step 8, part 2: the brain (istiod) -------------------------------------
# It hands out the traffic rules.
resource "helm_release" "istiod" {
  name       = "istiod"
  repository = local.istio_chart_repo
  chart      = "istiod"
  version    = var.istio_version
  namespace  = "istio-system"
  timeout    = 600

  values = [
    file("${local.helm_dir}/istio/istiod-values.yaml"),
  ]

  depends_on = [helm_release.istio_base]
}

# ---- Step 8, part 3: the front door itself ----------------------------------
# The name "istio-ingressgateway" becomes the label "istio: ingressgateway".
# Other files look for that label, so keep the name.
resource "helm_release" "gateway" {
  name             = "istio-ingressgateway"
  repository       = local.istio_chart_repo
  chart            = "gateway"
  version          = var.istio_version
  namespace        = "istio-ingress"
  create_namespace = true
  timeout          = 600 # also waits for Azure to attach the public address

  values = [
    file("${local.helm_dir}/istio/gateway-values.yaml"),

    # Two notes for Azure: "use the reserved public IP with this name, kept
    # in this resource group". These are Azure's official labels for the job.
    yamlencode({
      service = {
        annotations = {
          "service.beta.kubernetes.io/azure-load-balancer-resource-group" = local.resource_group_name
          "service.beta.kubernetes.io/azure-pip-name"                     = local.public_ip_name
        }
      }
    }),
  ]

  depends_on = [helm_release.istiod]
}

# ---- Step 9: rooms and storage for future apps ------------------------------
# Our own small chart: a Gateway sign for the door, namespaces (rooms) and
# volume claims (locker reservations).
resource "helm_release" "platform" {
  name             = "platform"
  chart            = local.platform_chart_dir
  namespace        = "platform"
  create_namespace = true

  # Do NOT wait here. The volume claims stay "Pending" until an app uses
  # them, so waiting would never finish. That is normal, and it costs nothing.
  wait = false

  # On its own, Terraform only looks at the settings in this block. It does
  # not open the chart's files, so an edit to helm/platform would be missed.
  # Writing the chart's fingerprint here fixes that: edit any file in the
  # chart, the fingerprint changes, and the next "terraform apply" updates
  # the cluster. You can see this note later with "helm history platform".
  description = "chart files ${local.platform_chart_fingerprint}"

  values = [
    # The one setting worked out for you: the right kind of disk.
    # Everything else comes from helm/platform/values.yaml.
    yamlencode({
      storageClass = {
        skuName = local.disk_sku
      }
    }),
  ]

  depends_on = [helm_release.gateway]
}
