# =============================================================================
#  versions.tf  -  which tools this blueprint needs
#
#  Stage 2 installs things INSIDE the cluster that stage 1 built.
#  Checked on 2026-11-13 with Terraform 1.17, azurerm 5.13 and helm 3.3.
# =============================================================================

terraform {
  required_version = ">= 1.9.0"

  required_providers {
    # azurerm is only used here to LOOK UP the cluster and the public address.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 5.13"
    }
    # helm installs charts (recipes) into the cluster, like the helm command does.
    helm = {
      source  = "hashicorp/helm"
      version = "~> 3.3"
    }
  }

  # Where Terraform keeps its notebook. See ../1-cluster/versions.tf and
  # terraform/README.md. Use a different "key" for each stage.
  # backend "azurerm" {
  #   resource_group_name  = "rg-tfstate"
  #   storage_account_name = "CHANGE-ME"
  #   container_name       = "tfstate"
  #   key                  = "aks-platform/2-platform.tfstate"
  #   use_azuread_auth     = true
  # }
}
