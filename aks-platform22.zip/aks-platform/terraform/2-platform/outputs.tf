# =============================================================================
#  outputs.tf  -  what Terraform tells you when it is done
# =============================================================================

output "front_door_ip" {
  description = "The public address of the gateway. Point your website name at it."
  value       = data.azurerm_public_ip.ingress.ip_address
}

output "istio_version" {
  description = "The Istio version that is installed."
  value       = var.istio_version
}

output "disk_sku" {
  description = "The disk type the storage class uses."
  value       = local.disk_sku
}

output "have_a_look" {
  description = "Commands to look around. Run the kubectl_login commands from stage 1 first."
  value       = <<-EOT
    kubectl --context ${local.cluster_name} get pods -n istio-system
    kubectl --context ${local.cluster_name} get service -n istio-ingress
    kubectl --context ${local.cluster_name} get storageclass,pvc -A
  EOT
}

output "good_to_know" {
  description = "Two things that are normal."
  value       = "The volume claims show Pending until an app uses them. The gateway speaks plain HTTP until you add a certificate (see the main README)."
}
