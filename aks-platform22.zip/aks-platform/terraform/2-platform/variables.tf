# =============================================================================
#  variables.tf  -  the choices for stage 2
#
#  name and env must be the SAME as in stage 1. That is how this stage finds
#  the cluster.
# =============================================================================

variable "name" {
  description = "The project name you gave stage 1, like shop."
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{1,18}[a-z0-9]$", var.name)) && length(regexall("--", var.name)) == 0
    error_message = "name must be 3-20 characters: small letters, numbers and single dashes. It must start with a letter and may not end with a dash."
  }
}

variable "env" {
  description = "The label you gave stage 1, like dev or prod."
  type        = string
  default     = "dev"

  validation {
    condition     = can(regex("^[a-z0-9]{2,10}$", var.env))
    error_message = "env must be 2-10 small letters or numbers, like dev or prod."
  }
}

variable "subscription_id" {
  description = "Azure subscription ID. Empty means the one az is using now."
  type        = string
  default     = null
}

variable "istio_version" {
  description = "Istio version, all three numbers. Checked on 2026-11-13: 1.31.4 supports Kubernetes 1.32 to 1.37."
  type        = string
  default     = "1.31.4"

  validation {
    condition     = can(regex("^[0-9]+\\.[0-9]+\\.[0-9]+$", var.istio_version))
    error_message = "istio_version needs all three numbers, like 1.31.4."
  }
}

variable "disk_sku" {
  description = "Disk type for the storage class. Empty means Premium_ZRS when the cluster uses zones, Premium_LRS when it does not."
  type        = string
  default     = null

  validation {
    condition     = var.disk_sku == null ? true : contains(["Premium_LRS", "Premium_ZRS", "StandardSSD_LRS", "StandardSSD_ZRS"], var.disk_sku)
    error_message = "disk_sku must be Premium_LRS, Premium_ZRS, StandardSSD_LRS or StandardSSD_ZRS."
  }
}
