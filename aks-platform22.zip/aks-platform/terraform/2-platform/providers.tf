# =============================================================================
#  providers.tf  -  how Terraform logs in to Azure and to the cluster
# =============================================================================

provider "azurerm" {
  subscription_id = var.subscription_id
  features {}
}

# The Helm provider talks to the cluster itself. It needs three things:
#   host                    where the cluster's control desk is
#   cluster_ca_certificate  proof that it is talking to the real cluster
#   a login                 a short-lived pass, fetched fresh each time
#
# For the login it runs "kubelogin", which reuses your "az login". The long
# number is not a secret: it is Azure's fixed ID for "the AKS login service",
# the same for every cluster in the world.
provider "helm" {
  kubernetes = {
    host                   = data.azurerm_kubernetes_cluster.this.kube_config[0].host
    cluster_ca_certificate = base64decode(data.azurerm_kubernetes_cluster.this.kube_config[0].cluster_ca_certificate)

    exec = {
      api_version = "client.authentication.k8s.io/v1beta1"
      command     = "kubelogin"
      args = [
        "get-token",
        "--login", "azurecli",
        "--server-id", "6dae42f8-4368-4678-94ff-3960e28e3630",
      ]
    }
  }
}
