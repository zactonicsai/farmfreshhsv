# =============================================================================
#  blueprint.tftest.hcl  -  check stage 2 WITHOUT a cluster
#
#  Run it from the 2-platform folder:
#
#      terraform init
#      terraform test
#
#  "mock_provider" swaps Azure and Helm for pretend ones. Nothing is
#  installed. Terraform still works out the plan, and each "assert" checks
#  one fact about it.
# =============================================================================

mock_provider "azurerm" {
  # A pretend answer to "which cluster did stage 1 build?".
  mock_data "azurerm_kubernetes_cluster" {
    defaults = {
      kube_config = [{
        host                   = "https://aks-shop-dev-pretend.hcp.eastus2.azmk8s.io:443"
        cluster_ca_certificate = "cHJldGVuZCBjZXJ0aWZpY2F0ZQ==" # the words "pretend certificate"
        username               = "clusterUser_rg-shop-dev_aks-shop-dev"
        password               = ""
        client_certificate     = ""
        client_key             = ""
      }]
      # A cluster with no zones, like the "small" size.
      agent_pool_profile = [
        { name = "system", zones = [] },
        { name = "apps", zones = [] },
      ]
    }
  }

  # A pretend public address (203.0.113.x is set aside for examples).
  mock_data "azurerm_public_ip" {
    defaults = {
      ip_address = "203.0.113.10"
    }
  }
}

mock_provider "helm" {}

variables {
  name = "shop"
}

# ---- 1. Stage 2 looks for the names stage 1 used ----------------------------
run "finds_what_stage_1_built" {
  command = plan

  assert {
    condition     = data.azurerm_kubernetes_cluster.this.name == "aks-shop-dev" && data.azurerm_kubernetes_cluster.this.resource_group_name == "rg-shop-dev"
    error_message = "Stage 2 should look for cluster aks-<name>-<env> in rg-<name>-<env>."
  }
  assert {
    condition     = data.azurerm_public_ip.ingress.name == "pip-shop-dev-ingress" && data.azurerm_public_ip.ingress.resource_group_name == "rg-shop-dev"
    error_message = "Stage 2 should look for the address pip-<name>-<env>-ingress."
  }
  assert {
    condition     = output.front_door_ip == "203.0.113.10"
    error_message = "The output should show the public address."
  }
}

# ---- 2. Istio: three charts, one pinned version, the right rooms ------------
run "istio_is_three_charts_at_one_version" {
  command = plan

  assert {
    condition = alltrue([
      helm_release.istio_base.chart == "base",
      helm_release.istiod.chart == "istiod",
      helm_release.gateway.chart == "gateway",
    ])
    error_message = "Istio should be installed from the base, istiod and gateway charts."
  }
  assert {
    condition = alltrue([
      for r in [helm_release.istio_base, helm_release.istiod, helm_release.gateway] :
      r.repository == "https://blob.istio.io/istio-release/charts" && r.version == "1.31.4"
    ])
    error_message = "All three Istio charts should come from the official place, at the same pinned version."
  }
  assert {
    condition     = helm_release.istio_base.namespace == "istio-system" && helm_release.istiod.namespace == "istio-system"
    error_message = "The rule book and the brain belong in istio-system."
  }
  assert {
    condition     = helm_release.gateway.namespace == "istio-ingress" && helm_release.gateway.create_namespace == true
    error_message = "The front door belongs in its own room, istio-ingress."
  }
  assert {
    condition     = helm_release.gateway.name == "istio-ingressgateway"
    error_message = "Keep this name: it becomes the label istio=ingressgateway that other files look for."
  }
  assert {
    condition     = helm_release.istiod.values[0] == file("${path.module}/../../helm/istio/istiod-values.yaml")
    error_message = "The kit's istiod settings file should be handed to Helm, unchanged."
  }
  assert {
    condition     = helm_release.gateway.values[0] == file("${path.module}/../../helm/istio/gateway-values.yaml")
    error_message = "The kit's gateway settings file should be handed to Helm, unchanged."
  }
  assert {
    condition     = can(yamldecode(helm_release.istiod.values[0])) && can(yamldecode(helm_release.gateway.values[0]))
    error_message = "Both Istio settings files should be proper YAML."
  }
  assert {
    condition     = length(helm_release.istio_base.values == null ? [] : helm_release.istio_base.values) == 0
    error_message = "The rule book chart needs no settings of ours."
  }
}

# ---- 3. The front door gets the address reserved in stage 1 -----------------
run "front_door_uses_the_reserved_address" {
  command = plan

  assert {
    condition     = yamldecode(helm_release.gateway.values[1]).service.annotations["service.beta.kubernetes.io/azure-pip-name"] == "pip-shop-dev-ingress"
    error_message = "The gateway should ask Azure for our reserved address, by name."
  }
  assert {
    condition     = yamldecode(helm_release.gateway.values[1]).service.annotations["service.beta.kubernetes.io/azure-load-balancer-resource-group"] == "rg-shop-dev"
    error_message = "The gateway should tell Azure which resource group holds the address."
  }
  assert {
    condition     = yamldecode(helm_release.gateway.values[0]).service.type == "LoadBalancer"
    error_message = "The gateway must be a LoadBalancer, or it gets no public address at all."
  }
}

# ---- 4. Our own chart: no waiting, and edits are noticed --------------------
run "platform_chart_is_set_up_right" {
  command = plan

  assert {
    condition     = helm_release.platform.wait == false
    error_message = "Do not wait on the platform chart: its volume claims stay Pending on purpose."
  }
  assert {
    condition     = endswith(helm_release.platform.chart, "helm/platform")
    error_message = "The platform chart should be the kit's own helm/platform folder."
  }
  assert {
    condition     = can(regex("^chart files [0-9a-f]{12}$", helm_release.platform.description))
    error_message = "The chart's fingerprint should be written down, so edits to the chart are noticed."
  }
  assert {
    condition     = fileexists("${helm_release.platform.chart}/Chart.yaml") && fileexists("${helm_release.platform.chart}/values.yaml")
    error_message = "The chart folder should really be there."
  }
}

# ---- 5. Disks: one building, or three ---------------------------------------
run "no_zones_means_lrs_disks" {
  command = plan

  assert {
    condition     = yamldecode(helm_release.platform.values[0]).storageClass.skuName == "Premium_LRS"
    error_message = "A cluster without zones should get Premium_LRS disks."
  }
  assert {
    condition     = output.disk_sku == "Premium_LRS"
    error_message = "The output should show the disk type."
  }
}

run "zones_mean_zrs_disks" {
  command = plan

  # This time the pretend cluster spreads its nodes over three zones.
  override_data {
    target = data.azurerm_kubernetes_cluster.this
    values = {
      kube_config = [{
        host                   = "https://aks-shop-dev-pretend.hcp.eastus2.azmk8s.io:443"
        cluster_ca_certificate = "cHJldGVuZCBjZXJ0aWZpY2F0ZQ=="
        username               = "clusterUser_rg-shop-dev_aks-shop-dev"
        password               = ""
        client_certificate     = ""
        client_key             = ""
      }]
      agent_pool_profile = [
        { name = "system", zones = ["1", "2", "3"] },
        { name = "apps", zones = ["1", "2", "3"] },
      ]
    }
  }

  assert {
    condition     = yamldecode(helm_release.platform.values[0]).storageClass.skuName == "Premium_ZRS"
    error_message = "A cluster with zones should get Premium_ZRS disks, so a disk can follow its app."
  }
}

run "your_disk_choice_wins" {
  command = plan

  variables {
    disk_sku = "StandardSSD_LRS"
  }

  assert {
    condition     = yamldecode(helm_release.platform.values[0]).storageClass.skuName == "StandardSSD_LRS"
    error_message = "disk_sku should win over the automatic choice."
  }
}

# ---- 6. Your own choices ----------------------------------------------------
run "another_env_and_istio_version" {
  command = plan

  variables {
    env           = "prod"
    istio_version = "1.32.0"
  }

  assert {
    condition     = data.azurerm_kubernetes_cluster.this.name == "aks-shop-prod" && data.azurerm_kubernetes_cluster.this.resource_group_name == "rg-shop-prod"
    error_message = "The env should be part of the names stage 2 looks for."
  }
  assert {
    condition     = yamldecode(helm_release.gateway.values[1]).service.annotations["service.beta.kubernetes.io/azure-pip-name"] == "pip-shop-prod-ingress"
    error_message = "The gateway should ask for the prod address."
  }
  assert {
    condition     = helm_release.istio_base.version == "1.32.0" && helm_release.istiod.version == "1.32.0" && helm_release.gateway.version == "1.32.0"
    error_message = "istio_version should move all three charts together."
  }
  assert {
    condition     = strcontains(output.have_a_look, "kubectl --context aks-shop-prod get pods -n istio-system")
    error_message = "The output should show commands for the right cluster."
  }
}

# ---- 7. Wrong answers are refused early -------------------------------------
run "istio_version_needs_three_numbers" {
  command = plan
  variables {
    istio_version = "1.31"
  }
  expect_failures = [var.istio_version]
}

run "unknown_disk_type_is_refused" {
  command = plan
  variables {
    disk_sku = "UltraSSD_LRS"
  }
  expect_failures = [var.disk_sku]
}

run "name_with_capitals_is_refused" {
  command = plan
  variables {
    name = "Shop"
  }
  expect_failures = [var.name]
}

run "env_with_a_dash_is_refused" {
  command = plan
  variables {
    env = "dev-1"
  }
  expect_failures = [var.env]
}
