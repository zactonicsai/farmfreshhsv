# =============================================================================
#  locals.tf  -  things Terraform works out from your choices
#
#  "locals" are like scratch notes: values we work out once and then use in
#  many places. Nothing here creates anything in Azure.
#
#  IMPORTANT: the names below follow the same rule as create-aks.sh and as
#  ../2-platform. If you change the rule here, change it there too.
# =============================================================================

locals {
  base = "${var.name}-${var.env}"

  # ---- names: a short prefix says what kind of thing it is -----------------
  resource_group_name      = "rg-${local.base}"          # rg   = resource group (the folder)
  node_resource_group_name = "rg-${local.base}-nodes"    # the folder AKS manages by itself
  cluster_name             = "aks-${local.base}"         # aks  = the cluster
  vnet_name                = "vnet-${local.base}"        # vnet = virtual network
  subnet_name              = "snet-aks-nodes"            # snet = subnet (one slice of the network)
  identity_name            = "id-${local.base}-aks"      # id   = managed identity (the ID badge)
  public_ip_name           = "pip-${local.base}-ingress" # pip  = public IP

  # ---- the address plan -----------------------------------------------------
  # The whole network: 65,536 addresses that all start with your two numbers.
  vnet_cidr = "${var.ip_base}.0.0/16"
  # The slice for the node computers: 4,096 addresses (x.x.0.0 to x.x.15.255).
  # Everything from x.x.16.0 upward stays free for things you add later.
  node_subnet_cidr = "${var.ip_base}.0.0/20"

  # Pods and services get addresses that exist ONLY inside the cluster.
  # They must not overlap your network, so we step aside if you picked the same.
  pod_cidr     = var.ip_base == "10.244" ? "10.245.0.0/16" : "10.244.0.0/16"
  service_cidr = var.ip_base == "10.0" ? "10.1.0.0/16" : "10.0.0.0/16"
  # The cluster's own phone book (DNS) lives at address number 10 of the service range.
  dns_service_ip = cidrhost(local.service_cidr, 10)

  # ---- size presets ---------------------------------------------------------
  # small = for learning: cheap, but one broken part can stop it.
  # ha    = "high availability": keeps working when one part breaks.
  presets = {
    small = {
      tier             = "free"
      system_nodes     = 1
      system_node_size = "Standard_D2ds_v5"
      user_nodes_min   = 1
      user_nodes_max   = 3
    }
    ha = {
      tier             = "standard"
      system_nodes     = 3
      system_node_size = "Standard_D4ds_v5"
      user_nodes_min   = 3
      user_nodes_max   = 6
    }
  }

  # No preset chosen? Real-user environments get the strong one.
  profile = var.profile != null ? var.profile : (contains(["prod", "prd", "production"], var.env) ? "ha" : "small")
  preset  = local.presets[local.profile]

  # Your own choice wins. Otherwise the preset decides.
  tier             = lower(coalesce(var.tier, local.preset.tier))
  system_nodes     = coalesce(var.system_nodes, local.preset.system_nodes)
  system_node_size = coalesce(var.system_node_size, local.preset.system_node_size)
  user_nodes_min   = coalesce(var.user_nodes_min, local.preset.user_nodes_min)
  user_nodes_max   = coalesce(var.user_nodes_max, local.preset.user_nodes_max)

  preset_zones = local.profile == "ha" ? ["1", "2", "3"] : []
  zones        = var.zones != null ? var.zones : local.preset_zones
  # Azure wants "no zones" written as nothing at all, not as an empty list.
  zones_or_null = length(local.zones) > 0 ? local.zones : null

  # The public address is different from the nodes. Azure offers two kinds:
  # tied to ONE zone, or spread over ALL of them. When the cluster uses
  # zones, we always take "all", so the address outlives any one data center.
  public_ip_zones = length(local.zones) > 0 ? ["1", "2", "3"] : null

  # ---- the disk each node starts up from ------------------------------------
  # "Ephemeral" keeps the operating system on the disk that is built into the
  # node: faster, and no extra bill. It must fit on that built-in disk. The
  # smallest default VM size has room for 75 GB, so 60 is a safe size.
  # "Managed" is a separate Azure disk; we let Azure pick its size.
  os_disk_type    = title(lower(var.os_disk_type)) # "ephemeral" becomes "Ephemeral"
  os_disk_size_gb = var.os_disk_size_gb != null ? var.os_disk_size_gb : (local.os_disk_type == "Ephemeral" ? 60 : null)

  # ---- labels stuck on everything, so the bill can be sorted ----------------
  # "created-by = terraform" also tells destroy-aks.sh to keep its hands off:
  # what Terraform builds, only Terraform should take down.
  tags = merge(
    {
      project      = var.name
      env          = var.env
      "created-by" = "terraform"
    },
    var.tags,
  )
}
