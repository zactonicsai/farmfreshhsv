# =============================================================================
#  wiring.tftest.hcl  -  check that the parts are plugged into each other
#
#  The other test files only PLAN. This one also does a pretend "apply", so
#  every part gets an ID, just like in real Azure. The real Azure provider
#  code then checks each ID where it is used. If the cluster were handed,
#  say, the network's ID where it wants the subnet's ID, this test fails.
#
#  It is still pretend: nothing is built and nothing costs money.
#
#  Run from the 1-cluster folder:   terraform init && terraform test
# =============================================================================

mock_provider "azurerm" {
  mock_data "azurerm_client_config" {
    defaults = {
      tenant_id       = "11111111-1111-1111-1111-111111111111"
      object_id       = "22222222-2222-2222-2222-222222222222"
      client_id       = "33333333-3333-3333-3333-333333333333"
      subscription_id = "44444444-4444-4444-4444-444444444444"
    }
  }

  # Made-up IDs in the same shape real Azure uses.
  mock_resource "azurerm_resource_group" {
    defaults = {
      id = "/subscriptions/44444444-4444-4444-4444-444444444444/resourceGroups/rg-shop-dev"
    }
  }
  mock_resource "azurerm_virtual_network" {
    defaults = {
      id = "/subscriptions/44444444-4444-4444-4444-444444444444/resourceGroups/rg-shop-dev/providers/Microsoft.Network/virtualNetworks/vnet-shop-dev"
    }
  }
  mock_resource "azurerm_subnet" {
    defaults = {
      id = "/subscriptions/44444444-4444-4444-4444-444444444444/resourceGroups/rg-shop-dev/providers/Microsoft.Network/virtualNetworks/vnet-shop-dev/subnets/snet-aks-nodes"
    }
  }
  mock_resource "azurerm_user_assigned_identity" {
    defaults = {
      id           = "/subscriptions/44444444-4444-4444-4444-444444444444/resourceGroups/rg-shop-dev/providers/Microsoft.ManagedIdentity/userAssignedIdentities/id-shop-dev-aks"
      principal_id = "66666666-6666-6666-6666-666666666666"
      client_id    = "77777777-7777-7777-7777-777777777777"
      tenant_id    = "11111111-1111-1111-1111-111111111111"
    }
  }
  mock_resource "azurerm_public_ip" {
    defaults = {
      id         = "/subscriptions/44444444-4444-4444-4444-444444444444/resourceGroups/rg-shop-dev/providers/Microsoft.Network/publicIPAddresses/pip-shop-dev-ingress"
      ip_address = "203.0.113.10"
    }
  }
  mock_resource "azurerm_kubernetes_cluster" {
    defaults = {
      id              = "/subscriptions/44444444-4444-4444-4444-444444444444/resourceGroups/rg-shop-dev/providers/Microsoft.ContainerService/managedClusters/aks-shop-dev"
      oidc_issuer_url = "https://eastus2.oic.prod-aks.azure.com/11111111-1111-1111-1111-111111111111/88888888-8888-8888-8888-888888888888/"
    }
  }
}

# The blueprint waits one minute at one point. In a test nobody wants to
# wait, so the clock is pretend too.
mock_provider "time" {}

variables {
  name    = "shop"
  ip_base = "10.40"
}

run "every_part_is_plugged_into_the_right_part" {
  command = apply

  assert {
    condition     = azurerm_subnet.nodes.virtual_network_name == azurerm_virtual_network.this.name
    error_message = "The subnet should sit inside our network."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].vnet_subnet_id == azurerm_subnet.nodes.id
    error_message = "System nodes should plug into our subnet."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.vnet_subnet_id == azurerm_subnet.nodes.id
    error_message = "App nodes should plug into our subnet."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.kubernetes_cluster_id == azurerm_kubernetes_cluster.this.id
    error_message = "The app pool should belong to our cluster."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.identity[0].identity_ids == toset([azurerm_user_assigned_identity.aks.id])
    error_message = "The cluster should wear the ID badge we made."
  }
  assert {
    condition     = azurerm_role_assignment.aks_network.scope == azurerm_resource_group.this.id && azurerm_role_assignment.aks_network.principal_id == "66666666-6666-6666-6666-666666666666"
    error_message = "The badge should get its network permission on our resource group."
  }
  assert {
    condition     = azurerm_role_assignment.cluster_admin.scope == azurerm_kubernetes_cluster.this.id
    error_message = "The admin key should be for our cluster only."
  }
  assert {
    condition     = output.front_door_ip == "203.0.113.10"
    error_message = "The output should show the public address."
  }
  assert {
    condition     = strcontains(output.kubectl_login, "az aks get-credentials --resource-group rg-shop-dev --name aks-shop-dev")
    error_message = "The output should show how to log in."
  }
  assert {
    condition     = strcontains(output.next_step, "-var name=shop -var env=dev")
    error_message = "The output should hand the right name and env to stage 2."
  }
}

# The same pretend build at the big size, with every optional choice filled in.
run "the_ha_size_also_plugs_together" {
  command = apply

  variables {
    env             = "prod"
    admin_group_id  = "55555555-5555-5555-5555-555555555555"
    api_allowed_ips = ["203.0.113.7/32"]
  }

  assert {
    condition     = azurerm_kubernetes_cluster.this.name == "aks-shop-prod" && azurerm_kubernetes_cluster.this.sku_tier == "Standard"
    error_message = "The ha build should plan the Standard tier."
  }
  assert {
    condition     = azurerm_role_assignment.cluster_admin.principal_type == "Group"
    error_message = "A named admin group should get the key as a Group."
  }
}
