# =============================================================================
#  blueprint.tftest.hcl  -  check the plan WITHOUT touching Azure
#
#  Run it from the 1-cluster folder:
#
#      terraform init
#      terraform test
#
#  How it works: "mock_provider" swaps Azure for a pretend one. Nothing is
#  built and nothing costs money. Terraform still works out the whole plan,
#  and each "assert" below checks one fact about it.
# =============================================================================

mock_provider "azurerm" {
  # The pretend Azure needs a pretend "who am I". These are made-up IDs.
  mock_data "azurerm_client_config" {
    defaults = {
      tenant_id       = "11111111-1111-1111-1111-111111111111"
      object_id       = "22222222-2222-2222-2222-222222222222"
      client_id       = "33333333-3333-3333-3333-333333333333"
      subscription_id = "44444444-4444-4444-4444-444444444444"
    }
  }
}

# The blueprint waits one minute at one point. In a test nobody wants to
# wait, so the clock is pretend too.
mock_provider "time" {}

# Used by every test unless the test says otherwise.
variables {
  name    = "shop"
  ip_base = "10.40"
}

# ---- 1. Names: the same naming rule as create-aks.sh ------------------------
run "names_follow_the_rule" {
  command = plan

  assert {
    condition     = azurerm_resource_group.this.name == "rg-shop-dev"
    error_message = "The resource group should be rg-<name>-<env>."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.name == "aks-shop-dev"
    error_message = "The cluster should be aks-<name>-<env>."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.node_resource_group == "rg-shop-dev-nodes"
    error_message = "The node resource group should be rg-<name>-<env>-nodes."
  }
  assert {
    condition     = azurerm_virtual_network.this.name == "vnet-shop-dev"
    error_message = "The network should be vnet-<name>-<env>."
  }
  assert {
    condition     = azurerm_subnet.nodes.name == "snet-aks-nodes"
    error_message = "The subnet should be snet-aks-nodes."
  }
  assert {
    condition     = azurerm_user_assigned_identity.aks.name == "id-shop-dev-aks"
    error_message = "The ID badge should be id-<name>-<env>-aks."
  }
  assert {
    condition     = azurerm_public_ip.ingress.name == "pip-shop-dev-ingress"
    error_message = "The public address should be pip-<name>-<env>-ingress."
  }
  assert {
    condition     = azurerm_resource_group.this.location == "eastus2"
    error_message = "The default region should be eastus2."
  }
}

# ---- 2. Addresses: the plan worked out from ip_base -------------------------
run "address_plan_from_ip_base" {
  command = plan

  assert {
    condition     = tolist(azurerm_virtual_network.this.address_space) == tolist(["10.40.0.0/16"])
    error_message = "The network should be <ip_base>.0.0/16."
  }
  assert {
    condition     = azurerm_subnet.nodes.address_prefixes == tolist(["10.40.0.0/20"])
    error_message = "The node subnet should be <ip_base>.0.0/20."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.network_profile[0].pod_cidr == "10.244.0.0/16"
    error_message = "Pods should use 10.244.0.0/16."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.network_profile[0].service_cidr == "10.0.0.0/16"
    error_message = "Services should use 10.0.0.0/16."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.network_profile[0].dns_service_ip == "10.0.0.10"
    error_message = "The cluster's phone book (DNS) should sit at .10 of the service range."
  }
}

# ---- 3. The "small" size: what you get by default ---------------------------
run "small_is_the_default" {
  command = plan

  assert {
    condition     = azurerm_kubernetes_cluster.this.sku_tier == "Free"
    error_message = "small should use the Free tier."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].node_count == 1
    error_message = "small should have 1 system node."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].vm_size == "Standard_D2ds_v5"
    error_message = "small should use Standard_D2ds_v5 for the system node."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].zones == null
    error_message = "small should not use zones."
  }
  assert {
    condition     = azurerm_public_ip.ingress.zones == null
    error_message = "With no zones, the public address should not ask for zones either."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.min_count == 1 && azurerm_kubernetes_cluster_node_pool.apps.max_count == 3
    error_message = "small should grow the app pool between 1 and 3 nodes."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.vm_size == "Standard_D4ds_v5"
    error_message = "App nodes should default to Standard_D4ds_v5."
  }
  assert {
    condition = alltrue([
      azurerm_kubernetes_cluster.this.kubernetes_version == "1.36",
      azurerm_kubernetes_cluster.this.default_node_pool[0].orchestrator_version == "1.36",
      azurerm_kubernetes_cluster_node_pool.apps.orchestrator_version == "1.36",
    ])
    error_message = "The brain, the system nodes and the app nodes should all run the same Kubernetes."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].os_disk_type == "Ephemeral" && azurerm_kubernetes_cluster.this.default_node_pool[0].os_disk_size_gb == 60
    error_message = "System nodes should start from a 60 GB built-in (ephemeral) disk."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.os_disk_type == "Ephemeral" && azurerm_kubernetes_cluster_node_pool.apps.os_disk_size_gb == 60
    error_message = "App nodes should start from a 60 GB built-in (ephemeral) disk."
  }
}

# ---- 4. The "ha" size: picked for you when env is prod ----------------------
run "prod_gets_the_ha_size" {
  command = plan

  variables {
    env = "prod"
  }

  assert {
    condition     = azurerm_kubernetes_cluster.this.name == "aks-shop-prod"
    error_message = "The env should be part of the name."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.sku_tier == "Standard"
    error_message = "ha should use the Standard tier (it has an uptime promise)."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].node_count == 3
    error_message = "ha should have 3 system nodes."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].vm_size == "Standard_D4ds_v5"
    error_message = "ha should use Standard_D4ds_v5 for system nodes."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].zones == toset(["1", "2", "3"])
    error_message = "ha should spread system nodes over zones 1, 2 and 3."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.zones == toset(["1", "2", "3"])
    error_message = "ha should spread app nodes over zones 1, 2 and 3."
  }
  assert {
    condition     = azurerm_public_ip.ingress.zones == toset(["1", "2", "3"])
    error_message = "ha should keep the public address in all three zones."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.min_count == 3 && azurerm_kubernetes_cluster_node_pool.apps.max_count == 6
    error_message = "ha should grow the app pool between 3 and 6 nodes."
  }
}

# ---- 5. You can still ask for "small" in prod, or "ha" in dev ---------------
run "profile_beats_the_env_guess" {
  command = plan

  variables {
    env     = "prod"
    profile = "small"
  }

  assert {
    condition     = azurerm_kubernetes_cluster.this.sku_tier == "Free" && azurerm_kubernetes_cluster.this.default_node_pool[0].node_count == 1
    error_message = "profile = small should win over the prod guess."
  }
}

run "ha_can_be_asked_for_in_dev" {
  command = plan

  variables {
    profile = "ha"
  }

  assert {
    condition     = azurerm_kubernetes_cluster.this.sku_tier == "Standard" && azurerm_kubernetes_cluster.this.default_node_pool[0].node_count == 3
    error_message = "profile = ha should work in any env."
  }
}

# ---- 6. Address clashes: the inside ranges step aside -----------------------
run "services_step_aside_for_10_0" {
  command = plan

  variables {
    ip_base = "10.0"
  }

  assert {
    condition     = tolist(azurerm_virtual_network.this.address_space) == tolist(["10.0.0.0/16"])
    error_message = "The network should use the base you asked for."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.network_profile[0].service_cidr == "10.1.0.0/16"
    error_message = "Services must move to 10.1.0.0/16 when the network uses 10.0."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.network_profile[0].dns_service_ip == "10.1.0.10"
    error_message = "DNS must move with the service range."
  }
}

run "pods_step_aside_for_10_244" {
  command = plan

  variables {
    ip_base = "10.244"
  }

  assert {
    condition     = azurerm_kubernetes_cluster.this.network_profile[0].pod_cidr == "10.245.0.0/16"
    error_message = "Pods must move to 10.245.0.0/16 when the network uses 10.244."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.network_profile[0].service_cidr == "10.0.0.0/16"
    error_message = "Services can stay at 10.0.0.0/16 here."
  }
}

run "other_private_ranges_work" {
  command = plan

  variables {
    ip_base = "172.20"
  }

  assert {
    condition     = azurerm_subnet.nodes.address_prefixes == tolist(["172.20.0.0/20"])
    error_message = "172.16 to 172.29 should be allowed as a base."
  }
}

# ---- 7. Safety settings that must never quietly change ----------------------
run "safety_settings_are_on" {
  command = plan

  assert {
    condition     = azurerm_kubernetes_cluster.this.local_account_disabled == true
    error_message = "The built-in master key must be off."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.azure_active_directory_role_based_access_control[0].azure_rbac_enabled == true
    error_message = "Logins must use Entra ID with Azure roles."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.azure_active_directory_role_based_access_control[0].tenant_id == "11111111-1111-1111-1111-111111111111"
    error_message = "The cluster should trust the directory you are logged in to."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.oidc_issuer_enabled && azurerm_kubernetes_cluster.this.workload_identity_enabled
    error_message = "Workload identity (no stored passwords) must be on."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.automatic_upgrade_channel == "patch" && azurerm_kubernetes_cluster.this.node_os_upgrade_channel == "NodeImage"
    error_message = "Automatic patching must be on."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].only_critical_addons_enabled == true
    error_message = "The system nodes must be kept for Kubernetes' own helpers."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.identity[0].type == "UserAssigned"
    error_message = "The cluster must use its own ID badge."
  }
  assert {
    condition = alltrue([
      azurerm_kubernetes_cluster.this.network_profile[0].network_plugin == "azure",
      azurerm_kubernetes_cluster.this.network_profile[0].network_plugin_mode == "overlay",
      azurerm_kubernetes_cluster.this.network_profile[0].network_data_plane == "cilium",
      azurerm_kubernetes_cluster.this.network_profile[0].network_policy == "cilium",
    ])
    error_message = "Networking must be Azure CNI Overlay with Cilium."
  }
  assert {
    condition     = azurerm_subnet.nodes.default_outbound_access_enabled == false
    error_message = "The node subnet must be private: no hidden way out to the internet."
  }
  assert {
    condition     = azurerm_public_ip.ingress.sku == "Standard" && azurerm_public_ip.ingress.allocation_method == "Static"
    error_message = "The public address must be a Standard, Static one."
  }
  assert {
    condition     = azurerm_role_assignment.aks_network.role_definition_name == "Network Contributor"
    error_message = "The cluster's badge needs the Network Contributor role."
  }
  assert {
    condition     = length(azurerm_kubernetes_cluster.this.api_server_access_profile) == 0
    error_message = "With no allowed IPs given, there should be no access list."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.auto_scaling_enabled == true && azurerm_kubernetes_cluster_node_pool.apps.mode == "User"
    error_message = "The app pool must be a User pool that grows and shrinks."
  }
}

# ---- 8. Labels, and who gets the admin key ----------------------------------
run "labels_and_admin_key" {
  command = plan

  assert {
    condition     = azurerm_resource_group.this.tags == tomap({ project = "shop", env = "dev", "created-by" = "terraform" })
    error_message = "Every resource should carry the project, env and created-by labels."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.tags["created-by"] == "terraform"
    error_message = "The cluster should be labelled as built by Terraform."
  }
  assert {
    condition     = azurerm_role_assignment.cluster_admin.principal_id == "22222222-2222-2222-2222-222222222222"
    error_message = "With no admin group, the person running Terraform gets the admin key."
  }
  assert {
    condition     = azurerm_role_assignment.cluster_admin.role_definition_name == "Azure Kubernetes Service RBAC Cluster Admin"
    error_message = "The admin key should be the AKS RBAC Cluster Admin role."
  }
}

# ---- 9. Your own choices win over the size preset ---------------------------
run "your_choices_win" {
  command = plan

  variables {
    env                = "test"
    location           = "westeurope"
    node_size          = "Standard_D8ds_v5"
    system_node_size   = "Standard_D4ds_v5"
    system_nodes       = 2
    user_nodes_min     = 2
    user_nodes_max     = 9
    zones              = ["1", "2"]
    tier               = "Standard"
    kubernetes_version = "1.35"
    admin_group_id     = "55555555-5555-5555-5555-555555555555"
    api_allowed_ips    = ["203.0.113.7/32", "198.51.100.0/24"]
    tags               = { owner = "team-a", env = "sandbox" }
    os_disk_type       = "managed" # small letters are fine too
    os_disk_size_gb    = 128
  }

  assert {
    condition     = azurerm_resource_group.this.location == "westeurope"
    error_message = "location should be used."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.sku_tier == "Standard"
    error_message = "tier should win over the preset."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].node_count == 2 && azurerm_kubernetes_cluster.this.default_node_pool[0].vm_size == "Standard_D4ds_v5"
    error_message = "system_nodes and system_node_size should win over the preset."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.vm_size == "Standard_D8ds_v5"
    error_message = "node_size should be used for app nodes."
  }
  assert {
    condition     = azurerm_kubernetes_cluster_node_pool.apps.min_count == 2 && azurerm_kubernetes_cluster_node_pool.apps.max_count == 9
    error_message = "user_nodes_min and user_nodes_max should win over the preset."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].zones == toset(["1", "2"]) && azurerm_kubernetes_cluster_node_pool.apps.zones == toset(["1", "2"])
    error_message = "zones should be used for both kinds of nodes."
  }
  assert {
    condition     = azurerm_public_ip.ingress.zones == toset(["1", "2", "3"])
    error_message = "The public address is either in one zone or in all of them. With zones on, it should be in all three."
  }
  assert {
    condition = alltrue([
      azurerm_kubernetes_cluster.this.default_node_pool[0].os_disk_type == "Managed",
      azurerm_kubernetes_cluster.this.default_node_pool[0].os_disk_size_gb == 128,
      azurerm_kubernetes_cluster_node_pool.apps.os_disk_type == "Managed",
      azurerm_kubernetes_cluster_node_pool.apps.os_disk_size_gb == 128,
    ])
    error_message = "os_disk_type and os_disk_size_gb should be used for all nodes."
  }
  assert {
    condition     = azurerm_kubernetes_cluster.this.kubernetes_version == "1.35"
    error_message = "kubernetes_version should be used."
  }
  assert {
    condition     = azurerm_role_assignment.cluster_admin.principal_id == "55555555-5555-5555-5555-555555555555" && azurerm_role_assignment.cluster_admin.principal_type == "Group"
    error_message = "admin_group_id should get the admin key, as a Group."
  }
  assert {
    condition     = toset(azurerm_kubernetes_cluster.this.api_server_access_profile[0].authorized_ip_ranges) == toset(["203.0.113.7/32", "198.51.100.0/24"])
    error_message = "api_allowed_ips should become the cluster's access list."
  }
  assert {
    condition     = azurerm_resource_group.this.tags == tomap({ project = "shop", env = "sandbox", "created-by" = "terraform", owner = "team-a" })
    error_message = "Your own tags should be added, and win when the same label is used twice."
  }
}

# ---- 10. The summary printed at the end -------------------------------------
run "outputs_tell_you_what_was_planned" {
  command = plan

  assert {
    condition     = output.resource_group_name == "rg-shop-dev" && output.cluster_name == "aks-shop-dev"
    error_message = "The outputs should show the names."
  }
  assert {
    condition     = output.address_plan.whole_network == "10.40.0.0/16" && output.address_plan.nodes == "10.40.0.0/20"
    error_message = "The outputs should show the address plan."
  }
  assert {
    condition     = output.sizes.profile == "small" && output.sizes.node_os_disk == "Ephemeral, 60 GB"
    error_message = "The outputs should show which size and which node disk were picked."
  }
}

# ---- 11. Managed disks: Azure picks the size --------------------------------
run "managed_disks_let_azure_pick_the_size" {
  command = plan

  variables {
    os_disk_type = "Managed"
  }

  assert {
    condition     = azurerm_kubernetes_cluster.this.default_node_pool[0].os_disk_type == "Managed" && azurerm_kubernetes_cluster_node_pool.apps.os_disk_type == "Managed"
    error_message = "os_disk_type = Managed should be used for all nodes."
  }
  assert {
    condition     = output.sizes.node_os_disk == "Managed"
    error_message = "With Managed and no size given, we should not force a size on Azure."
  }
}
