# =============================================================================
#  bad_inputs.tftest.hcl  -  make sure mistakes are caught EARLY
#
#  Each test below hands Terraform one wrong answer on purpose.
#  "expect_failures" means: this test passes only if Terraform refuses.
#  A typo should stop the plan, not show up 10 minutes later in Azure.
#
#  Run from the 1-cluster folder:   terraform init && terraform test
# =============================================================================

mock_provider "azurerm" {
  mock_data "azurerm_client_config" {
    defaults = {
      tenant_id       = "11111111-1111-1111-1111-111111111111"
      object_id       = "22222222-2222-2222-2222-222222222222"
      client_id       = "33333333-3333-3333-3333-333333333333"
      subscription_id = "44444444-4444-4444-4444-444444444444"
    }
  }
}

# The blueprint waits one minute at one point. In a test nobody wants to
# wait, so the clock is pretend too.
mock_provider "time" {}

# Good answers. Each test swaps in ONE bad answer.
variables {
  name    = "shop"
  ip_base = "10.40"
}

# ---- ip_base: must be the first two numbers of a private range --------------
run "ip_base_public_range_is_refused" {
  command = plan
  variables {
    ip_base = "11.5"
  }
  expect_failures = [var.ip_base]
}

run "ip_base_number_too_big_is_refused" {
  command = plan
  variables {
    ip_base = "10.256"
  }
  expect_failures = [var.ip_base]
}

run "ip_base_three_numbers_is_refused" {
  command = plan
  variables {
    ip_base = "10.40.0"
  }
  expect_failures = [var.ip_base]
}

# AKS keeps 172.30 and 172.31 for itself, so we stop at 172.29.
run "ip_base_172_30_is_refused" {
  command = plan
  variables {
    ip_base = "172.30"
  }
  expect_failures = [var.ip_base]
}

run "ip_base_192_169_is_refused" {
  command = plan
  variables {
    ip_base = "192.169"
  }
  expect_failures = [var.ip_base]
}

# ---- name: small letters, numbers and dashes, 3 to 20 long ------------------
run "name_with_capitals_is_refused" {
  command = plan
  variables {
    name = "Shop"
  }
  expect_failures = [var.name]
}

run "name_too_short_is_refused" {
  command = plan
  variables {
    name = "ab"
  }
  expect_failures = [var.name]
}

run "name_too_long_is_refused" {
  command = plan
  variables {
    name = "abcdefghijklmnopqrstu" # 21 letters
  }
  expect_failures = [var.name]
}

run "name_starting_with_a_number_is_refused" {
  command = plan
  variables {
    name = "1shop"
  }
  expect_failures = [var.name]
}

run "name_ending_with_a_dash_is_refused" {
  command = plan
  variables {
    name = "shop-"
  }
  expect_failures = [var.name]
}

run "name_with_double_dash_is_refused" {
  command = plan
  variables {
    name = "my--shop"
  }
  expect_failures = [var.name]
}

# ---- the other choices -------------------------------------------------------
run "env_with_a_dash_is_refused" {
  command = plan
  variables {
    env = "dev-1"
  }
  expect_failures = [var.env]
}

run "location_with_spaces_is_refused" {
  command = plan
  variables {
    location = "East US 2"
  }
  expect_failures = [var.location]
}

run "unknown_profile_is_refused" {
  command = plan
  variables {
    profile = "medium"
  }
  expect_failures = [var.profile]
}

run "unknown_tier_is_refused" {
  command = plan
  variables {
    tier = "gold"
  }
  expect_failures = [var.tier]
}

run "zone_4_is_refused" {
  command = plan
  variables {
    zones = ["1", "4"]
  }
  expect_failures = [var.zones]
}

run "zero_system_nodes_is_refused" {
  command = plan
  variables {
    system_nodes = 0
  }
  expect_failures = [var.system_nodes]
}

run "half_a_node_is_refused" {
  command = plan
  variables {
    system_nodes = 1.5
  }
  expect_failures = [var.system_nodes]
}

run "zero_app_nodes_is_refused" {
  command = plan
  variables {
    user_nodes_min = 0
  }
  expect_failures = [var.user_nodes_min]
}

run "too_many_app_nodes_is_refused" {
  command = plan
  variables {
    user_nodes_max = 101
  }
  expect_failures = [var.user_nodes_max]
}

run "node_size_with_a_space_is_refused" {
  command = plan
  variables {
    node_size = "Standard D4ds v5"
  }
  expect_failures = [var.node_size]
}

run "unknown_os_disk_type_is_refused" {
  command = plan
  variables {
    os_disk_type = "floppy"
  }
  expect_failures = [var.os_disk_type]
}

run "tiny_os_disk_is_refused" {
  command = plan
  variables {
    os_disk_size_gb = 10
  }
  expect_failures = [var.os_disk_size_gb]
}

run "kubernetes_version_must_be_numbers" {
  command = plan
  variables {
    kubernetes_version = "latest"
  }
  expect_failures = [var.kubernetes_version]
}

run "admin_group_must_be_an_id" {
  command = plan
  variables {
    admin_group_id = "my-admin-group"
  }
  expect_failures = [var.admin_group_id]
}

run "allowed_ips_must_be_addresses" {
  command = plan
  variables {
    api_allowed_ips = ["the-office"]
  }
  expect_failures = [var.api_allowed_ips]
}

# ---- two answers that are each fine, but not together ------------------------
run "more_min_than_max_app_nodes_is_refused" {
  command = plan
  variables {
    user_nodes_min = 5
    user_nodes_max = 2
  }
  expect_failures = [azurerm_kubernetes_cluster_node_pool.apps]
}
