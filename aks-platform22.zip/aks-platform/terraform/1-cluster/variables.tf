# =============================================================================
#  variables.tf  -  the choices you can make
#
#  These are the same choices create-aks.sh offers. Only the first two are
#  required. Give them on the command line:
#      terraform apply -var name=shop -var ip_base=10.40
#  or copy terraform.tfvars.example to terraform.tfvars and fill it in.
#
#  Each "validation" block checks what you typed BEFORE anything is built,
#  so a typo costs you a second, not twenty minutes.
# =============================================================================

# ---- The two things you must choose -----------------------------------------

variable "name" {
  description = "Short name for your project, like shop. Every Azure name is built from it."
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{1,18}[a-z0-9]$", var.name)) && length(regexall("--", var.name)) == 0
    error_message = "name must be 3-20 characters: small letters, numbers and single dashes. It must start with a letter and may not end with a dash."
  }
}

variable "ip_base" {
  description = "The first two numbers of your private network. 10.40 gives the network 10.40.0.0/16."
  type        = string

  validation {
    # Private ranges only, so the network never clashes with the real internet.
    # 172.30 and 172.31 are left out because AKS uses them itself.
    condition     = can(regex("^(10\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])|172\\.(1[6-9]|2[0-9])|192\\.168)$", var.ip_base))
    error_message = "ip_base must be the first two numbers of a private network: 10.0 to 10.255, 172.16 to 172.29, or 192.168. Example: 10.40"
  }
}

# ---- Common choices ---------------------------------------------------------

variable "env" {
  description = "A label such as dev, test or prod. It becomes part of every name."
  type        = string
  default     = "dev"

  validation {
    condition     = can(regex("^[a-z0-9]{2,10}$", var.env))
    error_message = "env must be 2-10 small letters or numbers, like dev or prod."
  }
}

variable "location" {
  description = "The Azure region, written as one word, like eastus2 or westeurope."
  type        = string
  default     = "eastus2"

  validation {
    condition     = can(regex("^[a-z0-9]+$", var.location))
    error_message = "location must be an Azure region written as one word, like eastus2 or westeurope."
  }
}

variable "profile" {
  description = "Size preset: small (practice) or ha (real users). Empty means small, or ha when env is prod."
  type        = string
  default     = null

  validation {
    condition     = var.profile == null ? true : contains(["small", "ha"], var.profile)
    error_message = "profile must be small or ha."
  }
}

variable "subscription_id" {
  description = "Azure subscription ID to build in. Empty means the one az is using now."
  type        = string
  default     = null
}

# ---- Sizes (each one overrides the preset) ----------------------------------

variable "node_size" {
  description = "VM size for the app nodes."
  type        = string
  default     = "Standard_D4ds_v5"

  validation {
    condition     = can(regex("^[A-Za-z0-9_]+$", var.node_size))
    error_message = "VM sizes look like Standard_D4ds_v5 (letters, numbers and underscores only)."
  }
}

variable "system_node_size" {
  description = "VM size for the system nodes. Empty means the preset decides."
  type        = string
  default     = null

  validation {
    condition     = var.system_node_size == null ? true : can(regex("^[A-Za-z0-9_]+$", var.system_node_size))
    error_message = "VM sizes look like Standard_D4ds_v5 (letters, numbers and underscores only)."
  }
}

variable "system_nodes" {
  description = "How many system nodes. Empty means the preset decides."
  type        = number
  default     = null

  validation {
    condition     = var.system_nodes == null ? true : (var.system_nodes >= 1 && var.system_nodes <= 20 && floor(var.system_nodes) == var.system_nodes)
    error_message = "system_nodes must be a whole number between 1 and 20."
  }
}

variable "user_nodes_min" {
  description = "Fewest app nodes. Empty means the preset decides."
  type        = number
  default     = null

  validation {
    condition     = var.user_nodes_min == null ? true : (var.user_nodes_min >= 1 && floor(var.user_nodes_min) == var.user_nodes_min)
    error_message = "user_nodes_min must be a whole number, at least 1, or the front door has nowhere to run."
  }
}

variable "user_nodes_max" {
  description = "Most app nodes. The cluster grows by itself up to here. Empty means the preset decides."
  type        = number
  default     = null

  validation {
    condition     = var.user_nodes_max == null ? true : (var.user_nodes_max >= 1 && var.user_nodes_max <= 100 && floor(var.user_nodes_max) == var.user_nodes_max)
    error_message = "user_nodes_max must be a whole number between 1 and 100."
  }
}

variable "zones" {
  description = "Spread nodes over separate data centers, like [\"1\", \"2\", \"3\"]. Use [] for none. Empty (null) means the preset decides."
  type        = list(string)
  default     = null

  validation {
    condition     = var.zones == null ? true : alltrue([for z in var.zones : contains(["1", "2", "3"], z)])
    error_message = "zones must be a list made of \"1\", \"2\" and \"3\", like [\"1\", \"2\", \"3\"], or [] for none."
  }
}

variable "tier" {
  description = "free or standard. Standard adds an uptime promise, for a fee. Empty means the preset decides."
  type        = string
  default     = null

  validation {
    condition     = var.tier == null ? true : contains(["free", "standard"], lower(var.tier))
    error_message = "tier must be free or standard."
  }
}

variable "os_disk_type" {
  description = "Where each node keeps its operating system. Ephemeral = on the node's own built-in disk (faster, and free). Managed = on a separate Azure disk (works with every VM size, but costs extra)."
  type        = string
  default     = "Ephemeral"

  validation {
    condition     = contains(["ephemeral", "managed"], lower(var.os_disk_type))
    error_message = "os_disk_type must be Ephemeral or Managed."
  }
}

variable "os_disk_size_gb" {
  description = "Size of that disk in GB. Empty means the usual choice: 60 for Ephemeral (it fits the built-in disk of every default VM size), or Azure's own pick for Managed."
  type        = number
  default     = null

  validation {
    condition     = var.os_disk_size_gb == null ? true : (var.os_disk_size_gb >= 30 && var.os_disk_size_gb <= 2048 && floor(var.os_disk_size_gb) == var.os_disk_size_gb)
    error_message = "os_disk_size_gb must be a whole number between 30 and 2048."
  }
}

# ---- Versions ---------------------------------------------------------------

variable "kubernetes_version" {
  description = "Kubernetes version, like 1.36. Checked on 2026-11-13: AKS offers 1.35 to 1.37, and Istio 1.31 supports 1.32 to 1.37."
  type        = string
  default     = "1.36"

  validation {
    condition     = can(regex("^[0-9]+\\.[0-9]+(\\.[0-9]+)?$", var.kubernetes_version))
    error_message = "kubernetes_version looks like 1.36 or 1.36.2."
  }
}

# ---- Safety -----------------------------------------------------------------

variable "admin_group_id" {
  description = "Object ID of a Microsoft Entra group whose members become cluster admins. Empty means only you."
  type        = string
  default     = null

  validation {
    condition     = var.admin_group_id == null ? true : can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.admin_group_id))
    error_message = "admin_group_id must be a group's Object ID. Find it with: az ad group show --group \"Group Name\" --query id -o tsv"
  }
}

variable "api_allowed_ips" {
  description = "Only these address ranges may reach the cluster's control desk, like [\"203.0.113.7/32\"]. Empty list means anywhere (login is still required)."
  type        = list(string)
  default     = []

  validation {
    condition     = alltrue([for ip in var.api_allowed_ips : can(cidrhost(ip, 0))])
    error_message = "Each entry in api_allowed_ips must be a range such as 203.0.113.7/32 or 198.51.100.0/24."
  }
}

# ---- Other ------------------------------------------------------------------

variable "tags" {
  description = "Extra Azure labels for billing reports, like { owner = \"team-a\" }."
  type        = map(string)
  default     = {}
}
