# =============================================================================
#  outputs.tf  -  what Terraform tells you when it is done
#
#  See them again at any time with:  terraform output
# =============================================================================

output "resource_group_name" {
  description = "The folder that holds everything."
  value       = azurerm_resource_group.this.name
}

output "cluster_name" {
  description = "The name of the AKS cluster."
  value       = azurerm_kubernetes_cluster.this.name
}

output "front_door_ip" {
  description = "The public address that never changes. Point your website name at it."
  value       = azurerm_public_ip.ingress.ip_address
}

output "address_plan" {
  description = "Which address ranges are used for what."
  value = {
    whole_network = local.vnet_cidr
    nodes         = local.node_subnet_cidr
    pods          = "${local.pod_cidr} (inside the cluster only)"
    services      = "${local.service_cidr} (inside the cluster only)"
  }
}

output "sizes" {
  description = "The sizes that were chosen, after presets and your own choices."
  value = {
    profile      = local.profile
    tier         = local.tier
    zones        = local.zones
    system_nodes = "${local.system_nodes} x ${local.system_node_size}"
    app_nodes    = "${local.user_nodes_min} to ${local.user_nodes_max} x ${var.node_size}"
    node_os_disk = local.os_disk_size_gb == null ? local.os_disk_type : "${local.os_disk_type}, ${local.os_disk_size_gb} GB"
  }
}

output "oidc_issuer_url" {
  description = "Needed later, when an app wants to prove who it is to Azure (workload identity)."
  value       = azurerm_kubernetes_cluster.this.oidc_issuer_url
}

output "kubectl_login" {
  description = "Run these two commands to point kubectl at the new cluster."
  value       = <<-EOT
    az aks get-credentials --resource-group ${azurerm_resource_group.this.name} --name ${azurerm_kubernetes_cluster.this.name} --context ${azurerm_kubernetes_cluster.this.name} --overwrite-existing
    kubelogin convert-kubeconfig --login azurecli --context ${azurerm_kubernetes_cluster.this.name}
  EOT
}

output "next_step" {
  description = "What to do now."
  value       = "The cluster is up. Next, install the front door and storage:  cd ../2-platform && terraform init && terraform apply -var name=${var.name} -var env=${var.env}"
}
