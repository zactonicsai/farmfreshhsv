# =============================================================================
#  versions.tf  -  which tools this blueprint needs
#
#  Terraform reads the .tf files in this folder as one blueprint. This file
#  pins the versions, so the blueprint builds the same thing next month as it
#  does today. Checked on 2026-11-13 with Terraform 1.17, azurerm 5.13 and time 0.14.
# =============================================================================

terraform {
  # The Terraform program itself.
  required_version = ">= 1.9.0"

  required_providers {
    # A "provider" is a plug-in that knows how to talk to one service.
    # azurerm talks to Azure. "~> 5.13" means: 5.13 or newer, but never 6.0,
    # because a new first number may change how things are written.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 5.13"
    }

    # time does one small job here: it waits a minute at the right moment
    # (see the "settle" block in main.tf).
    time = {
      source  = "hashicorp/time"
      version = "~> 0.14"
    }
  }

  # ---------------------------------------------------------------------------
  # WHERE TERRAFORM KEEPS ITS NOTEBOOK (the "state")
  #
  # Terraform writes down everything it built in a state file. Without that
  # file it no longer knows what belongs to it. By default the file sits in
  # this folder (terraform.tfstate), which is fine for practice.
  #
  # For a team, or for anything real, keep it in Azure Storage instead, where
  # it is backed up and two people cannot change it at the same moment.
  # terraform/README.md shows how to make the storage. Then remove the "#"
  # marks below, fill in the name, and run: terraform init -migrate-state
  # ---------------------------------------------------------------------------
  # backend "azurerm" {
  #   resource_group_name  = "rg-tfstate"
  #   storage_account_name = "CHANGE-ME"          # must be unique in all of Azure
  #   container_name       = "tfstate"
  #   key                  = "aks-platform/1-cluster.tfstate"
  #   use_azuread_auth     = true                 # log in as you, no storage key needed
  # }
}
