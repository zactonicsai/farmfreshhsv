# =============================================================================
#  aks.tf  -  the cluster, the app nodes, and your key to get in
#
#  These are steps 5 to 7 of create-aks.sh.
# =============================================================================

# ---- Step 5: the AKS cluster ------------------------------------------------
# Azure runs the "brain" of Kubernetes for you. This is the slow part:
# about 5 to 10 minutes.
resource "azurerm_kubernetes_cluster" "this" {
  name                = local.cluster_name
  location            = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name
  dns_prefix          = local.cluster_name # the first part of the cluster's web address
  kubernetes_version  = var.kubernetes_version
  sku_tier            = title(local.tier) # "free" becomes "Free", the spelling Azure wants
  node_resource_group = local.node_resource_group_name

  # --- who the cluster is: the ID badge from step 3 ---
  identity {
    type         = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.aks.id]
  }

  # --- the first node pool: only for Kubernetes' own helpers ---
  default_node_pool {
    name           = "system"
    vm_size        = local.system_node_size
    node_count     = local.system_nodes
    vnet_subnet_id = azurerm_subnet.nodes.id
    zones          = local.zones_or_null

    # Same Kubernetes as the brain. When you raise kubernetes_version later,
    # the brain is upgraded first and these nodes follow.
    orchestrator_version = var.kubernetes_version

    # The disk each node starts up from (explained in locals.tf).
    os_disk_type    = local.os_disk_type
    os_disk_size_gb = local.os_disk_size_gb

    # A "staff only" sign: your apps cannot crowd out the helpers Kubernetes needs.
    only_critical_addons_enabled = true

    # If you later change the VM size, Azure needs a spare pool name to swap
    # the nodes over without rebuilding the whole cluster.
    temporary_name_for_rotation = "systemtmp"

    # During an upgrade, add 10% extra nodes first, so nothing runs short.
    upgrade_settings {
      max_surge = "10%"
    }
  }

  # We add node pools ourselves (step 6), so the mode is "Manual". In the
  # other mode, Azure invents node pools by itself. (The second line only
  # matters in that other mode. It is written out because the provider's own
  # examples always do.)
  node_provisioning_profile {
    mode               = "Manual"
    default_node_pools = "Auto"
  }

  # --- networking ---
  # Nodes sit in our subnet. Pods get cluster-only addresses ("overlay"), so
  # they do not use up the network. Cilium is the fast traffic engine, and it
  # also enforces rules about which pods may talk to each other.
  network_profile {
    network_plugin      = "azure"
    network_plugin_mode = "overlay"
    network_data_plane  = "cilium"
    network_policy      = "cilium"
    pod_cidr            = local.pod_cidr
    service_cidr        = local.service_cidr
    dns_service_ip      = local.dns_service_ip
  }

  # --- logins: people use their own Microsoft Entra account ---
  # You can see who did what, and remove one person without changing a
  # shared password.
  azure_active_directory_role_based_access_control {
    # Which Entra "directory" (list of people) to trust: the one you are
    # logged in to right now.
    tenant_id = data.azurerm_client_config.current.tenant_id

    # Use Azure roles to decide who may do what inside the cluster.
    azure_rbac_enabled = true
  }
  # Turn off the built-in master key. A key that never expires is a gift to a thief.
  local_account_disabled = true
  # (No "linux_profile" block here on purpose: that means no remote-login
  # keys for the nodes. One less key to lose.)

  # --- lets apps prove who they are to Azure without stored passwords ---
  oidc_issuer_enabled       = true
  workload_identity_enabled = true

  # --- stay patched: small safe updates install themselves ---
  automatic_upgrade_channel = "patch"
  node_os_upgrade_channel   = "NodeImage"

  # --- optional: only these addresses may reach the cluster's control desk ---
  dynamic "api_server_access_profile" {
    for_each = length(var.api_allowed_ips) > 0 ? [1] : []
    content {
      authorized_ip_ranges = var.api_allowed_ips
    }
  }

  tags = local.tags

  # Build order (and, in reverse, the take-down order):
  #  * The badge needs its permission slip, and a minute for it to settle,
  #    BEFORE the cluster is built.
  #  * On "terraform destroy" the cluster must go BEFORE the public address,
  #    because the cluster's load balancer is still holding on to it.
  depends_on = [
    time_sleep.permission_settles,
    azurerm_public_ip.ingress,
  ]
}

# ---- Step 6: worker nodes for your apps -------------------------------------
# System helpers and your apps get separate computers, so a busy app can
# never crowd out Kubernetes itself.
resource "azurerm_kubernetes_cluster_node_pool" "apps" {
  name                  = "apps"
  kubernetes_cluster_id = azurerm_kubernetes_cluster.this.id
  mode                  = "User"
  vm_size               = var.node_size
  vnet_subnet_id        = azurerm_subnet.nodes.id
  zones                 = local.zones_or_null
  orchestrator_version  = var.kubernetes_version # same Kubernetes as the brain

  # The disk each node starts up from (explained in locals.tf).
  os_disk_type    = local.os_disk_type
  os_disk_size_gb = local.os_disk_size_gb

  # The autoscaler adds nodes when apps need room and removes them when they don't.
  auto_scaling_enabled = true
  min_count            = local.user_nodes_min
  max_count            = local.user_nodes_max

  temporary_name_for_rotation = "appstmp"

  upgrade_settings {
    max_surge = "10%"
  }

  lifecycle {
    # Checked before anything is built.
    precondition {
      condition     = local.user_nodes_max >= local.user_nodes_min
      error_message = "user_nodes_max cannot be smaller than user_nodes_min."
    }
  }
}

# ---- Step 7: a key so YOU can log in ----------------------------------------
# Because the master key is off, nobody can log in yet, not even you. This
# gives the admin role to your group, or to you if you named no group.
resource "azurerm_role_assignment" "cluster_admin" {
  scope                = azurerm_kubernetes_cluster.this.id
  role_definition_name = "Azure Kubernetes Service RBAC Cluster Admin"
  principal_id         = var.admin_group_id != null ? var.admin_group_id : data.azurerm_client_config.current.object_id
  principal_type       = var.admin_group_id != null ? "Group" : null
}
