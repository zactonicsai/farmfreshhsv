# =============================================================================
#  providers.tf  -  how Terraform logs in to Azure
#
#  There is no password here. The azurerm provider reuses your "az login".
# =============================================================================

provider "azurerm" {
  # Which subscription to build in. Leave it empty (null) to use the one
  # "az" is pointing at right now.
  subscription_id = var.subscription_id

  # Azure services must be switched on once per subscription before they can
  # be used. Since version 5 the provider switches on nothing by itself, so we
  # list exactly the five this blueprint needs. It costs nothing.
  resource_providers_to_register = [
    "Microsoft.ContainerService", # AKS, the cluster
    "Microsoft.Network",          # networks and public addresses
    "Microsoft.Compute",          # the node computers
    "Microsoft.Storage",          # disks
    "Microsoft.ManagedIdentity",  # the cluster's ID badge
  ]

  features {
    resource_group {
      # A safety belt for "terraform destroy": refuse to delete the resource
      # group if it still holds things Terraform did not make.
      prevent_deletion_if_contains_resources = true
    }
  }
}

# Who is logged in right now? We use the answer to make that person a
# cluster admin (unless you name a group instead).
data "azurerm_client_config" "current" {}
