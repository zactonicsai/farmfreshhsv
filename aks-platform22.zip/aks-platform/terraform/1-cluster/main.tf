# =============================================================================
#  main.tf  -  the folder, the network, the ID badge and the public address
#
#  These are steps 1 to 4 of create-aks.sh, written as a blueprint.
#  Each "resource" block is one thing Terraform builds and then looks after.
#  When one block mentions another (like azurerm_resource_group.this.name),
#  Terraform knows it must build that other thing first.
# =============================================================================

# ---- Step 1: the resource group ---------------------------------------------
# A resource group is a folder. Everything in this blueprint goes in it, so
# you can see the cost of the whole project in one place.
resource "azurerm_resource_group" "this" {
  name     = local.resource_group_name
  location = var.location
  tags     = local.tags
}

# ---- Step 2: the private network --------------------------------------------
# Like the hallways of a school: computers inside can reach each other,
# strangers outside cannot walk in. We make it ourselves so that YOU choose
# the addresses, not AKS.
resource "azurerm_virtual_network" "this" {
  name                = local.vnet_name
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  address_space       = [local.vnet_cidr]
  tags                = local.tags
}

# One slice of the network, just for the node computers.
resource "azurerm_subnet" "nodes" {
  name                 = local.subnet_name
  resource_group_name  = azurerm_resource_group.this.name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = [local.node_subnet_cidr]

  # A "private" subnet: the nodes get no hidden way out to the internet.
  # They leave through the cluster's own load balancer, so every trip
  # outside uses an address you can see. (Left alone, the provider would
  # switch the old hidden way on.)
  default_outbound_access_enabled = false
}

# ---- Step 3: an ID badge for the cluster ------------------------------------
# The cluster needs permission to plug into the network and to use the public
# address. A managed identity is a badge with no password to leak.
resource "azurerm_user_assigned_identity" "aks" {
  name                = local.identity_name
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  tags                = local.tags
}

# The permission slip: "Network Contributor", but only inside our own folder.
# Giving only the access that is needed is called least privilege.
resource "azurerm_role_assignment" "aks_network" {
  scope                = azurerm_resource_group.this.id
  role_definition_name = "Network Contributor"
  principal_id         = azurerm_user_assigned_identity.aks.principal_id
  principal_type       = "ServicePrincipal"

  # The badge is only seconds old. This tells Azure not to look it up in the
  # staff directory first, where it may not have shown up yet.
  skip_service_principal_aad_check = true
}

# A brand-new permission can take a little while before every part of Azure
# knows about it. Waiting one minute here saves you from a confusing "not
# allowed" error while the cluster is being built. It only waits the first
# time; later runs skip it.
resource "time_sleep" "permission_settles" {
  create_duration = "60s"

  depends_on = [azurerm_role_assignment.aks_network]
}

# ---- Step 4: a public address that never changes ----------------------------
# Like a street address for your front door. Because it is reserved, your
# website name can point at it for as long as you keep it.
resource "azurerm_public_ip" "ingress" {
  name                = local.public_ip_name
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  allocation_method   = "Static"
  sku                 = "Standard"
  ip_version          = "IPv4"
  # With zones, ask for an address that survives one data center going dark.
  zones = local.public_ip_zones
  tags  = local.tags
}
