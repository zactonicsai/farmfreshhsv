# The Terraform way

This folder builds the same things as `create-aks.sh`: the cluster, the front
door, and the storage. The difference is how. The script is a list of
commands. Terraform works from a blueprint and keeps a notebook of what it
built.

## Start here

```bash
az login

# Stage 1: the Azure parts. About 10 to 15 minutes.
cd terraform/1-cluster
terraform init                                        # fetch the plug-ins (once)
terraform plan  -var name=shop -var ip_base=10.40     # a preview, changes nothing
terraform apply -var name=shop -var ip_base=10.40     # build it (asks you to type yes)

# Stage 2: the things inside the cluster. About 5 minutes.
cd ../2-platform
terraform init
terraform apply -var name=shop

# Optional: look around with kubectl. Terraform does not touch your kubectl
# settings, so stage 1 prints the two commands that connect it.
terraform -chdir=../1-cluster output -raw kubectl_login
```

> **Please read:** like the scripts, this blueprint was checked in many ways
> but has not been run against a live Azure account. See
> [How this was checked](#how-this-was-checked). Run `terraform plan` first and
> read it before you say yes.

Two things that are normal:

- Stage 1 stands still for one minute just before it builds the cluster. It
  is giving Azure time to spread a new permission.
- The cluster itself takes 5 to 10 minutes. Terraform prints `Still
  creating...` while it waits.

---

## Scripts or Terraform? Pick one

| | The scripts | Terraform |
|---|---|---|
| Good for | Learning, a quick practice cluster | Something you keep, change and share with a team |
| Remembers what it built | No. It asks Azure each time. | Yes. It keeps a notebook (the "state"). |
| Changing things later | Never changes a cluster that exists | Change a value, run `apply`, and it updates |
| Shows a preview first | `--dry-run` shows commands | `plan` shows exactly what will change |
| Taking it down | `destroy-aks.sh` | `terraform destroy` |

**Do not mix them on the same project.** If Terraform built it, only Terraform
should change it or take it down. To help with that, Terraform labels its
things `created-by=terraform`, and `destroy-aks.sh` refuses to touch anything
that does not carry its own label.

Terraform also cannot take over something the script already built. If you
want to switch, use a different `name` or `env`.

### Two small differences

Both ways build the same cluster. Two details are not the same:

1. **The disk each node starts up from.** The script lets Azure choose.
   Terraform has to say it out loud, so it asks for the faster kind that
   costs nothing extra (*ephemeral*, 60 GB) on every node. See
   `os_disk_type` under [Your choices](#your-choices).
2. **Your kubectl settings.** The script connects `kubectl` for you.
   Terraform leaves your computer alone and prints the two commands instead.

---

## New words

| The word | Picture it as |
|---|---|
| Terraform | A builder who works from a blueprint |
| `.tf` files | The blueprint |
| Provider | A plug-in that knows how to talk to one service, like Azure or Helm |
| `init` | The builder fetches the plug-ins |
| `plan` | A preview: "here is what I would add, change or remove" |
| `apply` | Do it |
| State | The builder's notebook of everything it built |
| Variable | A blank on the blueprint that you fill in |
| Output | What the builder reports back when done |

---

## Why two folders?

| Folder | What it builds | Steps of `create-aks.sh` |
|---|---|---|
| `1-cluster` | The Azure parts: folder, network, ID badge, public address, cluster, app nodes, your admin access | 1 to 7 |
| `2-platform` | The things inside the cluster: Istio, the gateway, rooms and storage | 8 and 9 |

Terraform always makes a full plan before it builds anything. It cannot plan
what goes *inside* a cluster that does not exist yet. So we build in two
rounds. HashiCorp, the company behind Terraform, recommends this too.

There is a bonus. When you change a Helm setting, you only run stage 2 again.
That takes a minute and cannot touch the cluster itself.

Stage 2 finds the cluster by its name, so give both stages the same `name`
and `env`. It uses the very same Helm files as the script (the `helm/` folder
next to this one), so there is one place to change a setting.

---

## What you need first

1. **An Azure subscription where you are an Owner.** (Contributor plus
   "User Access Administrator" also works.) The blueprint hands out two
   permission slips.
2. **Three tools:**
   - `terraform` 1.9 or newer. This was checked with 1.17.
   - `az`, the Azure CLI. Terraform reuses your `az login`.
   - `kubelogin`. Stage 2 uses it to log in to the cluster.
3. **To be signed in:** run `az login`.

You do not need the `helm` program. The Helm plug-in has Helm built in.
`kubectl` is only needed if you want to look around afterwards.

**The easy way:** [Azure Cloud Shell](https://shell.azure.com) already has
all three, and you are signed in the moment it opens.

**On your own computer:** install Terraform and the Azure CLI from their
websites. Then `az aks install-cli` adds `kubelogin`. On Linux or a Mac you
may need to type `sudo` in front of it.

The first `terraform init` in each folder needs the internet. It downloads
the plug-ins.

---

## Your choices

Give them with `-var name=value`, or copy `terraform.tfvars.example` to
`terraform.tfvars` and fill it in. Then you can just type `terraform apply`.

### Stage 1 (`1-cluster`)

These are the same choices as `create-aks.sh`. The main README explains
`name`, `ip_base` and the two sizes in detail.

| Variable | What it does | Default |
|---|---|---|
| `name` | Project name. **Required.** | |
| `ip_base` | First two numbers of your network, like `10.40`. **Required.** | |
| `env` | A label such as `dev`, `test` or `prod` | `dev` |
| `location` | Azure region | `eastus2` |
| `profile` | `small` or `ha` | `small` (`ha` when env is prod) |
| `subscription_id` | Which Azure subscription | the one `az` uses now |
| `node_size` | VM size for app nodes | `Standard_D4ds_v5` |
| `system_node_size` | VM size for system nodes | from the profile |
| `system_nodes` | How many system nodes | from the profile |
| `user_nodes_min` | Fewest app nodes | from the profile |
| `user_nodes_max` | Most app nodes | from the profile |
| `zones` | `["1", "2", "3"]`, or `[]` for none | from the profile |
| `tier` | `free` or `standard` | from the profile |
| `os_disk_type` | Where each node keeps its operating system: `Ephemeral` or `Managed` | `Ephemeral` |
| `os_disk_size_gb` | Size of that disk | `60` for Ephemeral, Azure's pick for Managed |
| `kubernetes_version` | Kubernetes version | `1.36` |
| `admin_group_id` | A Microsoft Entra group whose members become admins | only you |
| `api_allowed_ips` | Only these ranges may reach the control desk | anywhere |
| `tags` | Extra labels for billing, like `{ owner = "team-a" }` | |

### Stage 2 (`2-platform`)

| Variable | What it does | Default |
|---|---|---|
| `name` | The same name as stage 1. **Required.** | |
| `env` | The same label as stage 1 | `dev` |
| `subscription_id` | Which Azure subscription | the one `az` uses now |
| `istio_version` | Istio version | `1.31.4` |
| `disk_sku` | Disk type for the storage class | ZRS with zones, LRS without |

Wrong input is caught before anything is built. For example, `ip_base=8.8`
stops with a message that explains which ranges are allowed.

**About `os_disk_type`.** Every node is a computer, and it needs a disk to
start up from.

- `Ephemeral` uses the disk that is built into the node. It is faster, and
  it is already part of the node's price. It only works when that built-in
  disk is big enough. The default VM sizes in this kit have room.
- `Managed` uses a separate Azure disk. It works with every VM size, but
  you pay for one more disk per node.

If you choose a small or low-cost `node_size` and Azure answers that an
ephemeral disk is not supported or does not fit, add
`-var os_disk_type=Managed`.

**About `zones`.** The nodes use exactly the zones you list. The public
address is different: Azure offers "one zone" or "all zones" for an address.
When you use any zones, this kit asks for all of them.

---

## What each file is

| File | What it is |
|---|---|
| `1-cluster/versions.tf` | Which Terraform and plug-in versions to use, and where the notebook is kept |
| `1-cluster/providers.tf` | How Terraform logs in to Azure |
| `1-cluster/variables.tf` | Your choices, with a check on each one |
| `1-cluster/locals.tf` | Names, the address plan and the size presets, worked out from your choices |
| `1-cluster/main.tf` | Steps 1 to 4: folder, network, ID badge, public address |
| `1-cluster/aks.tf` | Steps 5 to 7: cluster, app nodes, your admin access |
| `1-cluster/outputs.tf` | What is reported at the end, such as the public address |
| `1-cluster/terraform.tfvars.example` | A form to copy and fill in, so you need not type `-var` each time |
| `1-cluster/tests/` | Checks you can run without Azure (see below) |
| `2-platform/versions.tf`, `providers.tf` | Plug-in versions, and how Terraform logs in to the cluster |
| `2-platform/variables.tf` | Your choices for stage 2 |
| `2-platform/main.tf` | Steps 8 and 9: Istio, the gateway, rooms and storage |
| `2-platform/outputs.tf` | What is reported at the end |
| `2-platform/terraform.tfvars.example` | A form to copy and fill in |
| `2-platform/tests/` | Checks you can run without Azure |
| `.gitignore` | Keeps the notebook and your settings out of git |

Every file has comments in plain words next to each setting.

---

## The notebook (state): keep it safe

Terraform writes down everything it built in a file called
`terraform.tfstate`. That file is how it knows what is yours.

- **Never delete it.** Without it, Terraform forgets what it built. The
  things stay in Azure, still costing money, and Terraform can no longer
  change or remove them.
- **Never put it in git.** It can hold private details. The `.gitignore`
  here already keeps it out.
- **Do commit `.terraform.lock.hcl`.** `terraform init` makes it. It records
  the exact plug-in versions, so everyone gets the same ones.

By default the notebook sits in each stage's folder. That is fine for
practice. For a team, or for anything real, keep it in Azure Storage. There
it is backed up, and two people cannot change things at the same moment.

Make the storage once:

```bash
az group create --name rg-tfstate --location eastus2

# The name must be unique in all of Azure: 3-24 small letters and numbers.
az storage account create --name CHANGEME --resource-group rg-tfstate \
  --sku Standard_LRS --min-tls-version TLS1_2 --allow-blob-public-access false

az storage container create --name tfstate --account-name CHANGEME --auth-mode login

# Allow yourself to read and write the notebook.
az role assignment create --role "Storage Blob Data Contributor" \
  --assignee "$(az ad signed-in-user show --query id -o tsv)" \
  --scope "$(az storage account show --name CHANGEME --resource-group rg-tfstate --query id -o tsv)"
```

Then open `versions.tf` in each stage, remove the `#` marks from the
`backend "azurerm"` block, put in your storage name, and run:

```bash
terraform init -migrate-state
```

---

## Changing things later

Change a variable or a file, then run `plan` and `apply` again. Terraform
works out the difference and changes only that.

- **More app nodes:** `terraform apply -var name=shop -var ip_base=10.40 -var user_nodes_max=6`
  in stage 1. Unlike the script, Terraform updates the cluster that exists.
- **A Helm setting, or any file under `helm/`:** edit it, then run `apply`
  in stage 2. Terraform notices the edit by itself. For our own chart it
  keeps a *fingerprint*: a short code worked out from every file in
  `helm/platform`. Change a file and the code changes.
- **A newer Kubernetes:** first check that your Istio version supports it.
  Then set `kubernetes_version` in stage 1. Terraform upgrades the brain
  first, then the system nodes, then the app nodes. Go up one step at a
  time (1.36, then 1.37). Small safety updates inside a version install
  themselves; you do nothing for those.
- **A newer Istio:** set `istio_version` in stage 2. Go up one step at a
  time (1.31, then 1.32).

**Read the plan before you say yes.** Most changes say `update in-place`.
If the plan says `must be replaced` next to the cluster or the public
address, stop. Replacing means deleting and building again: the cluster's
data would be lost, or your address would change. Changing `name`, `env`,
`ip_base` or `location` does this. Turning zones on or off later (or
switching between `small` and `ha`) replaces the public address.

Tip: put your choices in `terraform.tfvars`. If you type `-var` by hand and
forget one, Terraform thinks you want the default back.

---

## Taking it down

Go in the opposite order: inside first, then the cluster.

```bash
cd terraform/2-platform
terraform destroy -var name=shop

cd ../1-cluster
terraform destroy -var name=shop -var ip_base=10.40
```

Terraform shows what it will remove and asks you to type `yes`.

> **There is no undo.** The disks your apps use are deleted with the
> cluster. Back up anything you need first.

Good to know:

- Stage 2 leaves the namespaces and volume claims in place on purpose. They
  go when the cluster is deleted in stage 1.
- If the resource group holds something Terraform did not make, the last
  step stops instead of deleting it. Remove that thing yourself and run
  `destroy` again.
- Already destroyed stage 1 before stage 2? Then stage 2 has nothing left
  to remove. Delete the `terraform.tfstate` files in `2-platform` and you
  are done.

---

## Check the blueprint without Azure

Each stage has a `tests` folder. The tests swap Azure and Helm for pretend
ones, so they need no login, build nothing and cost nothing. They take a few
seconds.

```bash
cd terraform/1-cluster && terraform init && terraform test
cd ../2-platform       && terraform init && terraform test
```

| Test file | What it checks |
|---|---|
| `1-cluster/tests/blueprint.tftest.hcl` | The names, the address plan, both size presets, the safety settings, and that your own choices win |
| `1-cluster/tests/bad_inputs.tftest.hcl` | That 27 kinds of wrong input are refused before anything is built |
| `1-cluster/tests/wiring.tftest.hcl` | A pretend build, to check every part is plugged into the right part |
| `2-platform/tests/blueprint.tftest.hcl` | The three Istio charts, the reserved address on the gateway, the disk type, and wrong input |

Run them after you change the blueprint, before you run `apply`.

The tests are a spell check, not a test drive. They prove the blueprint is
written correctly and does what this guide says. They cannot prove that
Azure will accept it. Only a real `apply` can.

---

## If something goes wrong

| What you see | What it means | What to do |
|---|---|---|
| A message about the subscription ID or `az login` | Terraform cannot tell which subscription to use | Run `az login`, or add `-var subscription_id=...` |
| `does not have authorization to perform action 'Microsoft.Authorization/roleAssignments/write'` | You may not hand out permission slips | Ask to be made Owner, or Contributor plus User Access Administrator |
| A message about `quota`, a VM size, or `zone` | Your subscription or region cannot give what was asked | Try `-var profile=small`, another `node_size`, or `-var 'zones=[]'` |
| A message about an `Ephemeral` OS disk that is not supported or is too big | The VM size you chose has no built-in disk with enough room | Add `-var os_disk_type=Managed` |
| Stage 1: the cluster step fails with a message about permission on the network or subnet | The cluster's new permission had not reached all of Azure yet | Run `apply` again. Terraform carries on from where it stopped. |
| Stage 2: the cluster `was not found` | Stage 1 is not built, or `name` and `env` differ | Apply stage 1 first, and use the same `name` and `env` |
| Stage 2: `executable kubelogin not found` | The login helper is missing | Install it: `az aks install-cli` |
| Stage 2: `Unauthorized` or `forbidden` | Your new admin rights have not reached the cluster yet | Wait two minutes and run `apply` again. In Cloud Shell it can also help to run `az login` once. |
| Stage 2: `i/o timeout`, or it cannot reach the cluster | You set `api_allowed_ips` in stage 1, and this computer's address is not on the list | Add your address to `api_allowed_ips` and apply stage 1 again |
| Stage 2: `was not found` on a chart, or it cannot download | The computer cannot reach the Istio chart site, or the version does not exist | Check `istio_version`, and that you can open `https://blob.istio.io/istio-release/charts/index.yaml` |
| Stage 2: the gateway step times out | Azure could not attach the public address | Run `kubectl -n istio-ingress describe service istio-ingressgateway` and read the last lines. Then run `apply` again. |
| Destroy: the resource group `still contains resources` | Something Terraform did not make is in the group | Remove it yourself, then run `destroy` again |
| Destroy: the subnet or the public address `is in use` | Azure is still tidying up after the cluster | Wait a few minutes and run `destroy` again |
| An error stops `apply` half-way | One step failed | Fix the cause and run `apply` again. Terraform carries on from where it stopped. |

---

## Versions

Checked on 13 November 2026.

| Part | Version | Notes |
|---|---|---|
| Terraform | 1.17.2 | The blueprint asks for 1.9 or newer |
| azurerm plug-in | 5.13.0 | Pinned to 5.x. Version 5 changed several settings, so older guides on the web may not match. |
| helm plug-in | 3.3.0 | Pinned to 3.x |
| time plug-in | 0.14.2 | Only used for the one-minute pause in stage 1 |
| Kubernetes, Istio | 1.36, 1.31.4 | The same as the scripts. See the main README. |

---

## How this was checked

Checked on 13 November 2026. **Nothing here was run against a real Azure
account.** The checking was done on a computer with no Azure login. Here is
what was done instead, and what that leaves open.

### What was done

1. **Format and grammar.** `terraform fmt -check` and `terraform validate`
   pass on both stages. They ran on Terraform 1.17.2 with the real code of
   all three plug-ins. `validate` caught one real mistake, now fixed: since
   version 5 of the Azure plug-in, the login block must name a `tenant_id`.
2. **55 tests.** `terraform test` runs 43 tests in stage 1 and 12 in stage 2.
   All pass. The tests use a pretend Azure, but Terraform still runs the
   Azure plug-in's own checks on the values. To be sure of that, a setting
   was misspelled on purpose, and the test failed as it should.
3. **Broken on purpose, 57 times.** One line of the blueprint at a time was
   changed to something wrong: wrong address maths, a missing label, the
   master key left on, a part plugged into the wrong part, and so on. After
   each change the tests ran again. They caught all 57.
4. **The real Helm plug-in with a pretend cluster.** It planned all four
   Helm installs. It found the three Istio charts by name and version, and
   it loaded this kit's own chart from disk. The Istio charts came from a
   copy of Istio 1.31.4's own source, because the checking computer could
   not reach the Istio chart site.
5. **What Helm would install.** The real Istio gateway chart and this kit's
   chart were filled in with exactly the values Terraform hands over. The
   gateway came out as a load balancer carrying both Azure notes, and the
   storage class got the right disk type.
6. **The build order.** Terraform's own order list (`terraform graph`) shows
   that the cluster waits for the one-minute pause, the public address and
   the subnet, and that the app nodes and your admin key come after the
   cluster.
7. **The fingerprint.** It stays the same when nothing changes. It changes
   when any chart file is edited. It ignores hidden files.
8. **Both `terraform.tfvars.example` files.** Every line was switched on and
   accepted.
9. **The plug-in's source code was read** for the settings used here, to
   find places where it acts differently from the `az` commands in
   `create-aks.sh`. Two turned up: the node's start-up disk and the subnet's
   "private" switch. The blueprint now sets both out loud.

### What was not done

- **No `terraform plan` or `apply` against Azure.** A real plan needs a
  login. So quotas, region limits, and whether Azure accepts all these
  settings together are untested. The choices follow Microsoft's documents
  (linked below), not a trial run. That includes the 60 GB ephemeral disk on
  the default VM sizes.
- **Helm never installed anything into a live cluster through Terraform.**
  The login step with `kubelogin` is written the way the documents
  describe. It was not tried.
- **`terraform destroy` was not run.**
- **The plug-ins were built from their public source code.** The checking
  computer could not reach the download site for the official files. The
  Azure plug-in was built with only the parts this blueprint uses. Your
  `terraform init` downloads the official ones.
- **Only Terraform 1.17.2 on Linux was used.** The blueprint asks for 1.9 or
  newer, but older versions were not tried.
- **The commands for the notebook storage** were checked against the Azure
  CLI's own rules. They were not run.

So do the `plan` first, read it, and start with the small size.

---

## Where the facts came from

Terraform and its plug-ins:

- [azurerm provider: version 5.0 upgrade guide](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/guides/5.0-upgrade-guide)
- [azurerm provider: `azurerm_kubernetes_cluster`](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/kubernetes_cluster)
- [Helm provider documentation](https://registry.terraform.io/providers/hashicorp/helm/latest/docs)
- [Kubernetes provider: why the cluster and what is inside it are built separately](https://registry.terraform.io/providers/hashicorp/kubernetes/latest/docs#stacking-with-managed-kubernetes-cluster-resources)
- [Terraform tests and pretend ("mock") providers](https://developer.hashicorp.com/terraform/language/tests/mocking)

Choices made in the blueprint:

- [Ephemeral OS disks on AKS nodes](https://learn.microsoft.com/azure/aks/concepts-storage): faster, no extra cost, and must fit the node's built-in disk
- [Private subnets and default outbound access](https://learn.microsoft.com/azure/virtual-network/ip-services/default-outbound-access)
- [AKS outbound types](https://learn.microsoft.com/azure/aks/egress-outboundtype): AKS itself now uses private subnets
- [Public IP addresses and zones](https://learn.microsoft.com/azure/virtual-network/ip-services/public-ip-addresses)
- [Install Istio with Helm](https://istio.io/latest/docs/setup/install/helm/): the chart site and chart names
- [What Azure Cloud Shell has installed](https://learn.microsoft.com/azure/cloud-shell/features), and [the list it is built from](https://github.com/Azure/CloudShell)

The main [README](../README.md#where-the-facts-came-from) lists the sources
for the cluster design itself.
