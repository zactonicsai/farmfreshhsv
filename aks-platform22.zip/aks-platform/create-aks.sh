#!/usr/bin/env bash
# =============================================================================
#  create-aks.sh
#
#  WHAT THIS DOES (in plain words)
#    It builds a home for your apps on Microsoft Azure, one piece at a time:
#
#      1. A folder that keeps everything together     (resource group)
#      2. A private network with its own addresses    (virtual network)
#      3. An ID badge for the cluster                 (managed identity)
#      4. A street address that never changes         (static public IP)
#      5. The cluster itself                          (AKS)
#      6. Worker computers for your apps              (node pool)
#      7. A key so YOU can log in                     (access)
#      8. A guarded front door                        (Istio gateway)
#      9. Rooms and storage lockers for future apps   (namespaces + volumes)
#
#  SAFE TO RUN AGAIN
#    If a piece already exists, the script leaves it alone and moves on.
#
#  TRY IT WITHOUT CHANGING ANYTHING
#    ./create-aks.sh --name shop --ip-base 10.40 --dry-run
#
#  TAKE IT DOWN AGAIN
#    ./destroy-aks.sh --name shop
#
#  Runs on Linux, macOS (even its old bash 3.2), WSL and Azure Cloud Shell.
# =============================================================================

# Stop at the first error instead of charging ahead with a half-built setup.
#   -e  stop when a command fails
#   -E  make our "something went wrong" message work inside functions too
#   -u  stop if we use a variable we never set (catches typos)
#   -o pipefail  a chain of commands fails if ANY link fails, not just the last
set -Eeuo pipefail

# Git Bash on Windows tries to "fix" anything that starts with a slash.
# Azure IDs start with a slash, so tell it to leave them alone.
export MSYS_NO_PATHCONV=1
# Hide Azure CLI chatter such as "this command is in preview". Real errors still show.
export AZURE_CORE_ONLY_SHOW_ERRORS=true

# -----------------------------------------------------------------------------
# VERSIONS - checked to work together on 2026-11-12.
# Think of these as a matched set, like shoes. Change one, check the other.
#   * AKS offers Kubernetes 1.35, 1.36 and 1.37 today (1.36 is its default).
#   * Istio 1.31 supports Kubernetes 1.32 through 1.37.
# -----------------------------------------------------------------------------
DEFAULT_KUBERNETES_VERSION="1.36"
DEFAULT_ISTIO_VERSION="1.31.4"
# Where the official Istio Helm charts live (they moved here in 2026).
ISTIO_CHART_REPO="https://blob.istio.io/istio-release/charts"
TESTED_AZ_CLI="2.92.0"
OLDEST_OK_AZ_CLI="2.70.0"

# -----------------------------------------------------------------------------
# FIXED NAMES inside the cluster. The Helm files use the same names,
# so only change these if you also change the files in ./helm.
# -----------------------------------------------------------------------------
SYSTEM_POOL="system"                  # nodes that run Kubernetes' own helpers
APPS_POOL="apps"                      # nodes that run YOUR apps
ISTIO_SYSTEM_NS="istio-system"        # where the Istio "brain" lives
ISTIO_INGRESS_NS="istio-ingress"      # where the front door lives
GATEWAY_RELEASE="istio-ingressgateway"
PLATFORM_NS="platform"                # where Helm keeps notes about our own chart
PLATFORM_RELEASE="platform"

# -----------------------------------------------------------------------------
# INPUTS. Empty means "not chosen yet". Defaults are filled in later.
# -----------------------------------------------------------------------------
NAME=""; IP_BASE_INPUT=""; ENV_NAME=""; LOCATION=""; PROFILE=""; SUBSCRIPTION=""
NODE_SIZE=""; SYSTEM_NODE_SIZE=""; SYSTEM_NODES=""; USER_NODES_MIN=""; USER_NODES_MAX=""
ZONES=""; TIER=""; KUBERNETES_VERSION=""; ISTIO_VERSION=""
ADMIN_GROUP_ID=""; API_ALLOWED_IPS=""; EXTRA_TAGS=""; DISK_SKU_INPUT=""
DRY_RUN=false; ASSUME_YES=false

# Things the script works out as it goes.
STEP_NO=0; STEP_TOTAL=9; STEP_TITLE=""
SUBSCRIPTION_ID=""; SUBSCRIPTION_NAME=""
TMP_DIR=""; ROLE_CREATED=false
ZONE_LIST=(); TAGS=()

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
HELM_DIR="${SCRIPT_DIR}/helm"

# =============================================================================
#  Small helpers
# =============================================================================

# Use colors only when a person is looking at a terminal.
if [[ -t 1 && -z "${NO_COLOR:-}" ]]; then
  C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'; C_RED=$'\033[31m'
  C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'; C_OFF=$'\033[0m'
else
  C_BOLD=""; C_DIM=""; C_RED=""; C_GREEN=""; C_YELLOW=""; C_OFF=""
fi

info() { printf '%s\n' "  $*"; }
# ok: a green tick for something that really happened (so it stays quiet in a dry run).
ok() {
  if [[ "$DRY_RUN" == true ]]; then return 0; fi
  printf '%s\n' "  ${C_GREEN}ok${C_OFF}    $*"
}
note() { printf '%s\n' "  ${C_YELLOW}note${C_OFF}  $*"; }
die()  { printf '\n%s\n\n' "${C_RED}STOP:${C_OFF} $*" >&2; exit 1; }

# step "Title" "one plain sentence about why we do this"
step() {
  STEP_NO=$((STEP_NO + 1)); STEP_TITLE="$1"
  printf '\n%s\n' "${C_BOLD}Step ${STEP_NO} of ${STEP_TOTAL}: $1${C_OFF}"
  printf '%s\n' "  ${C_DIM}$2${C_OFF}"
}

# If any command fails, say so in plain words. (Skip the message inside
# sub-shells, otherwise the same failure would be announced twice.)
on_error() {
  local exit_code=$? line="$1"
  if [[ "${BASH_SUBSHELL}" -eq 0 ]]; then
    if [[ "$STEP_NO" -gt 0 ]]; then
      printf '\n%s\n' "${C_RED}Step ${STEP_NO} did not finish:${C_OFF} ${STEP_TITLE}  (script line ${line}, exit code ${exit_code})" >&2
    else
      printf '\n%s\n' "${C_RED}Something went wrong${C_OFF} while getting ready (script line ${line}, exit code ${exit_code})." >&2
    fi
    printf '%s\n' "Read the message just above this one. Once it is fixed, run the same" >&2
    printf '%s\n\n' "command again. The script skips every piece that is already built." >&2
  fi
}
trap 'on_error "$LINENO"' ERR

# Always tidy up our scratch folder, even if we stop early.
cleanup() {
  if [[ -n "${TMP_DIR}" && -d "${TMP_DIR}" ]]; then rm -rf "${TMP_DIR}"; fi
}
trap cleanup EXIT

# Put quotes around a word only when it needs them, so printed commands
# look like something a person would type.
quote_arg() {
  local safe_re='^[A-Za-z0-9_./:=@%+,-]+$'
  if [[ "$1" =~ $safe_re ]]; then
    printf '%s' "$1"
  elif [[ "$1" == *"'"* ]]; then
    printf '%q' "$1"
  else
    printf "'%s'" "$1"
  fi
}

# Print a command the way you could type it, one option per line.
print_cmd() {
  local out="" arg quoted
  for arg in "$@"; do
    quoted="$(quote_arg "$arg")"
    if [[ -z "$out" ]]; then
      out="$quoted"
    elif [[ "$arg" == --* ]]; then
      out="${out} \\"$'\n'"        ${quoted}"
    else
      out="${out} ${quoted}"
    fi
  done
  printf '%s\n' "${C_DIM}    \$ ${out}${C_OFF}"
}

# run: show a command, then do it. In a dry run we only show it.
run() {
  print_cmd "$@"
  if [[ "$DRY_RUN" == true ]]; then return 0; fi
  "$@"
}

# retry <times> <seconds-between> <command...>
# Azure sometimes needs a moment before a brand-new thing can be used.
retry() {
  local times="$1" pause="$2" attempt=1
  shift 2
  until "$@"; do
    if [[ "$attempt" -ge "$times" ]]; then return 1; fi
    note "That did not work yet (try ${attempt} of ${times}). Waiting ${pause}s and trying again..."
    sleep "$pause"
    attempt=$((attempt + 1))
  done
}

# az_do: run an Azure command that CHANGES something, in the chosen subscription.
az_do() { run az "$@" --subscription "$SUBSCRIPTION_ID" --output none; }

# az_get <pretend-answer> <az args...>: ask Azure for ONE value.
# In a dry run we do not talk to Azure, so we hand back the pretend answer.
az_get() {
  local pretend="$1"
  shift
  if [[ "$DRY_RUN" == true ]]; then printf '%s' "$pretend"; return 0; fi
  # tr removes the stray "\r" that Windows adds to the end of lines.
  az "$@" --subscription "$SUBSCRIPTION_ID" --output tsv | tr -d '\r'
}

# az_exists <az show ...>: "yes" if the thing exists, "no" if Azure says
# "not found". Any other problem (no internet, expired login) stops the script,
# so we never build a second copy of something by mistake.
az_exists() {
  local out
  if [[ "$DRY_RUN" == true ]]; then return 1; fi
  if out="$(az "$@" --subscription "$SUBSCRIPTION_ID" --output none 2>&1)"; then return 0; fi
  if printf '%s' "$out" | grep -qiE 'not ?found|not be found|does not exist'; then return 1; fi
  die "I could not check Azure for: az $1 $2 $3
Azure said: ${out}"
}

# ensure_role <who (object id)> <kind of who> <role name> <where (scope id)>
# Gives a permission slip, unless that exact slip is already there.
ensure_role() {
  local who="$1" kind="$2" role="$3" scope="$4" existing=""
  if [[ "$DRY_RUN" != true ]]; then
    existing="$(az role assignment list --scope "$scope" --subscription "$SUBSCRIPTION_ID" \
      --query "[?principalId=='${who}' && roleDefinitionName=='${role}'] | [0].id" \
      --output tsv | tr -d '\r')"
  fi
  if [[ -n "$existing" ]]; then
    ok "Permission \"${role}\" is already in place"
    return 0
  fi
  # Saying the "kind" up front lets Azure skip a lookup that can fail for
  # identities that are only a few seconds old.
  retry 4 15 az_do role assignment create \
    --assignee-object-id "$who" \
    --assignee-principal-type "$kind" \
    --role "$role" \
    --scope "$scope"
  ROLE_CREATED=true
}

# version_at_least 2.92.0 2.70.0  ->  true when the first is the same or newer
version_at_least() {
  local IFS=.
  # shellcheck disable=SC2206  # we WANT the dots to split the numbers apart
  local -a have=($1) want=($2)
  local i h w
  for i in 0 1 2; do
    h="${have[i]:-0}"; w="${want[i]:-0}"
    h="${h%%[!0-9]*}"; w="${w%%[!0-9]*}"
    if (( 10#${h:-0} > 10#${w:-0} )); then return 0; fi
    if (( 10#${h:-0} < 10#${w:-0} )); then return 1; fi
  done
  return 0
}

usage() {
  cat <<EOF
${C_BOLD}create-aks.sh${C_OFF} - build an AKS cluster with an Istio front door and storage

${C_BOLD}USAGE${C_OFF}
  ./create-aks.sh --name NAME --ip-base A.B [options]

${C_BOLD}YOU MUST GIVE${C_OFF}
  -n, --name NAME            Short name for your project. 3-20 characters:
                             small letters, numbers and dashes. Example: shop
  -i, --ip-base A.B          The first two numbers of your private network.
                             Example: 10.40 gives the network 10.40.0.0/16
                             Allowed: 10.0-10.255, 172.16-172.29, 192.168

${C_BOLD}COMMON CHOICES${C_OFF}
  -e, --env ENV              Label such as dev, test or prod      (default: dev)
  -l, --location REGION      Azure region                         (default: eastus2)
  -p, --profile small|ha     Size preset. See the table below.
                             (default: small, or ha when --env is prod)
  -s, --subscription ID      Azure subscription name or ID
                             (default: the one "az" is using now)

${C_BOLD}SIZES${C_OFF} (each one overrides the preset)
      --node-size SIZE           VM size for app nodes       (Standard_D4ds_v5)
      --system-node-size SIZE    VM size for system nodes
      --system-nodes N           How many system nodes
      --user-nodes-min N         Fewest app nodes
      --user-nodes-max N         Most app nodes (it grows by itself up to here)
      --zones "1 2 3" | none     Spread nodes over separate data centers
      --tier free|standard       standard adds an uptime promise, for a fee
      --disk-sku TYPE            Disk type for the storage class. One of:
                                 Premium_LRS, Premium_ZRS, StandardSSD_LRS,
                                 StandardSSD_ZRS. (default: Premium_ZRS when the
                                 cluster uses zones, Premium_LRS when it does not)

                         small (practice)       ha (real users)
      tier               free                   standard
      zones              none                   1 2 3
      system nodes       1 x Standard_D2ds_v5   3 x Standard_D4ds_v5
      app nodes          1 to 3                 3 to 6

${C_BOLD}VERSIONS${C_OFF}
      --kubernetes-version X.Y   (default: ${DEFAULT_KUBERNETES_VERSION})
      --istio-version X.Y.Z      (default: ${DEFAULT_ISTIO_VERSION})

${C_BOLD}SAFETY${C_OFF}
      --admin-group-id ID        Microsoft Entra group (object ID) whose members
                                 become cluster admins. Default: only you.
      --api-allowed-ips LIST     Only these addresses may talk to the cluster's
                                 control desk. Example: 203.0.113.7/32
                                 (You must run this script from one of them.)

${C_BOLD}OTHER${C_OFF}
      --tags "k=v k=v"           Extra Azure labels for billing reports
      --dry-run                  Show the plan and every command. Change nothing.
  -y, --yes                      Do not stop to ask "are you sure?"
  -h, --help                     Show this help

${C_BOLD}EXAMPLES${C_OFF}
  ./create-aks.sh --name shop --ip-base 10.40 --dry-run
  ./create-aks.sh --name shop --ip-base 10.40
  ./create-aks.sh --name shop --ip-base 10.41 --env prod --location westeurope
EOF
}

# =============================================================================
#  Reading and checking what you typed
# =============================================================================

need_value() {
  if [[ $# -lt 2 || -z "$2" || "$2" == --* ]]; then
    die "The option $1 needs a value right after it. Example: $1 something"
  fi
}

parse_args() {
  # Let people write --name=shop as well as --name shop.
  local -a args=()
  local arg
  for arg in "$@"; do
    case "$arg" in
      --*=*) args+=("${arg%%=*}" "${arg#*=}") ;;
      *)     args+=("$arg") ;;
    esac
  done
  set -- ${args[@]+"${args[@]}"}

  local zone_re='^[1-3]$'
  while [[ $# -gt 0 ]]; do
    case "$1" in
      -n|--name)            need_value "$@"; NAME="$2"; shift 2 ;;
      -i|--ip-base)         need_value "$@"; IP_BASE_INPUT="$2"; shift 2 ;;
      -e|--env)             need_value "$@"; ENV_NAME="$2"; shift 2 ;;
      -l|--location)        need_value "$@"; LOCATION="$2"; shift 2 ;;
      -p|--profile)         need_value "$@"; PROFILE="$2"; shift 2 ;;
      -s|--subscription)    need_value "$@"; SUBSCRIPTION="$2"; shift 2 ;;
      --node-size)          need_value "$@"; NODE_SIZE="$2"; shift 2 ;;
      --system-node-size)   need_value "$@"; SYSTEM_NODE_SIZE="$2"; shift 2 ;;
      --system-nodes)       need_value "$@"; SYSTEM_NODES="$2"; shift 2 ;;
      --user-nodes-min)     need_value "$@"; USER_NODES_MIN="$2"; shift 2 ;;
      --user-nodes-max)     need_value "$@"; USER_NODES_MAX="$2"; shift 2 ;;
      --tier)               need_value "$@"; TIER="$2"; shift 2 ;;
      --disk-sku)           need_value "$@"; DISK_SKU_INPUT="$2"; shift 2 ;;
      --kubernetes-version) need_value "$@"; KUBERNETES_VERSION="$2"; shift 2 ;;
      --istio-version)      need_value "$@"; ISTIO_VERSION="$2"; shift 2 ;;
      --admin-group-id)     need_value "$@"; ADMIN_GROUP_ID="$2"; shift 2 ;;
      --api-allowed-ips)    need_value "$@"; API_ALLOWED_IPS="$2"; shift 2 ;;
      --zones)
        need_value "$@"; ZONES="$2"; shift 2
        # Also accept --zones 1 2 3 typed without quotes.
        while [[ $# -gt 0 && "$1" =~ $zone_re ]]; do ZONES="${ZONES} $1"; shift; done ;;
      --tags)
        need_value "$@"; EXTRA_TAGS="$2"; shift 2
        # Also accept --tags a=1 b=2 typed without quotes.
        while [[ $# -gt 0 && "$1" != -* && "$1" == *=* ]]; do EXTRA_TAGS="${EXTRA_TAGS} $1"; shift; done ;;
      --dry-run)            DRY_RUN=true; shift ;;
      -y|--yes)             ASSUME_YES=true; shift ;;
      -h|--help)            usage; exit 0 ;;
      -*) die "I don't know the option '$1'. Run ./create-aks.sh --help to see the list." ;;
      *)  die "I did not expect the word '$1' here. If a value has spaces, put it in quotes.
Options such as --dry-run and --yes take no value. Run ./create-aks.sh --help to see the list." ;;
    esac
  done
}

apply_defaults() {
  : "${ENV_NAME:=dev}"
  : "${LOCATION:=eastus2}"
  : "${KUBERNETES_VERSION:=$DEFAULT_KUBERNETES_VERSION}"
  : "${ISTIO_VERSION:=$DEFAULT_ISTIO_VERSION}"

  # No preset chosen? Real-user environments get the strong one.
  if [[ -z "$PROFILE" ]]; then
    case "$ENV_NAME" in
      prod|prd|production) PROFILE="ha" ;;
      *)                   PROFILE="small" ;;
    esac
  fi

  case "$PROFILE" in
    small)   # for learning and testing: cheap, but one broken part can stop it
      : "${TIER:=free}"
      : "${ZONES:=none}"
      : "${SYSTEM_NODES:=1}"
      : "${SYSTEM_NODE_SIZE:=Standard_D2ds_v5}"
      : "${USER_NODES_MIN:=1}"
      : "${USER_NODES_MAX:=3}"
      ;;
    ha)      # "high availability": keeps working when one part breaks
      : "${TIER:=standard}"
      : "${ZONES:=1 2 3}"
      : "${SYSTEM_NODES:=3}"
      : "${SYSTEM_NODE_SIZE:=Standard_D4ds_v5}"
      : "${USER_NODES_MIN:=3}"
      : "${USER_NODES_MAX:=6}"
      ;;
    *) die "--profile must be small or ha (you gave: ${PROFILE})." ;;
  esac
  : "${NODE_SIZE:=Standard_D4ds_v5}"
}

validate_inputs() {
  local re

  # ---- name ----
  if [[ -z "$NAME" ]]; then die "Please give a name. Example: --name shop   (see --help)"; fi
  re='^[a-z][a-z0-9-]{1,18}[a-z0-9]$'
  if [[ ! "$NAME" =~ $re || "$NAME" == *--* ]]; then
    die "--name must be 3-20 characters: small letters, numbers and single dashes.
It must start with a letter and may not end with a dash. You gave: ${NAME}"
  fi

  # ---- environment and region ----
  re='^[a-z0-9]{2,10}$'
  if [[ ! "$ENV_NAME" =~ $re ]]; then
    die "--env must be 2-10 small letters or numbers, like dev or prod. You gave: ${ENV_NAME}"
  fi
  re='^[a-z0-9]+$'
  if [[ ! "$LOCATION" =~ $re ]]; then
    die "--location must be an Azure region written as one word, like eastus2 or westeurope.
You gave: ${LOCATION}   (see them all with: az account list-locations -o table)"
  fi

  # ---- IP base ----
  if [[ -z "$IP_BASE_INPUT" ]]; then die "Please give an IP base. Example: --ip-base 10.40   (see --help)"; fi
  local raw="$IP_BASE_INPUT" a b
  raw="${raw%/16}"      # also accept 10.40.0.0/16
  raw="${raw%.0.0}"     # also accept 10.40.0.0
  re='^([0-9]{1,3})\.([0-9]{1,3})$'
  if [[ ! "$raw" =~ $re ]]; then
    die "--ip-base must be the first two numbers of a private network, like 10.40
You gave: ${IP_BASE_INPUT}"
  fi
  a=$((10#${BASH_REMATCH[1]})); b=$((10#${BASH_REMATCH[2]}))
  if (( a == 172 && (b == 30 || b == 31) )); then
    die "172.30 and 172.31 are used by AKS itself. Please pick another --ip-base, like 172.20 or 10.40"
  fi
  if ! { (( a == 10 && b <= 255 )) || (( a == 172 && b >= 16 && b <= 29 )) || (( a == 192 && b == 168 )); }; then
    die "--ip-base must be a PRIVATE range so it never clashes with the real internet.
Allowed: 10.0 to 10.255, 172.16 to 172.29, or 192.168. You gave: ${IP_BASE_INPUT}"
  fi
  IP_BASE="${a}.${b}"

  # ---- numbers ----
  re='^[0-9]+$'
  if [[ ! "$SYSTEM_NODES" =~ $re ]];   then die "--system-nodes must be a whole number. You gave: ${SYSTEM_NODES}"; fi
  if [[ ! "$USER_NODES_MIN" =~ $re ]]; then die "--user-nodes-min must be a whole number. You gave: ${USER_NODES_MIN}"; fi
  if [[ ! "$USER_NODES_MAX" =~ $re ]]; then die "--user-nodes-max must be a whole number. You gave: ${USER_NODES_MAX}"; fi
  if (( SYSTEM_NODES < 1 || SYSTEM_NODES > 20 )); then die "--system-nodes must be between 1 and 20."; fi
  if (( USER_NODES_MIN < 1 )); then die "--user-nodes-min must be at least 1, or the front door has nowhere to run."; fi
  if (( USER_NODES_MAX < USER_NODES_MIN )); then
    die "--user-nodes-max (${USER_NODES_MAX}) cannot be smaller than --user-nodes-min (${USER_NODES_MIN})."
  fi
  if (( USER_NODES_MAX > 100 )); then die "--user-nodes-max above 100 is more than this script is meant for."; fi

  # ---- VM sizes ----
  re='^[A-Za-z0-9_]+$'
  if [[ ! "$NODE_SIZE" =~ $re || ! "$SYSTEM_NODE_SIZE" =~ $re ]]; then
    die "VM sizes look like Standard_D4ds_v5 (letters, numbers and underscores only)."
  fi

  # ---- tier ----
  case "$TIER" in
    free|standard) ;;
    *) die "--tier must be free or standard (you gave: ${TIER})." ;;
  esac

  # ---- disk type ----
  case "$DISK_SKU_INPUT" in
    ""|Premium_LRS|Premium_ZRS|StandardSSD_LRS|StandardSSD_ZRS) ;;
    *) die "--disk-sku must be Premium_LRS, Premium_ZRS, StandardSSD_LRS or StandardSSD_ZRS.
You gave: ${DISK_SKU_INPUT}" ;;
  esac

  # ---- zones: turn "1,2,3" or "1 2 3" into a tidy list ----
  local zone seen=" "
  ZONE_LIST=()
  if [[ "$ZONES" != "none" ]]; then
    for zone in ${ZONES//,/ }; do
      case "$zone" in
        1|2|3)
          if [[ "$seen" != *" ${zone} "* ]]; then ZONE_LIST+=("$zone"); seen="${seen}${zone} "; fi ;;
        *) die "--zones must be numbers from 1 to 3, like \"1 2 3\", or the word none. You gave: ${ZONES}" ;;
      esac
    done
  fi

  # ---- versions ----
  re='^[0-9]+\.[0-9]+(\.[0-9]+)?$'
  if [[ ! "$KUBERNETES_VERSION" =~ $re ]]; then
    die "--kubernetes-version looks like 1.36 or 1.36.2. You gave: ${KUBERNETES_VERSION}"
  fi
  re='^[0-9]+\.[0-9]+\.[0-9]+$'
  if [[ ! "$ISTIO_VERSION" =~ $re ]]; then
    die "--istio-version needs all three numbers, like 1.31.4. You gave: ${ISTIO_VERSION}"
  fi

  # ---- optional safety settings ----
  if [[ -n "$ADMIN_GROUP_ID" ]]; then
    re='^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
    if [[ ! "$ADMIN_GROUP_ID" =~ $re ]]; then
      die "--admin-group-id must be a group's Object ID (looks like 1a2b3c4d-1111-2222-3333-1a2b3c4d5e6f).
Find it with: az ad group show --group \"Group Name\" --query id -o tsv"
    fi
  fi
  if [[ -n "$API_ALLOWED_IPS" ]]; then
    API_ALLOWED_IPS="${API_ALLOWED_IPS// /}"
    re='^([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?(,([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?)*$'
    if [[ ! "$API_ALLOWED_IPS" =~ $re ]]; then
      die "--api-allowed-ips is a comma-separated list like 203.0.113.7/32,198.51.100.0/24
You gave: ${API_ALLOWED_IPS}"
    fi
  fi

  # ---- tags ----
  local tag
  TAGS=("project=${NAME}" "env=${ENV_NAME}" "created-by=create-aks.sh")
  for tag in ${EXTRA_TAGS//,/ }; do
    re='^[A-Za-z0-9_.-]+=[^[:space:]]*$'
    if [[ ! "$tag" =~ $re ]]; then die "Each tag must look like key=value. This one does not: ${tag}"; fi
    TAGS+=("$tag")
  done

  # ---- the Helm files must be next to this script ----
  local file
  for file in istio/istiod-values.yaml istio/gateway-values.yaml platform/Chart.yaml platform/values.yaml; do
    if [[ ! -f "${HELM_DIR}/${file}" ]]; then
      die "I can't find ${HELM_DIR}/${file}
Keep the helm folder in the same folder as this script."
    fi
  done
}

# Work out every name and every address range from --name, --env and --ip-base.
derive_names() {
  local base="${NAME}-${ENV_NAME}"

  # Azure's naming habit: a short prefix says what kind of thing it is.
  RG="rg-${base}"                       # rg   = resource group
  NODE_RG="rg-${base}-nodes"            # where AKS keeps the machines it manages
  CLUSTER="aks-${base}"                 # aks  = the cluster
  VNET="vnet-${base}"                   # vnet = virtual network
  SUBNET="snet-aks-nodes"               # snet = subnet (one slice of the network)
  IDENTITY="id-${base}-aks"             # id   = managed identity
  PIP="pip-${base}-ingress"             # pip  = public IP
  KUBE_CONTEXT="${CLUSTER}"             # the name kubectl and helm use for this cluster

  # ---- the address plan ----
  # The whole network: 65,536 addresses that all start with your two numbers.
  VNET_CIDR="${IP_BASE}.0.0/16"
  # The slice for the node computers: 4,096 addresses (x.x.0.0 to x.x.15.255).
  # Everything from x.x.16.0 upward stays free for things you add later.
  NODE_SUBNET_CIDR="${IP_BASE}.0.0/20"

  # Pods and services get addresses that exist ONLY inside the cluster.
  # They must not overlap your network, so we step aside if you picked the same.
  POD_CIDR="10.244.0.0/16"
  if [[ "$IP_BASE" == "10.244" ]]; then POD_CIDR="10.245.0.0/16"; fi
  SERVICE_CIDR="10.0.0.0/16"; DNS_SERVICE_IP="10.0.0.10"
  if [[ "$IP_BASE" == "10.0" ]]; then SERVICE_CIDR="10.1.0.0/16"; DNS_SERVICE_IP="10.1.0.10"; fi

  # Disks: with zones we want copies in three buildings (ZRS) so a disk can
  # follow its app to another zone. Without zones, three copies in one building (LRS).
  # --disk-sku overrides this choice.
  if [[ -n "$DISK_SKU_INPUT" ]]; then
    DISK_SKU="$DISK_SKU_INPUT"
  elif [[ ${#ZONE_LIST[@]} -gt 0 ]]; then
    DISK_SKU="Premium_ZRS"
  else
    DISK_SKU="Premium_LRS"
  fi
}

# =============================================================================
#  Getting ready
# =============================================================================

preflight() {
  printf '\n%s\n' "${C_BOLD}Getting ready${C_OFF}"

  # ---- are the tools installed? ----
  local -a missing=()
  local tool
  for tool in az kubectl helm kubelogin; do
    if ! command -v "$tool" >/dev/null 2>&1; then missing+=("$tool"); fi
  done
  if [[ ${#missing[@]} -gt 0 ]]; then
    if [[ "$DRY_RUN" == true ]]; then
      note "Not installed here: ${missing[*]}  (that is fine for a dry run)"
    else
      die "These tools are missing: ${missing[*]}
The easy fix: run this script in Azure Cloud Shell (https://shell.azure.com),
which has all four. Or install them: az and helm from their websites, then
'az aks install-cli' adds kubectl and kubelogin."
    fi
  else
    ok "Found az, kubectl, helm and kubelogin"
  fi

  # ---- dry run: do not talk to Azure at all ----
  if [[ "$DRY_RUN" == true ]]; then
    local guid_re='^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$'
    SUBSCRIPTION_ID="YOUR-SUBSCRIPTION-ID"
    if [[ "$SUBSCRIPTION" =~ $guid_re ]]; then SUBSCRIPTION_ID="$SUBSCRIPTION"; fi
    SUBSCRIPTION_NAME="${SUBSCRIPTION:-(not checked in a dry run)}"
    return 0
  fi

  # ---- is the Azure CLI new enough? ----
  local az_version
  az_version="$(az version --query '"azure-cli"' --output tsv 2>/dev/null | tr -d '\r' || true)"
  if [[ -n "$az_version" ]] && ! version_at_least "$az_version" "$OLDEST_OK_AZ_CLI"; then
    note "Your Azure CLI is ${az_version}. This script was tested with ${TESTED_AZ_CLI}."
    note "If a step says 'unrecognized arguments', update it with: az upgrade"
  fi

  # ---- are you signed in, and to which subscription? ----
  if ! az account show --output none 2>/dev/null; then
    die "You are not signed in to Azure. Run this first:  az login"
  fi
  if [[ -n "$SUBSCRIPTION" ]]; then
    SUBSCRIPTION_ID="$(az account show --subscription "$SUBSCRIPTION" --query id --output tsv 2>/dev/null | tr -d '\r' || true)"
    if [[ -z "$SUBSCRIPTION_ID" ]]; then
      die "I can't find the subscription '${SUBSCRIPTION}'. See yours with: az account list -o table"
    fi
  else
    SUBSCRIPTION_ID="$(az account show --query id --output tsv | tr -d '\r')"
  fi
  SUBSCRIPTION_NAME="$(az account show --subscription "$SUBSCRIPTION_ID" --query name --output tsv | tr -d '\r')"
  ok "Signed in. Using subscription: ${SUBSCRIPTION_NAME}"
}

# Switch on the Azure services we need. This is a one-time thing per
# subscription and costs nothing. It runs only after you have said yes.
enable_services() {
  if [[ "$DRY_RUN" == true ]]; then return 0; fi
  local service state
  for service in Microsoft.ContainerService Microsoft.Network Microsoft.Compute Microsoft.Storage Microsoft.ManagedIdentity; do
    state="$(az_get "Registered" provider show --namespace "$service" --query registrationState)"
    if [[ "$state" != "Registered" ]]; then
      info "Switching on the Azure service ${service} (one time only, can take a minute)..."
      az_do provider register --namespace "$service" --wait
    fi
  done
  ok "The Azure services we need are switched on"
}

show_plan() {
  local zones_label="none" admin_label="you (the signed-in account)" api_label="anywhere (login still required)"
  if [[ ${#ZONE_LIST[@]} -gt 0 ]]; then zones_label="${ZONE_LIST[*]}"; fi
  if [[ -n "$ADMIN_GROUP_ID" ]]; then admin_label="members of group ${ADMIN_GROUP_ID}"; fi
  if [[ -n "$API_ALLOWED_IPS" ]]; then api_label="only ${API_ALLOWED_IPS}"; fi

  printf '\n%s\n' "${C_BOLD}The plan${C_OFF}"
  cat <<EOF
  Subscription       ${SUBSCRIPTION_NAME}
  Region             ${LOCATION}
  Resource group     ${RG}
  Cluster            ${CLUSTER}   (Kubernetes ${KUBERNETES_VERSION}, ${TIER} tier, "${PROFILE}" preset)
  Network            ${VNET}   ${VNET_CIDR}
    nodes live in    ${NODE_SUBNET_CIDR}
    pods use         ${POD_CIDR}   (inside the cluster only)
    services use     ${SERVICE_CIDR}   (inside the cluster only)
  System nodes       ${SYSTEM_NODES} x ${SYSTEM_NODE_SIZE}
  App nodes          ${USER_NODES_MIN} to ${USER_NODES_MAX} x ${NODE_SIZE}   (grows and shrinks by itself)
  Zones              ${zones_label}
  Front door         Istio ${ISTIO_VERSION} gateway on the fixed address "${PIP}"
  Storage            ${DISK_SKU} disks. The storage class and volume claims
                     are listed in helm/platform/values.yaml
  Cluster admins     ${admin_label}
  API reachable from ${api_label}
EOF
  if [[ "$DRY_RUN" == true ]]; then
    printf '\n%s\n' "${C_YELLOW}DRY RUN:${C_OFF} nothing will be created. Below is every command a real run would use,"
    printf '%s\n' "shown as if nothing existed yet. Words in CAPITALS (like NEW-PUBLIC-IP) are only known in a real run."
  fi
}

confirm() {
  if [[ "$DRY_RUN" == true || "$ASSUME_YES" == true ]]; then return 0; fi
  if [[ ! -t 0 ]]; then
    die "This creates things that cost money, and nobody is at the keyboard to say yes.
Add --yes if you really want to run without being asked."
  fi
  local answer=""
  printf '\n%s' "This creates Azure resources that cost real money. Type ${C_BOLD}yes${C_OFF} to go ahead: "
  read -r answer
  if [[ "$answer" != "yes" ]]; then die "Okay, stopped. Nothing was created."; fi
}

# =============================================================================
#  The nine steps
# =============================================================================

step_resource_group() {
  step "Make the resource group" \
       "A resource group is a folder. Delete the folder later and everything in it goes too."
  if az_exists group show --name "$RG"; then
    ok "Resource group ${RG} already exists"
  else
    az_do group create --name "$RG" --location "$LOCATION" --tags "${TAGS[@]}"
    ok "Resource group ${RG} created"
  fi
}

step_network() {
  step "Build the private network" \
       "Like the hallways of a school: computers inside can reach each other, strangers outside cannot."

  if az_exists network vnet show --resource-group "$RG" --name "$VNET"; then
    # Make sure we are not about to mix two different address plans.
    local existing
    existing="$(az_get "$VNET_CIDR" network vnet show --resource-group "$RG" --name "$VNET" \
      --query "addressSpace.addressPrefixes[0]")"
    if [[ "$existing" != "$VNET_CIDR" ]]; then
      die "The network ${VNET} already exists with the range ${existing},
but --ip-base ${IP_BASE} means ${VNET_CIDR}.
Use the same --ip-base as last time, or choose a different --name."
    fi
    ok "Network ${VNET} already exists"
  else
    az_do network vnet create --resource-group "$RG" --name "$VNET" --location "$LOCATION" \
      --address-prefixes "$VNET_CIDR" --tags "${TAGS[@]}"
    ok "Network ${VNET} created (${VNET_CIDR})"
  fi

  if az_exists network vnet subnet show --resource-group "$RG" --vnet-name "$VNET" --name "$SUBNET"; then
    ok "Subnet ${SUBNET} already exists"
  else
    # "--default-outbound-access false" makes this a private subnet: the nodes
    # get no hidden way out to the internet. They leave through the cluster's
    # own load balancer, so every trip outside uses an address you can see.
    az_do network vnet subnet create --resource-group "$RG" --vnet-name "$VNET" --name "$SUBNET" \
      --address-prefixes "$NODE_SUBNET_CIDR" --default-outbound-access false
    ok "Subnet ${SUBNET} created (${NODE_SUBNET_CIDR})"
  fi

  SUBNET_ID="$(az_get "/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${RG}/providers/Microsoft.Network/virtualNetworks/${VNET}/subnets/${SUBNET}" \
    network vnet subnet show --resource-group "$RG" --vnet-name "$VNET" --name "$SUBNET" --query id)"
}

step_identity() {
  step "Give the cluster an ID badge" \
       "The cluster needs permission to plug into the network. A managed identity is a badge with no password to leak."

  if az_exists identity show --resource-group "$RG" --name "$IDENTITY"; then
    ok "Identity ${IDENTITY} already exists"
  else
    az_do identity create --resource-group "$RG" --name "$IDENTITY" --location "$LOCATION" --tags "${TAGS[@]}"
    ok "Identity ${IDENTITY} created"
  fi

  IDENTITY_ID="$(az_get "/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${RG}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${IDENTITY}" \
    identity show --resource-group "$RG" --name "$IDENTITY" --query id)"
  local badge_id rg_id
  badge_id="$(az_get "IDENTITY-OBJECT-ID" identity show --resource-group "$RG" --name "$IDENTITY" --query principalId)"
  rg_id="$(az_get "/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${RG}" group show --name "$RG" --query id)"

  # "Network Contributor" on our own folder lets the badge join the subnet
  # and attach the public IP. It cannot touch anything outside this folder.
  ensure_role "$badge_id" "ServicePrincipal" "Network Contributor" "$rg_id"
}

step_public_ip() {
  step "Reserve a public address that never changes" \
       "Like a street address for your front door. Because it is fixed, your website name can point at it forever."

  if az_exists network public-ip show --resource-group "$RG" --name "$PIP"; then
    ok "Public IP ${PIP} already exists"
  else
    local -a cmd=(network public-ip create --resource-group "$RG" --name "$PIP" --location "$LOCATION"
                  --sku Standard --allocation-method Static --version IPv4)
    # With zones, ask for an address that survives one data center going dark.
    # An address is either tied to ONE zone or spread over ALL of them, so we
    # always ask for all three here, whichever zones the nodes use.
    if [[ ${#ZONE_LIST[@]} -gt 0 ]]; then cmd+=(--zone 1 2 3); fi
    cmd+=(--tags "${TAGS[@]}")
    az_do "${cmd[@]}"
    ok "Public IP ${PIP} reserved"
  fi
  PIP_ADDRESS="$(az_get "NEW-PUBLIC-IP" network public-ip show --resource-group "$RG" --name "$PIP" --query ipAddress)"
  info "Your front door address: ${PIP_ADDRESS}"
}

step_cluster() {
  step "Create the AKS cluster" \
       "Azure runs the 'brain' of Kubernetes for you. This is the slow part: about 5 to 10 minutes."

  if az_exists aks show --resource-group "$RG" --name "$CLUSTER"; then
    ok "Cluster ${CLUSTER} already exists. Leaving its settings exactly as they are."
  else
    if [[ "$ROLE_CREATED" == true && "$DRY_RUN" != true ]]; then
      info "Giving Azure a minute to hand the new ID badge its permissions..."
      sleep 60
    fi

    local -a cmd=(aks create
      --resource-group "$RG"
      --name "$CLUSTER"
      --location "$LOCATION"
      --kubernetes-version "$KUBERNETES_VERSION"
      --tier "$TIER"
      --node-resource-group "$NODE_RG"
      # --- who the cluster is ---
      --assign-identity "$IDENTITY_ID"
      # --- networking: nodes sit in our subnet, pods get cluster-only addresses,
      #     and Cilium is the fast traffic engine that also enforces network rules ---
      --network-plugin azure
      --network-plugin-mode overlay
      --network-dataplane cilium
      --network-policy cilium
      --vnet-subnet-id "$SUBNET_ID"
      --pod-cidr "$POD_CIDR"
      --service-cidr "$SERVICE_CIDR"
      --dns-service-ip "$DNS_SERVICE_IP"
      # --- the first node pool: only for Kubernetes' own helpers ---
      --nodepool-name "$SYSTEM_POOL"
      --node-count "$SYSTEM_NODES"
      --node-vm-size "$SYSTEM_NODE_SIZE"
      --nodepool-taints CriticalAddonsOnly=true:NoSchedule
      # --- logins: use Microsoft Entra accounts, no shared admin password ---
      --enable-aad
      --enable-azure-rbac
      --disable-local-accounts
      --no-ssh-key
      # --- lets apps prove who they are to Azure without stored passwords ---
      --enable-oidc-issuer
      --enable-workload-identity
      # --- stay patched: small safe updates install themselves ---
      --auto-upgrade-channel patch
      --node-os-upgrade-channel NodeImage)
    if [[ ${#ZONE_LIST[@]} -gt 0 ]]; then cmd+=(--zones "${ZONE_LIST[@]}"); fi
    if [[ -n "$API_ALLOWED_IPS" ]]; then cmd+=(--api-server-authorized-ip-ranges "$API_ALLOWED_IPS"); fi
    cmd+=(--tags "${TAGS[@]}")

    az_do "${cmd[@]}"
    ok "Cluster ${CLUSTER} created"
  fi

  CLUSTER_ID="$(az_get "/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${RG}/providers/Microsoft.ContainerService/managedClusters/${CLUSTER}" \
    aks show --resource-group "$RG" --name "$CLUSTER" --query id)"
}

step_app_nodes() {
  step "Add worker nodes for your apps" \
       "System helpers and your apps get separate computers, so a busy app can never crowd out Kubernetes itself."

  if az_exists aks nodepool show --resource-group "$RG" --cluster-name "$CLUSTER" --name "$APPS_POOL"; then
    ok "Node pool ${APPS_POOL} already exists. Leaving it as it is."
  else
    local -a cmd=(aks nodepool add
      --resource-group "$RG"
      --cluster-name "$CLUSTER"
      --name "$APPS_POOL"
      --mode User
      --node-vm-size "$NODE_SIZE"
      --node-count "$USER_NODES_MIN"
      # The autoscaler adds nodes when apps need room and removes them when they don't.
      --enable-cluster-autoscaler
      --min-count "$USER_NODES_MIN"
      --max-count "$USER_NODES_MAX")
    if [[ ${#ZONE_LIST[@]} -gt 0 ]]; then cmd+=(--zones "${ZONE_LIST[@]}"); fi
    cmd+=(--tags "${TAGS[@]}")
    az_do "${cmd[@]}"
    ok "Node pool ${APPS_POOL} created"
  fi

  # Ask the real cluster whether it uses zones. This keeps the disk type right
  # even if you run the script again later with different options.
  # (Skipped when you chose a disk type yourself with --disk-sku.)
  if [[ "$DRY_RUN" != true && -z "$DISK_SKU_INPUT" ]]; then
    local live_zones
    live_zones="$(az_get "" aks show --resource-group "$RG" --name "$CLUSTER" \
      --query "agentPoolProfiles[?name=='${APPS_POOL}'] | [0].availabilityZones" | tr -d '[:space:]')"
    if [[ -n "$live_zones" ]]; then DISK_SKU="Premium_ZRS"; else DISK_SKU="Premium_LRS"; fi
  fi
}

step_access() {
  step "Get you a key to the cluster" \
       "Nobody can log in yet, not even you. We grant admin rights, then download the login settings."

  local who kind account_type login_name
  if [[ -n "$ADMIN_GROUP_ID" ]]; then
    who="$ADMIN_GROUP_ID"; kind="Group"
  elif [[ "$DRY_RUN" == true ]]; then
    who="YOUR-OBJECT-ID"; kind="User"
  else
    account_type="$(az account show --query user.type --output tsv | tr -d '\r')"
    if [[ "$account_type" == "user" ]]; then
      who="$(az ad signed-in-user show --query id --output tsv 2>/dev/null | tr -d '\r' || true)"; kind="User"
    else
      # A robot account (service principal), as used by CI pipelines.
      login_name="$(az account show --query user.name --output tsv | tr -d '\r')"
      who="$(az ad sp show --id "$login_name" --query id --output tsv 2>/dev/null | tr -d '\r' || true)"; kind="ServicePrincipal"
    fi
    if [[ -z "$who" ]]; then
      die "I could not work out which account you are signed in with.
Run again with --admin-group-id and the Object ID of a group you belong to."
    fi
  fi
  ensure_role "$who" "$kind" "Azure Kubernetes Service RBAC Cluster Admin" "$CLUSTER_ID"

  # Save the login settings under the name ${KUBE_CONTEXT}. Every kubectl and
  # helm command below names that context, so they can never hit another cluster.
  run az aks get-credentials --resource-group "$RG" --name "$CLUSTER" \
    --context "$KUBE_CONTEXT" --overwrite-existing --subscription "$SUBSCRIPTION_ID"
  # Tell kubectl to reuse your 'az login' instead of opening a browser each time.
  run kubelogin convert-kubeconfig --login azurecli --context "$KUBE_CONTEXT"

  if [[ "$DRY_RUN" == true ]]; then return 0; fi

  info "Waiting for the new permission to reach the cluster (up to 5 minutes)..."
  local tries=0
  until kubectl --context "$KUBE_CONTEXT" get nodes >/dev/null 2>&1; do
    tries=$((tries + 1))
    if [[ "$tries" -ge 30 ]]; then
      die "The cluster still says no. Two things to check:
  1. If you used --admin-group-id, are you a member of that group?
  2. If you used --api-allowed-ips, is this computer's address in the list?
Then run the same command again. To see the real error:
  kubectl --context ${KUBE_CONTEXT} get nodes"
    fi
    sleep 10
  done
  ok "You can talk to the cluster"
}

step_istio() {
  step "Install Istio and its gateway (the front door)" \
       "Istio is the traffic system. Its gateway is the single guarded door where visitors enter."

  # Part 1: the rule book. Teaches Kubernetes Istio's new words (like "Gateway").
  run helm upgrade --install istio-base base \
    --repo "$ISTIO_CHART_REPO" --version "$ISTIO_VERSION" \
    --namespace "$ISTIO_SYSTEM_NS" --create-namespace \
    --kube-context "$KUBE_CONTEXT" \
    --wait --timeout 5m

  # Part 2: the brain (istiod). It hands out the traffic rules.
  run helm upgrade --install istiod istiod \
    --repo "$ISTIO_CHART_REPO" --version "$ISTIO_VERSION" \
    --namespace "$ISTIO_SYSTEM_NS" \
    --kube-context "$KUBE_CONTEXT" \
    --values "${HELM_DIR}/istio/istiod-values.yaml" \
    --wait --timeout 10m

  # Part 3: the door itself. First write a tiny settings file that tells Azure
  # "use the fixed address from step 4". These two lines are Azure's official
  # labels for that job.
  local azure_values="${TMP_DIR}/gateway-azure-values.yaml"
  cat > "$azure_values" <<EOF
service:
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-resource-group: "${RG}"
    service.beta.kubernetes.io/azure-pip-name: "${PIP}"
EOF
  if [[ "$DRY_RUN" == true ]]; then
    info "The script writes this small file and passes it to Helm below:"
    sed 's/^/        /' "$azure_values"
  fi

  run helm upgrade --install "$GATEWAY_RELEASE" gateway \
    --repo "$ISTIO_CHART_REPO" --version "$ISTIO_VERSION" \
    --namespace "$ISTIO_INGRESS_NS" --create-namespace \
    --kube-context "$KUBE_CONTEXT" \
    --values "${HELM_DIR}/istio/gateway-values.yaml" \
    --values "$azure_values" \
    --wait --timeout 10m

  if [[ "$DRY_RUN" == true ]]; then return 0; fi

  # Check the door really got the fixed address.
  local door_ip
  door_ip="$(kubectl --context "$KUBE_CONTEXT" --namespace "$ISTIO_INGRESS_NS" get service "$GATEWAY_RELEASE" \
    --output jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
  if [[ "$door_ip" == "$PIP_ADDRESS" ]]; then
    ok "The gateway is listening on ${PIP_ADDRESS}"
  else
    note "The gateway reports the address '${door_ip:-none yet}', but ${PIP_ADDRESS} was expected."
    note "See why with: kubectl --context ${KUBE_CONTEXT} -n ${ISTIO_INGRESS_NS} describe service ${GATEWAY_RELEASE}"
  fi
}

step_platform() {
  step "Add rooms and storage for future apps" \
       "Our own small Helm chart: a Gateway sign for the door, namespaces (rooms) and volume claims (locker reservations)."

  # No --wait here on purpose: the volume claims stay "Pending" until an app
  # uses them, so waiting would never finish. That is normal, and it costs nothing.
  run helm upgrade --install "$PLATFORM_RELEASE" "${HELM_DIR}/platform" \
    --namespace "$PLATFORM_NS" --create-namespace \
    --kube-context "$KUBE_CONTEXT" \
    --set-string "storageClass.skuName=${DISK_SKU}"
  ok "Platform chart applied"
}

show_summary() {
  if [[ "$DRY_RUN" == true ]]; then
    printf '\n%s\n' "${C_BOLD}End of dry run.${C_OFF} Nothing was changed. Remove --dry-run to build it for real."
    return 0
  fi
  printf '\n%s\n' "${C_GREEN}${C_BOLD}All done.${C_OFF}"
  cat <<EOF

  Cluster          ${CLUSTER}   (resource group ${RG})
  Front door IP    ${PIP_ADDRESS}
  kubectl context  ${KUBE_CONTEXT}

  Have a look around:
    kubectl --context ${KUBE_CONTEXT} get nodes
    kubectl --context ${KUBE_CONTEXT} get pods -n ${ISTIO_SYSTEM_NS}
    kubectl --context ${KUBE_CONTEXT} get service -n ${ISTIO_INGRESS_NS}
    kubectl --context ${KUBE_CONTEXT} get storageclass,pvc -A

  Good to know:
    * The volume claims show "Pending". That is correct: Azure makes the disk
      (and starts charging for it) only when the first app uses the claim.
    * The gateway answers on plain HTTP until you add a certificate.
      Turn on HTTPS before real users arrive. README.md shows how.
    * To take it all down later:  ./destroy-aks.sh --name ${NAME} --env ${ENV_NAME}
EOF
}

# =============================================================================
#  Run it
# =============================================================================

main() {
  parse_args "$@"
  apply_defaults
  validate_inputs
  derive_names
  preflight
  show_plan
  confirm
  enable_services

  TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/create-aks.XXXXXX")"

  step_resource_group
  step_network
  step_identity
  step_public_ip
  step_cluster
  step_app_nodes
  step_access
  step_istio
  step_platform
  show_summary
}

main "$@"
