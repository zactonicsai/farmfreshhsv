{{/*
  Helpers are small snippets that other templates reuse, so we write them once.

  "platform.labels" is the set of name tags we put on everything this chart
  makes. They let you find it all later with:
      kubectl get all,pvc,ns,sc -A -l app.kubernetes.io/part-of=platform
*/}}
{{- define "platform.labels" -}}
app.kubernetes.io/part-of: platform
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}
