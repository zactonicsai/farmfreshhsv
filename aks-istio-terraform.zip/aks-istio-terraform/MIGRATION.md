# Moving from the Bash/Azure CLI edition to Terraform

This is a **new project and state**, not an in-place import of any cluster previously created with Bash. **Never point it at an existing production cluster and apply without first planning import and resource ownership.** If you have an existing AKS environment, use `terraform import` with explicit resource IDs and carefully reconcile state; do not recreate it accidentally.

| Original intention | Terraform location | Why this way |
|---|---|---|
| `01-create-cluster.sh` | `infra/main.tf`, `infra/modules/network/` and `infra/modules/aks/` | Desired state instead of one-time imperative commands |
| `02-enable-istio.sh` | AKS `service_mesh_profile` in `infra/modules/aks/main.tf` | Let Azure manage Istio and ingress |
| `03-install-storage.sh` | `platform/helm_release.storage_classes` | StorageClass definitions managed as a Helm release |
| `04-deploy-demo.sh` | `platform/helm_release.hello` (opt-in) | Istio routing defined with local Helm chart |
| `05-verify.sh` | `./scripts/lab.sh verify` | Inspect active nodes, gateway, classes, claims |
| `06-destroy.sh` | `./scripts/lab.sh destroy --confirm-destroy NAME` | Delete platform resources before infrastructure |
| `07-create-volume.sh` | `--postgres-pvc`, `--keycloak-pvc` in `platform` | Volume claims optional and separately configured |
| `08-add-user-pool.sh` | `--user-pool` option | Optional Terraform node pool for future apps |

## A key distinction: Terraform state

The original scripts performed Azure CLI operations. Terraform tracks objects it creates in its state file. It won't automatically know that an object created earlier by an unrelated script is already part of its managed resources.

Best approach for a new lab: choose **a new cluster name, resource group and IP base** and run `./scripts/lab.sh plan`. For an existing cluster, use carefully reviewed imports and an experienced Azure/Terraform operator; don't blindly apply this starter.

## Why no `helm install istio`?

The AKS-managed Istio add-on installs the Istio control plane and gateway service. The `charts/hello-istio` Gateway and VirtualService objects only tell that ingress how to forward HTTP requests. Duplicating the control plane with upstream Helm charts can introduce ownership and compatibility conflicts.
