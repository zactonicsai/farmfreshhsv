# Stage 2 runs ONLY after stage 1 has installed the AKS-managed Istio CRDs.
# Helm is used for our resources; do NOT install a second Istio control plane.
resource "helm_release" "storage_classes" {
  name             = "foundation-storage"
  namespace        = "platform-system"
  create_namespace = true
  chart            = "${path.module}/../charts/storage-classes"
  atomic           = true
  wait             = true
  timeout          = 300
}

# Claims are off by default to avoid allocating billable Azure storage.
# When turned on, the PVC starts Pending until a workload mounts it because
# the disk StorageClass uses WaitForFirstConsumer.
resource "helm_release" "postgres_volume" {
  count            = var.create_postgres_pvc ? 1 : 0
  name             = "postgres-volume"
  namespace        = "databases"
  create_namespace = true
  chart            = "${path.module}/../charts/service-volumes"
  atomic           = true
  wait             = false
  values = [yamlencode({
    claims = {
      postgres = {
        enabled          = true
        name             = "postgres-data"
        size             = var.postgres_storage_size
        storageClassName = "aks-disk-standard-retain"
        accessModes      = ["ReadWriteOnce"]
      }
      keycloak = { enabled = false }
    }
  })]
  depends_on = [helm_release.storage_classes]
}

# Optional shared assets ONLY. Keycloak user/account data goes in Postgres.
resource "helm_release" "keycloak_volume" {
  count            = var.create_keycloak_pvc ? 1 : 0
  name             = "keycloak-volume"
  namespace        = "identity"
  create_namespace = true
  chart            = "${path.module}/../charts/service-volumes"
  atomic           = true
  wait             = false
  values = [yamlencode({
    claims = {
      postgres = { enabled = false }
      keycloak = {
        enabled          = true
        name             = "keycloak-themes"
        size             = var.keycloak_storage_size
        storageClassName = "aks-file-retain"
        accessModes      = ["ReadWriteMany"]
      }
    }
  })]
  depends_on = [helm_release.storage_classes]
}

# The HTTP demo is intentionally opt-in; production gateways need HTTPS.
resource "helm_release" "hello" {
  count            = var.enable_demo ? 1 : 0
  name             = "hello-istio"
  namespace        = "demo"
  create_namespace = true
  chart            = "${path.module}/../charts/hello-istio"
  atomic           = true
  wait             = true
  values = [yamlencode({
    gateway = {
      type = var.gateway_type
      host = var.demo_host
    }
  })]
  lifecycle {
    precondition {
      condition     = var.gateway_type != "external" || var.demo_host != "*"
      error_message = "For an external gateway set a specific demo_host; do not expose the wildcard HTTP demo to the entire Internet."
    }
  }
  depends_on = [helm_release.storage_classes]
}
