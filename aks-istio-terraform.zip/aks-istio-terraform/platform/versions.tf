terraform {
  required_version = ">= 1.8.0"
  required_providers {
    helm = {
      source  = "hashicorp/helm"
      version = ">= 3.0.0, < 4.0.0"
    }
  }
}

# The Helm provider 3.x uses an OBJECT, not the old 'kubernetes { }' block.
# Azure CLI + kubelogin establish Kubernetes credentials BEFORE stage 2.
provider "helm" {
  kubernetes = {
    config_path    = pathexpand(var.kubeconfig_path)
    config_context = var.kube_context
  }
}
