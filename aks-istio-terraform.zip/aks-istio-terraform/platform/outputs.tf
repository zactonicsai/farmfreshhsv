output "gateway_service_name" {
  value = "aks-istio-ingressgateway-${var.gateway_type}"
}
output "gateway_namespace" {
  value = "aks-istio-ingress"
}
output "storage_class_names" {
  value = ["aks-disk-standard-retain", "aks-disk-premium-retain", "aks-file-retain"]
}
output "optional_pvc_namespaces" {
  value = { postgres = "databases", keycloak = "identity" }
}
