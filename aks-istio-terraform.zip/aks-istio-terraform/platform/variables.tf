variable "kubeconfig_path" {
  description = "Absolute kubeconfig path created with az aks get-credentials."
  type        = string
  default     = "~/.kube/config"
}
variable "kube_context" {
  description = "Name of the current AKS context (normally cluster name)."
  type        = string
}
variable "gateway_type" {
  type    = string
  default = "internal"
  validation {
    condition     = contains(["internal", "external"], var.gateway_type)
    error_message = "Must be internal or external."
  }
}
variable "demo_host" {
  description = "HTTP Host header for demo; use an FQDN when using public ingress."
  type        = string
  default     = "*"
}
variable "enable_demo" {
  type    = bool
  default = false
}
variable "create_postgres_pvc" {
  type    = bool
  default = false
}
variable "create_keycloak_pvc" {
  type    = bool
  default = false
}
variable "postgres_storage_size" {
  type    = string
  default = "20Gi"
  validation {
    condition     = can(regex("^[1-9][0-9]*Gi$", var.postgres_storage_size))
    error_message = "Use Gi sizes such as 20Gi."
  }
}
variable "keycloak_storage_size" {
  type    = string
  default = "5Gi"
  validation {
    condition     = can(regex("^[1-9][0-9]*Gi$", var.keycloak_storage_size))
    error_message = "Use Gi sizes such as 5Gi."
  }
}
