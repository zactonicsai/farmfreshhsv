output "cluster_name" {
  value       = module.aks.cluster_name
  description = "Pass this to 'az aks get-credentials'."
}
output "resource_group_name" {
  value = azurerm_resource_group.foundation.name
}
output "vnet_cidr" { value = local.vnet_cidr }
output "node_subnet_cidr" { value = local.nodes_cidr }
output "pod_cidr" { value = local.pods_cidr }
output "service_cidr" { value = local.service_cidr }
output "dns_ip" { value = local.dns_ip }
output "gateway_type" { value = var.gateway_type }
output "oidc_issuer_url" { value = module.aks.oidc_issuer_url }
output "kubelet_identity_object_id" { value = module.aks.kubelet_identity_object_id }
output "aks_id" { value = module.aks.aks_id }
output "connect_command" {
  value = "az aks get-credentials --resource-group ${azurerm_resource_group.foundation.name} --name ${module.aks.cluster_name} --overwrite-existing"
}

output "workload_node_pool_enabled" { value = var.workload_pool_enabled }
