terraform {
  required_version = ">= 1.8.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.59.0, < 5.0.0"
    }
  }
}

# Terraform needs the subscription explicitly with AzureRM 4.x.
# The configuration generator supplies it after 'az login'.
provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}
