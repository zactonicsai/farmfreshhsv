# Stage 1: Azure infrastructure only. Do NOT put Helm/Kubernetes resources here.
# Provider bootstrapping is reliable because we install add-ons in Stage 2.

data "azurerm_client_config" "current" {}

locals {
  second_octet = tonumber(split(".", var.ip_base)[1])
  vnet_cidr    = "10.${local.second_octet}.0.0/16"
  nodes_cidr   = "10.${local.second_octet}.0.0/22"
  pods_cidr    = "10.${local.second_octet + 1}.0.0/16"
  service_cidr = "10.${local.second_octet + 2}.0.0/16"
  dns_ip       = "10.${local.second_octet + 2}.0.10"
}

resource "azurerm_resource_group" "foundation" {
  name     = var.resource_group_name
  location = var.location
  tags     = var.tags
}

module "network" {
  source              = "./modules/network"
  resource_group_name = azurerm_resource_group.foundation.name
  location            = azurerm_resource_group.foundation.location
  cluster_name        = var.cluster_name
  vnet_cidr           = local.vnet_cidr
  nodes_cidr          = local.nodes_cidr
  tags                = var.tags
}

module "aks" {
  source              = "./modules/aks"
  cluster_name        = var.cluster_name
  resource_group_name = azurerm_resource_group.foundation.name
  location            = azurerm_resource_group.foundation.location
  vnet_id             = module.network.vnet_id
  nodes_subnet_id     = module.network.nodes_subnet_id
  pods_cidr           = local.pods_cidr
  service_cidr        = local.service_cidr
  dns_ip              = local.dns_ip
  gateway_type        = var.gateway_type
  private_cluster     = var.private_cluster
  authorized_ip_ranges = var.authorized_ip_ranges
  node_min            = var.node_min
  node_max            = var.node_max
  vm_size             = var.vm_size
  workload_pool_enabled = var.workload_pool_enabled
  workload_node_min  = var.workload_node_min
  workload_node_max  = var.workload_node_max
  workload_vm_size   = var.workload_vm_size
  zones               = var.zones
  kubernetes_version  = var.kubernetes_version
  sku_tier            = var.sku_tier
  tenant_id           = data.azurerm_client_config.current.tenant_id
  admin_group_object_ids = var.admin_group_object_ids
  current_principal_object_id = data.azurerm_client_config.current.object_id
  grant_current_principal_cluster_admin = var.grant_current_principal_cluster_admin
  enable_monitoring   = var.enable_monitoring
  tags                = var.tags
}

# Do not add an extra ingress controller. Azure already installs/manages Istio.
