variable "subscription_id" {
  description = "Azure subscription ID; never a password."
  type        = string
  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "Use a valid Azure subscription UUID."
  }
}

variable "cluster_name" {
  description = "Name of the Kubernetes school/campus."
  type        = string
  default     = "aks-school-lab"
  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9-]{1,50}[a-zA-Z0-9]$", var.cluster_name))
    error_message = "Cluster name must be 3-52 characters: letters, numbers or hyphens; start with a letter."
  }
}

variable "resource_group_name" {
  type    = string
  default = "rg-aks-school-lab"
  validation {
    condition     = can(regex("^[a-zA-Z0-9_.()-]{1,90}$", var.resource_group_name))
    error_message = "Use a valid Azure resource-group name (max 90 characters)."
  }
}

variable "location" {
  description = "Azure region that supports AKS, the selected VM size and Istio add-on."
  type        = string
  default     = "eastus2"
}

variable "ip_base" {
  description = "First two octets, e.g. 10.90 => VNet 10.90, pods 10.91, services 10.92."
  type        = string
  default     = "10.90"
  validation {
    condition = can(regex("^10\\.([0-9]{1,3})$", var.ip_base)) && (
      try(tonumber(split(".", var.ip_base)[1]), 999) >= 0 &&
      try(tonumber(split(".", var.ip_base)[1]), 999) <= 253
    )
    error_message = "ip_base must be 10.X, where X is between 0 and 253 (e.g. 10.90)."
  }
}

variable "gateway_type" {
  description = "Internal gateway has a private load-balancer IP; external has a public IP."
  type        = string
  default     = "internal"
  validation {
    condition     = contains(["internal", "external"], var.gateway_type)
    error_message = "gateway_type must be internal or external."
  }
}

variable "private_cluster" {
  description = "Private Kubernetes API. Requires access through the VNet/VPN/jump box."
  type        = bool
  default     = false
}

variable "authorized_ip_ranges" {
  description = "Optional public API allow-list, e.g. [\"198.51.100.5/32\"]. Empty = public AKS API endpoint not IP restricted."
  type        = list(string)
  default     = []
  validation {
    condition     = alltrue([for cidr in var.authorized_ip_ranges : can(cidrhost(cidr, 0))])
    error_message = "Each authorized IP range must be a CIDR value."
  }
}

variable "node_min" {
  type    = number
  default = 2
  validation {
    condition     = var.node_min >= 1 && var.node_min <= 100 && floor(var.node_min) == var.node_min
    error_message = "node_min must be an integer between 1 and 100."
  }
}

variable "node_max" {
  type    = number
  default = 3
  validation {
    condition     = var.node_max >= 1 && var.node_max <= 100 && floor(var.node_max) == var.node_max
    error_message = "node_max must be an integer between 1 and 100."
  }
}

variable "workload_pool_enabled" {
  description = "Optional second user node pool for Keycloak/Postgres and other applications (extra VM cost)."
  type        = bool
  default     = false
}
variable "workload_node_min" {
  type    = number
  default = 1
}
variable "workload_node_max" {
  type    = number
  default = 2
}
variable "workload_vm_size" {
  type    = string
  default = "Standard_D2s_v5"
}

variable "vm_size" {
  type    = string
  default = "Standard_D2s_v5"
}

variable "kubernetes_version" {
  description = "Optional supported AKS version, e.g. 1.34. Leave null to use Azure's current supported default."
  type        = string
  default     = null
}

variable "sku_tier" {
  description = "AKS control-plane tier; Free for lab, Standard for uptime SLA."
  type        = string
  default     = "Free"
  validation {
    condition     = contains(["Free", "Standard", "Premium"], var.sku_tier)
    error_message = "Choose Free, Standard or Premium."
  }
}

variable "zones" {
  description = "Optional AZs such as [\"1\", \"2\", \"3\"], only where supported."
  type        = list(string)
  default     = []
}

variable "admin_group_object_ids" {
  description = "Optional Entra group object IDs to grant cluster admin access."
  type        = list(string)
  default     = []
}

variable "grant_current_principal_cluster_admin" {
  description = "Grants the Terraform caller Azure Kubernetes Service RBAC Cluster Admin."
  type        = bool
  default     = true
}

variable "enable_monitoring" {
  description = "Log Analytics can incur costs; disabled for an inexpensive learning lab."
  type        = bool
  default     = false
}

variable "tags" {
  type = map(string)
  default = {
    project     = "aks-istio-foundation"
    environment = "lab"
    managed-by  = "terraform"
  }
}
