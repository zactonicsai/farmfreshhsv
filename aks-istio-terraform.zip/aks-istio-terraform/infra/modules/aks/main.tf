# First create a user-assigned identity (the school's staff badge).
# Unlike a system-assigned identity, its RBAC permissions can be created
# BEFORE AKS needs to join the network.
resource "azurerm_user_assigned_identity" "control_plane" {
  name                = "id-${var.cluster_name}-control"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_role_assignment" "network" {
  scope                = var.vnet_id
  role_definition_name = "Network Contributor"
  principal_id         = azurerm_user_assigned_identity.control_plane.principal_id
  principal_type       = "ServicePrincipal"
}

# Optional billing-based monitoring (default off to reduce lab cost).
resource "azurerm_log_analytics_workspace" "this" {
  count               = var.enable_monitoring ? 1 : 0
  name                = "log-${var.cluster_name}"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = 30
  tags                = var.tags
}

resource "azurerm_kubernetes_cluster" "this" {
  name                = var.cluster_name
  location            = var.location
  resource_group_name = var.resource_group_name
  dns_prefix          = var.cluster_name
  kubernetes_version  = var.kubernetes_version
  sku_tier            = var.sku_tier
  tags                = var.tags

  # Built-in Entra authentication; no static admin kubeconfig account.
  role_based_access_control_enabled = true
  local_account_disabled            = true
  azure_active_directory_role_based_access_control {
    tenant_id              = var.tenant_id
    azure_rbac_enabled     = true
    admin_group_object_ids = var.admin_group_object_ids
  }

  # Workload Identity allows future apps to authenticate to Azure with
  # federated identities rather than storing Azure passwords in pods.
  oidc_issuer_enabled       = true
  workload_identity_enabled = true

  # Default gateway is private. Private API is a separate setting.
  private_cluster_enabled = var.private_cluster

  dynamic "api_server_access_profile" {
    for_each = length(var.authorized_ip_ranges) > 0 ? [1] : []
    content {
      authorized_ip_ranges = var.authorized_ip_ranges
    }
  }

  identity {
    type         = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.control_plane.id]
  }

  # Managed node pools with familiar autoscaler, not node-autoprovisioning.
  node_provisioning_profile {
    mode = "Manual"
  }

  default_node_pool {
    name                         = "system"
    vm_size                      = var.vm_size
    node_count                   = var.node_min
    min_count                    = var.node_min
    max_count                    = var.node_max
    auto_scaling_enabled         = true
    vnet_subnet_id               = var.nodes_subnet_id
    type                         = "VirtualMachineScaleSets"
    os_disk_size_gb              = 64
    node_public_ip_enabled       = false
    max_pods                     = 30
    zones                        = length(var.zones) == 0 ? null : var.zones
    temporary_name_for_rotation  = "sysrotate"

    upgrade_settings {
      max_surge = "33%"
    }
  }

  # Azure CNI Overlay: pod IPs are in their own school hallway, not pulled
  # directly from the VNet subnet. Cilium enforces Kubernetes NetworkPolicy.
  network_profile {
    network_plugin      = "azure"
    network_plugin_mode = "overlay"
    network_policy      = "cilium"
    network_data_plane  = "cilium"
    pod_cidr            = var.pods_cidr
    service_cidr        = var.service_cidr
    dns_service_ip      = var.dns_ip
    load_balancer_sku   = "standard"
    outbound_type       = "loadBalancer"
  }

  # Azure manages Istio itself. Do NOT helm install istiod or Envoy here.
  service_mesh_profile {
    mode                             = "Istio"
    revisions                        = [] # Azure selects a supported revision on first creation.
    internal_ingress_gateway_enabled = var.gateway_type == "internal"
    external_ingress_gateway_enabled = var.gateway_type == "external"
  }

  # CSI drivers let apps create persistent disk/file volumes on demand.
  storage_profile {
    disk_driver_enabled        = true
    file_driver_enabled        = true
    snapshot_controller_enabled = true
  }

  dynamic "oms_agent" {
    for_each = var.enable_monitoring ? [1] : []
    content {
      log_analytics_workspace_id = azurerm_log_analytics_workspace.this[0].id
    }
  }

  automatic_upgrade_channel = "patch"
  node_os_upgrade_channel   = "NodeImage"

  lifecycle {
    # AKS autoscaler adjusts node count: do not fight its changes on each plan.
    ignore_changes = [default_node_pool[0].node_count]
    precondition {
      condition     = var.node_min <= var.node_max
      error_message = "node_min must be less than or equal to node_max."
    }
    precondition {
      condition     = !var.private_cluster || length(var.authorized_ip_ranges) == 0
      error_message = "authorized_ip_ranges is for a public API only; remove it for a private cluster."
    }
  }

  depends_on = [azurerm_role_assignment.network]
}

# Azure RBAC authorization: the Terraform operator can administer the lab.
# Requires 'User Access Administrator' or 'Owner' to create role assignments.
resource "azurerm_role_assignment" "operator_admin" {
  count                = var.grant_current_principal_cluster_admin ? 1 : 0
  scope                = azurerm_kubernetes_cluster.this.id
  role_definition_name = "Azure Kubernetes Service RBAC Cluster Admin"
  principal_id         = var.current_principal_object_id
}

resource "azurerm_role_assignment" "group_admin" {
  for_each             = toset(var.admin_group_object_ids)
  scope                = azurerm_kubernetes_cluster.this.id
  role_definition_name = "Azure Kubernetes Service RBAC Cluster Admin"
  principal_id         = each.value
  principal_type       = "Group"
}

# Optional second classroom wing reserved for user applications.
# Disabled by default to avoid extra VM charges; production separation is helpful.
resource "azurerm_kubernetes_cluster_node_pool" "workloads" {
  count                 = var.workload_pool_enabled ? 1 : 0
  name                  = "users"
  kubernetes_cluster_id = azurerm_kubernetes_cluster.this.id
  vm_size               = var.workload_vm_size
  mode                  = "User"
  node_count            = var.workload_node_min
  min_count             = var.workload_node_min
  max_count             = var.workload_node_max
  auto_scaling_enabled  = true
  vnet_subnet_id        = var.nodes_subnet_id
  node_public_ip_enabled = false
  os_disk_size_gb       = 64
  max_pods              = 30
  zones                 = length(var.zones) == 0 ? null : var.zones

  upgrade_settings {
    max_surge = "33%"
  }

  lifecycle {
    ignore_changes = [node_count]
    precondition {
      condition     = var.workload_node_min >= 1 && var.workload_node_min <= var.workload_node_max && var.workload_node_max <= 100
      error_message = "workload node minimum must be 1..workload node maximum, with max <= 100."
    }
  }
  tags = var.tags
}
