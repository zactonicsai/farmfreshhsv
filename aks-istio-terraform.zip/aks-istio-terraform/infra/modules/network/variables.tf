variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "cluster_name" { type = string }
variable "vnet_cidr" { type = string }
variable "nodes_cidr" { type = string }
variable "tags" { type = map(string) }
