# The campus (VNet) and a dedicated section for AKS machines (node subnet).
resource "azurerm_virtual_network" "this" {
  name                = "vnet-${var.cluster_name}"
  resource_group_name = var.resource_group_name
  location            = var.location
  address_space       = [var.vnet_cidr]
  tags                = var.tags
}

resource "azurerm_subnet" "nodes" {
  name                 = "snet-aks-nodes"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = [var.nodes_cidr]
}
