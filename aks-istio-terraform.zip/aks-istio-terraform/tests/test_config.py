#!/usr/bin/env python3
"""Offline functional checks for argument processing and network validation."""
import copy
import importlib.util
import ipaddress
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('configure', ROOT / 'scripts' / 'configure.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def should_fail(c, reason):
    try:
        mod.validate(c)
    except ValueError:
        return
    raise AssertionError(f'Expected invalid configuration to fail: {reason}')


def run():
    d = copy.deepcopy(mod.DEFAULTS)
    d['subscription_id'] = '00000000-0000-0000-0000-000000000001'
    mod.validate(d)
    for base in ('10.0', '10.90', '10.110', '10.253'):
        c = copy.deepcopy(d)
        c['ip_base'] = base
        mod.validate(c)
        n = int(base.split('.')[1])
        assert ipaddress.ip_network(f'10.{n}.0.0/22').subnet_of(
            ipaddress.ip_network(f'10.{n}.0.0/16'))
        assert not ipaddress.ip_network(f'10.{n}.0.0/16').overlaps(
            ipaddress.ip_network(f'10.{n+1}.0.0/16'))
        assert not ipaddress.ip_network(f'10.{n+1}.0.0/16').overlaps(
            ipaddress.ip_network(f'10.{n+2}.0.0/16'))
    for bad in ['10.254', '10.255', '11.10', '10.256', 'hello', '10.2.3']:
        c = copy.deepcopy(d)
        c['ip_base'] = bad
        should_fail(c, bad)
    c = copy.deepcopy(d); c['node_min'] = 4; c['node_max'] = 2
    should_fail(c, 'node min > node max')
    c = copy.deepcopy(d); c['workload_node_min']=5; c['workload_node_max']=2
    should_fail(c, 'invalid workload autoscaling')
    c = copy.deepcopy(d); c['private_cluster'] = True; c['authorized_ip_ranges'] = ['198.51.100.7/32']
    should_fail(c, 'private + authorized ranges')
    c = copy.deepcopy(d); c['gateway_type'] = 'external'; c['enable_demo'] = True
    should_fail(c, 'wildcard external demo')
    c['demo_host'] = 'hello.example.org'; mod.validate(c)
    c = copy.deepcopy(d); c['postgres_storage_size'] = 'wrong'
    should_fail(c, 'invalid PVC size')
    print('PASS: network CIDR, bad inputs, node bounds, private API and demo safety')


if __name__ == '__main__':
    run()
