#!/usr/bin/env bash
# No Azure or Terraform is required for these tests. They don't spend money.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
bash -n "$ROOT/scripts/lab.sh" "$ROOT/scripts/bootstrap-state.sh"
python3 -m py_compile "$ROOT/scripts/configure.py" "$ROOT/tests/test_config.py"
python3 "$ROOT/tests/test_config.py"
python3 - "$ROOT" <<'PY'
import json, pathlib, sys
root=pathlib.Path(sys.argv[1])
try: import yaml
except ImportError: yaml=None
for path in root.glob('charts/*/values.yaml'):
    if yaml:
        data=yaml.safe_load(path.read_text())
        assert isinstance(data, dict), path
        print('PASS YAML:',path.relative_to(root))
    else:
        print('SKIP PyYAML:',path.relative_to(root))
assert 'destroy)' in (root/'scripts/lab.sh').read_text()
assert 'run_platform destroy' in (root/'scripts/lab.sh').read_text()
assert 'terraform -chdir="$ROOT/platform" destroy' in (root/'scripts/lab.sh').read_text()
for path in root.glob('infra/**/*.tf'):
    assert path.stat().st_size>0, path
for path in root.glob('platform/*.tf'):
    assert path.stat().st_size>0, path
print('PASS: project layout, required HCL files, destroy dispatch')
PY
if command -v terraform >/dev/null; then
  echo 'Terraform binary found: running fmt -check (no Azure credentials needed).'
  terraform -chdir="$ROOT/infra" fmt -recursive
  terraform -chdir="$ROOT/platform" fmt
  terraform -chdir="$ROOT/infra" fmt -recursive -check
  terraform -chdir="$ROOT/platform" fmt -check
else
  echo 'SKIP: Terraform fmt/validate (Terraform binary not available on this computer).'
fi
if command -v helm >/dev/null; then
  for chart in "$ROOT"/charts/*; do
    helm lint "$chart"
    helm template local-test "$chart" --namespace demo >/dev/null
  done
else
  echo 'SKIP: Helm lint/template (Helm binary not available on this computer).'
fi
printf '%s\n' 'PASS: local offline tests completed.'
