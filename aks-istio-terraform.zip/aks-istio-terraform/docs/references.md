# Official reference links (verified against guidance current in November 2026)

- Terraform AzureRM AKS resource: https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/kubernetes_cluster
- Terraform Helm v3 upgrade guide: https://registry.terraform.io/providers/hashicorp/helm/latest/docs/guides/v3-upgrade-guide
- Microsoft AKS managed Istio ingress: https://learn.microsoft.com/en-us/azure/aks/istio-deploy-ingress
- Microsoft AKS managed Istio overview and limitations: https://learn.microsoft.com/en-us/azure/aks/istio-about
- Istio add-on revisions/upgrades: https://learn.microsoft.com/en-us/azure/aks/istio-upgrade
- Azure CNI Overlay: https://learn.microsoft.com/en-us/azure/aks/azure-cni-overlay
- Kubernetes NetworkPolicy on AKS: https://learn.microsoft.com/en-us/azure/aks/use-network-policies
- Entra + Kubernetes RBAC: https://learn.microsoft.com/en-us/azure/aks/kubernetes-rbac-entra-id
- Azure Disk CSI volumes: https://learn.microsoft.com/en-us/azure/aks/create-volume-azure-disk
- Azure Files CSI volumes: https://learn.microsoft.com/en-us/azure/aks/azure-csi-files-storage-provision
- Terraform `azurerm` backend: https://developer.hashicorp.com/terraform/language/backend/azurerm
- Terraform CLI: https://developer.hashicorp.com/terraform/install
- Azure CLI install: https://learn.microsoft.com/en-us/cli/azure/install-azure-cli
- Install Azure kubelogin: https://learn.microsoft.com/en-us/azure/aks/kubelogin-authentication
- Helm chart documentation: https://helm.sh/docs/topics/charts/
- AKS pricing and cost planning: https://azure.microsoft.com/en-us/pricing/details/kubernetes-service/

**Pay attention to release changes.** Validate provider and AKS/Kubernetes/Istio compatibility against these docs when deploying rather than assuming a version is permanently supported.
