# Lesson 5 — Common AKS + Istio + Terraform problems

## 1. `az` or Terraform not found

Install the Azure CLI and Terraform, reopen the terminal, then run `az version` and `terraform version`. `kubectl`, `kubelogin` and Helm are also needed for the Kubernetes stage. Use the official links in `references.md`.

## 2. `AuthorizationFailed` creating roles

The Terraform operator must have rights to **assign roles** in Azure, such as Owner or User Access Administrator at the required scopes. Contributor alone usually cannot grant RBAC. The project must grant its AKS identity Network Contributor on the VNet and its human operator Cluster Admin on AKS.

## 3. `Subnet Id is required` or subnet permission failures

The network module explicitly creates `snet-aks-nodes`; the AKS module passes its ID into `default_node_pool.vnet_subnet_id`. It creates a user-assigned identity and Network Contributor role **before** the cluster. Verify your resources and RBAC propagation:

```bash
terraform -chdir=infra output
az network vnet list -g rg-aks-demo -o table
az role assignment list --resource-group rg-aks-demo -o table
```

## 4. `kubectl` cannot connect / DNS fails

`./scripts/lab.sh connect` runs `az aks get-credentials`, `kubelogin convert-kubeconfig -l azurecli` and selects the context. Check the selected subscription/tenant and your Cluster Admin role. If you requested a private API, you **must** be connected to that VNet or VPN. A local laptop outside the VNet will not be able to reach its private DNS/API.

```bash
az account show --query '{name:name,id:id,tenant:tenantId}' -o json
kubectl config current-context
kubectl cluster-info
kubectl get nodes
```

## 5. A private ingress IP is not reachable from the Internet

That is expected! The default `internal` gateway has a private LB address. Test from a machine in the VNet, over a properly configured VPN, or through an approved bastion. Do not flip the gateway to external merely to fix a local networking issue.

```bash
kubectl get svc -n aks-istio-ingress
kubectl get gateway,virtualservice -n demo
kubectl get endpoints -n demo
```

## 6. Istio gateway does not appear

Check the Azure-managed Istio add-on and the installed revision:

```bash
az aks show -g rg-aks-demo -n aks-demo --query serviceMeshProfile -o json
kubectl get pods -n aks-istio-system
kubectl get svc -n aks-istio-ingress
```

The Service should be named `aks-istio-ingressgateway-internal` or `aks-istio-ingressgateway-external`. The example Gateway selector matches that. Do not `helm install istio/istiod` on top of Azure-managed Istio.

## 7. Istio upgrade conflicts with AKS version

The AKS `patch` upgrade channel does **not** automatically perform Istio add-on revision upgrades. Follow Microsoft's Istio add-on upgrade guide to select supported revisions and migrate namespaces safely. Always inspect both current Kubernetes and Istio revisions before upgrades.

## 8. Helm failed to install `Gateway` / `VirtualService`

Install Terraform Stage 1 first, wait until the Istio add-on CRDs exist, and only then use `./scripts/lab.sh platform`. Verify:

```bash
kubectl get crd gateways.networking.istio.io
kubectl get crd virtualservices.networking.istio.io
helm lint charts/hello-istio
helm template hello charts/hello-istio --namespace demo
```

With Helm provider 3.x use `kubernetes = { ... }` and `set = [{ ... }]`, **not** the old Helm 2.x provider syntax.

## 9. PostgreSQL PVC stays Pending

If the PVC is using `WaitForFirstConsumer`, it can legitimately wait for a matching pod to be scheduled. Check the event history:

```bash
kubectl get pvc -n databases
kubectl describe pvc postgres-data -n databases
kubectl describe storageclass aks-disk-standard-retain
```

Also inspect quotas, CSI driver pods, AZ alignment and the selected disk SKU. A multi-zone deployment might need a zone-aware strategy for stateful data.

## 10. Destroy fails or leaves storage behind

**Never bypass deletion checks simply because an Azure request failed.** Terraform destroys the platform stage before the infrastructure. Verify the Helm resources and PVs/PVCs first; the `Retain` reclaim policy can leave Azure data behind and still charge you. Read `docs/04-storage-services.md` and only delete data after confirming backups. For remote state, check and handle both stages manually.

## 11. `terraform plan` wants to replace AKS

Stop and read the diff. Renaming the cluster, changing the network plugin/CIDRs, switching private/public API or changing certain node pool attributes may force replacement. Terraform manages desired state, not just the commands you remember running previously. Don't apply destructive replacements to real databases unless you have a tested migration/backup plan.
