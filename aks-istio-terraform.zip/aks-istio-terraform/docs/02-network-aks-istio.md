# Lesson 2 — Networks, AKS, managed Istio

## IP addresses are numbered classroom doors

When you choose `--ip-base 10.90`, Terraform builds:

```text
VNet (whole campus)          10.90.0.0/16
  Node subnet (classrooms)   10.90.0.0/22
Pod overlay (student desks)  10.91.0.0/16
Service space (desk names)   10.92.0.0/16
DNS (directory)              10.92.0.10
```

The node subnet is *inside* the VNet; the other two ranges deliberately don't overlap it. With Azure CNI **Overlay**, pod IPs come from a separate network instead of consuming an IP from the node subnet for every pod. Cilium is the hall-monitor technology that supports network rules; setting up Cilium **does not automatically block all unauthorized traffic**. Add Kubernetes `NetworkPolicy` definitions appropriate to each application.

## What does `10.90.0.0/16` mean?

The `10.90` part stays the same for all addresses in that campus network. `/16` means the first 16 bits identify the network. A `/22` is a smaller zone of the network for machines. It is okay that the node subnet and VNet overlap: one is contained in the other.

Avoid conflicts with other VNets, VPNs, on-premises routes, peering and service networks. The helper verifies only internal cluster math; it cannot know your entire corporate network. These network values are difficult to change after creation.

## What is AKS?

AKS = Azure Kubernetes Service. Azure runs the Kubernetes control plane (the school office). Your node VMs run apps (the classrooms). Kubernetes schedules pods, replaces failed containers, exposes Services, and connects persistent disks requested by workloads. Your Azure subscription pays for VMs, load balancers, IPs, data transfer, storage, and optional monitoring even in the Free control-plane tier.

The default Terraform node pool is:

```hcl
default_node_pool {
  name                 = "system"
  vm_size              = var.vm_size
  node_count           = var.node_min
  min_count            = var.node_min
  max_count            = var.node_max
  auto_scaling_enabled = true
  # plus networking, upgrades and safety settings
}
```

The *autoscaler* adds nodes when scheduling demands it and can shrink to the minimum. It does not mean the node VMs become free. A separate application node pool is recommended in larger environments; see the AKS official docs.

## Managed identities and role assignment

`azurerm_user_assigned_identity.control_plane` creates an Azure machine identity — like a staff badge for Azure. `azurerm_role_assignment.network` gives that identity permission to join/manage the school's VNet. We assign this **before** AKS is built to prevent the common 'can't access subnet' error.

Workload Identity + OIDC is enabled so future Kubernetes apps can use federated identity to access Azure services without fixed Azure passwords. You still need to create per-application federated identity credentials and role assignments; enabling this setting alone doesn't grant an app any rights.

## Istio — the visitor entrance

Azure's Istio add-on creates and maintains `istiod`, supported sidecar proxies and the ingress gateway. Its **gateway service** has either a private or public LoadBalancer IP, depending on `--gateway`. The Terraform resource declares:

```hcl
service_mesh_profile {
  mode                             = "Istio"
  revisions                        = []
  internal_ingress_gateway_enabled = var.gateway_type == "internal"
  external_ingress_gateway_enabled = var.gateway_type == "external"
}
```

`revisions=[]` lets Azure select an installed supported revision at first create. Istio revision upgrades require their own tested procedure. The application chart's `Gateway` (capital G) tells the gateway which hosts/ports to accept. Its `VirtualService` says which backend Service should receive traffic. **Neither object installs the gateway deployment or its LoadBalancer.**

### Example request path

```text
Visiting computer
  --> internal LB IP (accessible from VNet)
  --> AKS-managed Istio ingressgateway
  --> Gateway HTTP 80 host rule
  --> VirtualService route /
  --> hello Service port 80
  --> hello Pod port 5678
```

For production public ingress, configure DNS, an HTTPS certificate/TLS termination, authorization, rate limits, allowed source networks and a WAF if appropriate. The sample HTTP Gateway is educational and **not appropriate for sensitive apps**.

### What about mTLS and sidecars?

The managed Istio add-on uses **revision labels** to choose which control plane injects its sidecar. The demo can be reached through ingress without automatically injecting sidecars. To add it to the mesh later, find the revision and then label the demo namespace:

```bash
kubectl get pods -n aks-istio-system
kubectl get mutatingwebhookconfigurations | grep -i istio
# Find the actual 'asm-1-XX' revision installed in YOUR cluster.
kubectl label namespace demo istio.io/rev=asm-1-XX --overwrite
kubectl rollout restart deployment/hello -n demo
```

Replace `asm-1-XX` with the actual version; don't paste an imaginary version. Production mTLS also needs peer authentication and authorization policies aligned with the application's traffic patterns.

## Gateway versus API access

An **internal Istio ingress** hides the *application gateway* from the public Internet. It does **not** automatically make the **Kubernetes API** private. The API is public by default in this starter. Choose either `--private-cluster` (requires VNet access for management) **or** `--authorized-ip-ranges YOUR-IP/32` for a public API allow-list. These are separate decisions.
