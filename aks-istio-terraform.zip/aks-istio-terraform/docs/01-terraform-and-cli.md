# Lesson 1 — Terraform and the command line

## What is Terraform?

Imagine the principal tells you to set up a new school. Rather than repeating instructions to every builder verbally, you create a **blueprint**. Terraform is the blueprint for cloud resources.

- `variable`: an empty spot on a form where you choose the school's name.
- `resource`: something Terraform will build, like a VNet or AKS cluster.
- `module`: a repeatable page in the blueprint, like the network module.
- `provider`: a translator that turns the blueprint into requests to Azure.
- `output`: a final receipt, such as the school name or IP ranges.
- `state`: Terraform's notebook of what it previously built; **protect it**.
- `plan`: a list of what will be added, changed or deleted.
- `apply`: asks Azure to perform the approved plan.
- `destroy`: removes Terraform-managed resources.

## Read the file structure in order

1. `infra/versions.tf`: AzureRM provider version 4.x; identifies which API Terraform uses.
2. `infra/variables.tf`: defines names, networks, gateway, node sizes and their validation.
3. `infra/main.tf`: computes CIDRs and connects the `network` and `aks` modules.
4. `infra/modules/network/main.tf`: builds the VNet and a node subnet.
5. `infra/modules/aks/main.tf`: builds identity and grants network permissions *before* Azure creates AKS; then creates AKS with the managed Istio add-on.
6. `infra/outputs.tf`: tells you where the resources were created.
7. `platform/`: separately installs Kubernetes/Helm resources after AKS exists.

## Terraform vocabulary in a real example

```hcl
variable "cluster_name" {
  type    = string
  default = "aks-school-lab"
}
```

`variable` says this is a user setting, `type=string` means text, and `default` says which name to use if you didn't supply one.

```hcl
resource "azurerm_resource_group" "foundation" {
  name     = var.resource_group_name
  location = var.location
}
```

`resource` says **create one Azure thing**. `azurerm_resource_group` is the thing's Azure type, `foundation` is Terraform's local nickname, `var...` reads values from the settings form.

```hcl
module "network" {
  source = "./modules/network"
  # Other inputs omitted here; see infra/main.tf.
}
```

`module` is a set of reusable blueprint pages. The real module wires the VNet, subnet and tags.

## Run Terraform manually, without the helper

```bash
./scripts/lab.sh configure --name aks-demo --ip-base 10.90
terraform -chdir=infra init
terraform -chdir=infra fmt -recursive
terraform -chdir=infra validate
terraform -chdir=infra plan
terraform -chdir=infra apply

# THEN configure Kubernetes access before Stage 2:
./scripts/lab.sh connect
terraform -chdir=platform init
terraform -chdir=platform plan
terraform -chdir=platform apply
```

These are two **different states**. Azure infrastructure cannot depend on the Kubernetes provider in a single first-time plan; the Kubernetes API isn't there until the AKS creation completes. Imagine building the school before asking someone to post the hallway signs.

The wrapper makes saved settings files for you. It does **not** put passwords in the saved configuration. Do not store credentials in `*.tfvars` or in source control.

## Practice questions

1. Which command just shows the proposed changes? `terraform plan`.
2. Why is the cluster built before Helm runs? Helm must connect to a real API server.
3. If you change `ip_base` after creation, is that a harmless rename? **No.** It can force the network and cluster to be replaced.
4. How can you stop using a command repeatedly? Put reusable settings in saved configuration and use separate modules.
