# Lesson 3 — Terraform state, identity and security

## What is Terraform state?

Imagine a librarian who keeps a notebook listing every book the library bought. Terraform state is the notebook listing what Azure resources Terraform created and their identifying information. Losing it can make normal updates and cleanup difficult. Exposing it may expose credentials or sensitive resource details.

### Local state for a one-person lab

By default each stage uses local files:

```text
infra/terraform.tfstate
platform/terraform.tfstate
```

These are excluded from Git. **Commit the generated `.terraform.lock.hcl` provider lock files** so your team uses tested provider versions. **Do not delete state files**, copy them to public chat/repositories or let two people change them at once. For a team or CI use remote state with Azure Blob Storage and locking.

## Optional Azure remote state

The starter includes `scripts/bootstrap-state.sh` and `infra/examples/backend.azurerm.tf.example` and `backend.hcl.example`.

First create a private Azure Storage account and Blob container. Choose a globally unique lowercase storage account name (3–24 chars). **This is a separate prerequisite**; it should not be stored in the same Terraform state whose backend it hosts.

```bash
./scripts/bootstrap-state.sh \
  --name myuniquetfstate2026 \
  --resource-group rg-tfstate \
  --location eastus2
```

The script uses Azure CLI + Entra authentication, disables anonymous public blobs and public/shared-key access, and sets minimum TLS 1.2. It assumes your identity is allowed to create storage accounts and role assignments. Wait for RBAC changes to propagate if container creation initially fails.

Next:

```bash
cp infra/examples/backend.azurerm.tf.example infra/backend.tf
cp infra/examples/backend.hcl.example infra/backend.hcl
# Edit infra/backend.hcl with real values.
cd infra
terraform init -migrate-state -backend-config=backend.hcl
cd ..
```

The backend file is ignored by Git when it includes private environment details. In this template only the `infra` stage has a backend example. For a team, configure a **different blob key and backend** for the `platform` stage too. State separation means updating Helm does not accidentally rebuild Azure networking.

**Before copying `backend.tf`**, ensure you have working permissions on the state container and plan your migration. Use Entra authentication for state (`use_azuread_auth=true`) and storage account private networking appropriate to your team. Production state should be encrypted, backed up, protected by RBAC and deletion controls, and audited.

## How does this configuration log in?

1. `az login` signs a real person in to Microsoft Entra ID.
2. AzureRM Terraform uses the selected Azure subscription to make resource-group, network and AKS requests.
3. AKS is created with **local accounts disabled** and Entra + Kubernetes Azure RBAC enabled.
4. The current Terraform identity is granted the **Azure Kubernetes Service RBAC Cluster Admin** role by Terraform for the lab. This can take time to propagate.
5. `az aks get-credentials` fetches a kubeconfig; `kubelogin convert-kubeconfig -l azurecli` makes Kubernetes use your Azure CLI Entra login.
6. Helm uses the *same user context* to install the platform stage.

Do not hardcode admin passwords. Use per-app Workload Identity, Kubernetes ServiceAccounts, Azure Key Vault and least-privilege rules as you build more services. Your identity needs permissions to make Azure role assignments before this lab can create itself.

## Security settings in Terraform

- `local_account_disabled=true`: no local cluster-admin account as a shortcut.
- `azure_rbac_enabled=true`: Azure evaluates Kubernetes authorization.
- `oidc_issuer_enabled=true` and `workload_identity_enabled=true`: foundation for password-free cloud access from pods.
- `node_public_ip_enabled=false`: node VMs lack public IPs.
- `network_policy=cilium`: platform capable of enforcing pod traffic rules; author actual policies per workload.
- `gateway_type=internal` by default: private application ingress.
- `private_cluster=false` by default: public Kubernetes **API**; protect with CIDR allow-list or private cluster.
- `azure-managed Istio`: Azure owns control plane and supported ingress deployment; don't install a second Istio.

## Production checklist

- Decide on an **AKS private API** and private DNS/network path, or at least an API allow-list.
- Use least-privilege Entra groups instead of granting every operator Cluster Admin.
- Split production node pools: system versus workload, with appropriate zones, taints and scaling.
- Set up an egress strategy (NAT Gateway/firewall, allowed outbound endpoints); the lab uses Standard Load Balancer egress and may have additional charges.
- Configure TLS certificates, domain names, HTTPS, `AuthorizationPolicy`, `PeerAuthentication` and NetworkPolicy before public traffic.
- Use Key Vault + Workload Identity for service credentials.
- Install metrics/alerts/logging with retention and budgets.
- Set maintenance windows and test separate AKS and Istio add-on version upgrades.
- Make and **restore-test** PostgreSQL backups, Azure Disk snapshots and disaster recovery.
- Lock remote state and review all Terraform plans for deletion/replacement before `apply`.

The lab starts with inexpensive defaults but is **not free**. AKS VMs, load balancers, NAT/egress, disks, IP addresses, file shares, monitoring and traffic can incur charges.
