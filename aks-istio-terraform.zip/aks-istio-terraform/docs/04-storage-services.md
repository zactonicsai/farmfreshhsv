# Lesson 4 — Persistent storage for PostgreSQL and Keycloak

## Why do Kubernetes apps need volumes?

A container is like a temporary classroom desk. If it is replaced, everything left only on the desk can disappear. A **PersistentVolumeClaim (PVC)** asks for a durable storage locker that Kubernetes can connect to a pod.

### Vocabulary

| Word | Easy meaning | Kubernetes/Azure counterpart |
|---|---|---|
| StorageClass | Which kind of locker to order | Azure Disk or Azure File CSI definition |
| PersistentVolumeClaim (PVC) | A student requests a locker | Named request for `20Gi`, etc. |
| PersistentVolume (PV) | The assigned locker | A volume backed by Azure storage |
| Access mode | How many people can use the locker | `ReadWriteOnce` or `ReadWriteMany` |
| Reclaim policy | What happens if the request is removed | `Retain` versus `Delete` |

## Which storage should you choose?

- **PostgreSQL:** Azure managed disk (`disk.csi.azure.com`), usually **ReadWriteOnce** and dedicated to a single Postgres pod/instance. For multiple database replicas, each database replica normally gets a *different PVC* and replication is handled by a database operator; don't attach one disk to all replicas.
- **Keycloak:** Keycloak keeps user and realm data in **PostgreSQL**, not in a shared Keycloak data directory. An Azure Files RWX claim (`file.csi.azure.com`) is optional for shared custom themes/import assets. A robust production design often packages themes into the container image instead of putting them in a shared volume.

Our `storage-classes` Helm chart defines:

```text
aks-disk-standard-retain   disk.csi.azure.com  StandardSSD_LRS
aks-disk-premium-retain    disk.csi.azure.com  Premium_LRS
aks-file-retain            file.csi.azure.com  Standard_LRS
```

They use `reclaimPolicy: Retain` so accidental PVC deletion does not intentionally delete the underlying PV's Azure storage. **Warning:** this can leave disks or shares behind after cleanup and continue billing. It is NOT a backup strategy. The file class and disk classes differ in performance, mounting and authentication properties. StandardSSD_LRS is intended as a budget-conscious example; select storage SKU and redundancy after measuring database needs.

## Prepare PVCs (optional)

```bash
./scripts/lab.sh platform --postgres-pvc --postgres-size 20Gi
./scripts/lab.sh platform --keycloak-pvc --keycloak-size 5Gi
kubectl get sc
kubectl get pvc -A
kubectl get pv
```

A disk PVC may stay **Pending** until its first pod needs it, because the class uses `WaitForFirstConsumer`. This is often expected, not a failure. The chart does not install Postgres or Keycloak; no Pod consumes the PVC yet.

## Example: mount the Postgres PVC from a future StatefulSet

```yaml
# Demonstration fragment; not a complete runnable PostgreSQL StatefulSet.
volumeMounts:
  - name: pgdata
    mountPath: /var/lib/postgresql/data
volumes:
  - name: pgdata
    persistentVolumeClaim:
      claimName: postgres-data
```

The Pod/StatefulSet must run in **the same namespace** (`databases`) as the claim. Supply correct database image version, permissions, secrets and init logic based on the actual Postgres image. Production should use a PostgreSQL operator with independently managed backups and high availability.

## Example: mount Keycloak theme assets

```yaml
# Illustration only, not a complete Keycloak Deployment.
volumeMounts:
  - name: themes
    mountPath: /opt/keycloak/themes
    readOnly: true
volumes:
  - name: themes
    persistentVolumeClaim:
      claimName: keycloak-themes
```

The Pod must be in the `identity` namespace. Azure Files needs testing for expected permissions and file locking. Keycloak application data still goes to its Postgres database.

## Don't confuse storage with backups

A PVC protects data from a **container restart**, not every danger. It doesn't protect against accidental writes, database corruption, deleted Azure resources, malicious changes or a region outage. Make backups and try an actual restore before trusting the system with important records.

## Practice

1. Which storage lets multiple pods share custom theme files? Azure Files with `ReadWriteMany`.
2. Why shouldn't two PostgreSQL primaries write to one disk? The data could be corrupted; cluster them through database-level replication instead.
3. What might a Pending claim mean with `WaitForFirstConsumer`? No application has requested a mount yet.
4. If a retained disk is no longer used, will Azure necessarily stop charging? **No.** You must deliberately inspect and delete it after safely preserving the data.
