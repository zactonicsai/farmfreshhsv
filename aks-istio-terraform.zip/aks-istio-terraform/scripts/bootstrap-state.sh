#!/usr/bin/env bash
# Optional, independent infrastructure to hold shared Terraform state.
set -Eeuo pipefail
usage() { cat <<'EOF'
Usage:
  ./scripts/bootstrap-state.sh --name globallyuniquestoragename \
      --resource-group rg-tfstate --location eastus2 [--container tfstate]

Runs with your current 'az login'. Your user needs permission to create Azure
Storage and RBAC role assignments. This account is NOT managed by the AKS state.
EOF
}
NAME=''; RG=''; REGION=''; CONTAINER='tfstate'
while (($#)); do
  case "$1" in
    --name) NAME="${2:?}"; shift 2 ;;
    --resource-group) RG="${2:?}"; shift 2 ;;
    --location) REGION="${2:?}"; shift 2 ;;
    --container) CONTAINER="${2:?}"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done
[[ "$NAME" =~ ^[a-z0-9]{3,24}$ ]] || { echo 'Storage name: lowercase a-z0-9, 3-24 chars' >&2; exit 2; }
[[ -n "$RG" && -n "$REGION" && "$CONTAINER" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?$ ]] || { usage; exit 2; }
command -v az >/dev/null || { echo 'Install Azure CLI and run az login' >&2; exit 1; }

az group create --name "$RG" --location "$REGION" --output none
az storage account create \
  --name "$NAME" --resource-group "$RG" --location "$REGION" \
  --sku Standard_LRS --kind StorageV2 \
  --min-tls-version TLS1_2 \
  --allow-blob-public-access false \
  --allow-shared-key-access false \
  --https-only true \
  --output none

ACCOUNT_ID="$(az storage account show --name "$NAME" --resource-group "$RG" --query id -o tsv)"
# This simple bootstrap assumes interactive human Azure CLI login.
CURRENT_ID="$(az ad signed-in-user show --query id -o tsv)"
[[ -n "$CURRENT_ID" ]] || { echo 'Could not find signed-in Entra user object ID' >&2; exit 1; }

# Blob data access is a different role than Azure resource management Owner.
if ! az role assignment list --scope "$ACCOUNT_ID" --assignee "$CURRENT_ID" \
    --query "[?roleDefinitionName=='Storage Blob Data Contributor'].id | [0]" -o tsv | grep -q '/'; then
  az role assignment create --assignee-object-id "$CURRENT_ID" \
    --assignee-principal-type User --role 'Storage Blob Data Contributor' \
    --scope "$ACCOUNT_ID" --output none
fi

if ! az storage container create --name "$CONTAINER" --account-name "$NAME" \
    --auth-mode login --output none; then
  echo 'RBAC propagation might not be complete. Retry this command once role assignment is active:' >&2
  echo "  az storage container create --account-name $NAME --name $CONTAINER --auth-mode login" >&2
  exit 1
fi
cat <<EOF

Remote state account ready (not managed by the AKS Terraform state):
  resource_group_name  = "$RG"
  storage_account_name = "$NAME"
  container_name       = "$CONTAINER"
  key                  = "aks-lab-infrastructure.tfstate"
  use_azuread_auth     = true

Add these entries to infra/backend.hcl (copy from the example), create
infra/backend.tf from the example, and run:
  terraform -chdir=infra init -migrate-state -backend-config=backend.hcl
Keep a separate blob key/backend for the platform state in team deployments.
EOF
