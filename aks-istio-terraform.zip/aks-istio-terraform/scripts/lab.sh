#!/usr/bin/env bash
# A small, human-friendly front door into the two Terraform stages.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

usage() {
  cat <<'EOF'
Azure AKS / Istio Terraform lab

Usage:
  ./scripts/lab.sh <command> [options]

Commands:
  configure  Save options to .local/settings.json and *.auto.tfvars.json
  plan       Show proposed Azure resources; creates no Azure infrastructure
  apply      Provision stage 1: Azure network, AKS, Istio managed add-on
  connect    Fetch kubeconfig and convert Entra login for kubectl/Helm
  platform-plan  Plan stage 2: Helm storage classes / optional PVCs / demo
  platform   Apply stage 2 after stage 1 is running
  all        Apply stage 1; then connect and apply stage 2
  verify     Show nodes, mesh ingress, storage classes and claims
  output     Show Terraform stage 1 outputs
  destroy    Destroy stage 2 then stage 1; requires --confirm-destroy NAME
  test       Run offline local tests (does not contact Azure)

Common options (persist to disk, CLI options override earlier values):
  --name aks-demo             --ip-base 10.90
  --resource-group rg-aks-demo --location eastus2
  --subscription UUID        --gateway internal|external
  --node-min 2               --node-max 3
  --vm-size Standard_D2s_v5  --private-cluster
  --user-pool --workload-node-min 1 --workload-node-max 2
  --authorized-ip-ranges 198.51.100.3/32
  --tier Free|Standard       --zones 1,2,3
  --monitoring               --demo --demo-host demo.example.org
  --postgres-pvc --postgres-size 20Gi
  --keycloak-pvc --keycloak-size 5Gi
  --yes                      Auto-approve apply (not recommended without plan)

Examples:
  ./scripts/lab.sh plan --name aks-demo --ip-base 10.90
  ./scripts/lab.sh all --name aks-demo --ip-base 10.90 --gateway internal
  ./scripts/lab.sh platform --postgres-pvc
  ./scripts/lab.sh destroy --confirm-destroy aks-demo

Important: use 'plan' first. Azure usage is billable.
EOF
}

command_name="${1:-help}"
if (($# > 0)); then shift; fi
case "$command_name" in
  help|-h|--help) usage; exit 0 ;;
  test) exec "$ROOT/tests/local-tests.sh" ;;
  configure|plan|apply|connect|platform-plan|platform|all|verify|output|destroy) ;;
  *) echo "Unknown command: $command_name" >&2; usage; exit 2 ;;
esac

YES=false
CONFIRM=''
CONFIG_ARGS=()
while (($#)); do
  case "$1" in
    --yes) YES=true; shift ;;
    --confirm-destroy)
      (($# >= 2)) || { echo '--confirm-destroy needs the exact cluster name' >&2; exit 2; }
      CONFIRM="$2"; shift 2 ;;
    *) CONFIG_ARGS+=("$1"); shift ;;
  esac
done

command -v python3 >/dev/null || { echo 'python3 required' >&2; exit 1; }
# Read the CLI subscription if available. No need to 'source' user input.
if command -v az >/dev/null && az account show --query id -o tsv >/dev/null 2>&1; then
  export AZURE_SUBSCRIPTION_ID
  AZURE_SUBSCRIPTION_ID="$(az account show --query id -o tsv)"
fi
python3 "$ROOT/scripts/configure.py" "${CONFIG_ARGS[@]}"

read_conf() { python3 - "$ROOT/.local/settings.json" "$1" <<'PY'
import json,sys
val=json.load(open(sys.argv[1]))[sys.argv[2]]
print(str(val).lower() if isinstance(val,bool) else val)
PY
}
NAME="$(read_conf cluster_name)"
RG="$(read_conf resource_group_name)"
SUBSCRIPTION="$(read_conf subscription_id)"
PRIVATE="$(read_conf private_cluster)"

if [[ "$command_name" == configure ]]; then exit 0; fi
if [[ "$command_name" == destroy && "$CONFIRM" != "$NAME" ]]; then
  echo "Refusing deletion: supply --confirm-destroy $NAME" >&2
  exit 2
fi
if [[ "$command_name" == plan || "$command_name" == apply || "$command_name" == all || "$command_name" == platform-plan || "$command_name" == platform || "$command_name" == destroy ]]; then
  command -v terraform >/dev/null || { echo 'Terraform >= 1.8 is required' >&2; exit 1; }
fi

if [[ "$command_name" != output ]]; then
  command -v az >/dev/null || { echo 'Azure CLI required: install it and run az login' >&2; exit 1; }
  az account set --subscription "$SUBSCRIPTION"
fi

init_infra() { terraform -chdir="$ROOT/infra" init -input=false; }
init_platform() { terraform -chdir="$ROOT/platform" init -input=false; }

connect_cluster() {
  command -v kubectl >/dev/null || { echo 'kubectl required' >&2; exit 1; }
  command -v kubelogin >/dev/null || { echo 'kubelogin required for Entra AKS login' >&2; exit 1; }
  if [[ "$PRIVATE" == true ]]; then
    echo 'Private AKS API selected: this computer must be on the connected VNet/VPN/bastion.'
  fi
  az aks get-credentials --resource-group "$RG" --name "$NAME" --overwrite-existing
  # Entra users sign in through Azure CLI; no embedded admin password.
  kubelogin convert-kubeconfig -l azurecli
  kubectl config use-context "$NAME"
  kubectl cluster-info
}

run_platform() {
  connect_cluster
  init_platform
  case "$1" in
    plan) terraform -chdir="$ROOT/platform" plan ;;
    apply)
      if "$YES"; then terraform -chdir="$ROOT/platform" apply -auto-approve
      else terraform -chdir="$ROOT/platform" apply; fi ;;
    destroy)
      if "$YES"; then terraform -chdir="$ROOT/platform" destroy -auto-approve
      else terraform -chdir="$ROOT/platform" destroy; fi ;;
    *) echo "Unknown platform action $1" >&2; exit 2 ;;
  esac
}

case "$command_name" in
  plan) init_infra; terraform -chdir="$ROOT/infra" plan ;;
  apply)
    init_infra
    if "$YES"; then terraform -chdir="$ROOT/infra" apply -auto-approve
    else terraform -chdir="$ROOT/infra" apply; fi
    ;;
  connect) connect_cluster ;;
  platform-plan) run_platform plan ;;
  platform) run_platform apply ;;
  all)
    init_infra
    if "$YES"; then terraform -chdir="$ROOT/infra" apply -auto-approve
    else terraform -chdir="$ROOT/infra" apply; fi
    run_platform apply
    ;;
  verify)
    connect_cluster
    echo '=== Nodes ==='; kubectl get nodes -o wide
    echo '=== Istio control plane ==='; kubectl get pods -n aks-istio-system
    echo '=== Istio gateway ==='; kubectl get svc -n aks-istio-ingress
    echo '=== StorageClasses ==='; kubectl get storageclass
    echo '=== PersistentVolumeClaims ==='; kubectl get pvc -A
    echo '=== App releases ==='; if command -v helm >/dev/null; then helm list -A; fi
    ;;
  output) terraform -chdir="$ROOT/infra" output ;;
  destroy)
    echo "DANGER: Deleting $NAME, its network, node pools, and any data not protected separately."
    echo 'A Retain StorageClass may leave Azure disks/shares and ongoing charges; inspect them manually.'
    if [[ -f "$ROOT/platform/terraform.tfstate" ]]; then
      run_platform destroy
    fi
    init_infra
    if "$YES"; then terraform -chdir="$ROOT/infra" destroy -auto-approve
    else terraform -chdir="$ROOT/infra" destroy; fi
    ;;
esac
