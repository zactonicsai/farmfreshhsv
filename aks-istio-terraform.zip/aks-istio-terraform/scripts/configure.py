#!/usr/bin/env python3
"""Safely generate shared Terraform tfvars from a single user configuration.

The settings file persists so that future 'plan' and 'destroy' do not silently
switch cluster names or networks. No shell eval, no secrets, no .env sourcing.
"""
from __future__ import annotations

import argparse
import ipaddress
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SETTINGS = ROOT / '.local' / 'settings.json'
DEFAULTS = {
    'subscription_id': '',
    'cluster_name': 'aks-school-lab',
    'resource_group_name': 'rg-aks-school-lab',
    'location': 'eastus2',
    'ip_base': '10.90',
    'gateway_type': 'internal',
    'private_cluster': False,
    'authorized_ip_ranges': [],
    'node_min': 2,
    'node_max': 3,
    'vm_size': 'Standard_D2s_v5',
    'workload_pool_enabled': False,
    'workload_node_min': 1,
    'workload_node_max': 2,
    'workload_vm_size': 'Standard_D2s_v5',
    'kubernetes_version': None,
    'sku_tier': 'Free',
    'zones': [],
    'admin_group_object_ids': [],
    'grant_current_principal_cluster_admin': True,
    'enable_monitoring': False,
    'enable_demo': False,
    'demo_host': '*',
    'create_postgres_pvc': False,
    'create_keycloak_pvc': False,
    'postgres_storage_size': '20Gi',
    'keycloak_storage_size': '5Gi',
    'tags': {'project': 'aks-istio-foundation', 'environment': 'lab', 'managed-by': 'terraform'},
}
PLATFORM_KEYS = {
    'gateway_type', 'enable_demo', 'demo_host', 'create_postgres_pvc',
    'create_keycloak_pvc', 'postgres_storage_size', 'keycloak_storage_size',
}
INFRA_KEYS = set(DEFAULTS) - PLATFORM_KEYS


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description='Save validated AKS+Istio Terraform arguments')
    string_options = {
        '--name': 'cluster_name', '--resource-group': 'resource_group_name',
        '--location': 'location', '--ip-base': 'ip_base',
        '--gateway': 'gateway_type', '--subscription': 'subscription_id',
        '--vm-size': 'vm_size', '--workload-vm-size': 'workload_vm_size', '--kubernetes-version': 'kubernetes_version',
        '--tier': 'sku_tier', '--demo-host': 'demo_host',
        '--postgres-size': 'postgres_storage_size',
        '--keycloak-size': 'keycloak_storage_size',
    }
    for flag, dest in string_options.items():
        p.add_argument(flag, dest=dest, default=None)
    p.add_argument('--node-min', type=int)
    p.add_argument('--node-max', type=int)
    p.add_argument('--workload-node-min', type=int)
    p.add_argument('--workload-node-max', type=int)
    p.add_argument('--authorized-ip-ranges', help='Comma-separated CIDR list (e.g. 198.51.100.3/32)')
    p.add_argument('--admin-group-object-ids', help='Comma-separated Entra group object IDs')
    p.add_argument('--zones', help='Comma-separated AZ IDs (e.g. 1,2,3)')
    for enable_flag, disable_flag, dest in [
        ('--private-cluster', '--public-cluster', 'private_cluster'),
        ('--user-pool', '--no-user-pool', 'workload_pool_enabled'),
        ('--monitoring', '--no-monitoring', 'enable_monitoring'),
        ('--demo', '--no-demo', 'enable_demo'),
        ('--postgres-pvc', '--no-postgres-pvc', 'create_postgres_pvc'),
        ('--keycloak-pvc', '--no-keycloak-pvc', 'create_keycloak_pvc'),
        ('--grant-operator-admin', '--no-grant-operator-admin', 'grant_current_principal_cluster_admin'),
    ]:
        group = p.add_mutually_exclusive_group()
        group.add_argument(enable_flag, action='store_const', const=True, dest=dest)
        group.add_argument(disable_flag, action='store_const', const=False, dest=dest)
        p.set_defaults(**{dest: None})
    p.add_argument('--show', action='store_true', help='Print saved configuration after writing it')
    return p


def read_settings() -> dict:
    if SETTINGS.exists():
        obj = json.loads(SETTINGS.read_text())
        extra = set(obj) - set(DEFAULTS)
        if extra:
            raise ValueError(f'Unknown keys in settings.json: {sorted(extra)}')
        return {**DEFAULTS, **obj}
    return dict(DEFAULTS)


def validate(cfg: dict) -> None:
    if not re.fullmatch(r'[a-zA-Z][a-zA-Z0-9-]{1,50}[a-zA-Z0-9]', cfg['cluster_name']):
        raise ValueError('Cluster name must be 3–52 chars, start with a letter, and end with a letter/digit')
    if not re.fullmatch(r'[a-zA-Z0-9_.()-]{1,90}', cfg['resource_group_name']):
        raise ValueError('Invalid resource group name')
    if not re.fullmatch(r'10\.\d{1,3}', cfg['ip_base']):
        raise ValueError('--ip-base must look like 10.90')
    i = int(cfg['ip_base'].split('.')[1])
    if not (0 <= i <= 253):
        raise ValueError('Second octet must be 0–253 to leave space for pods and services')
    address_blocks = [
        ipaddress.ip_network(f'10.{i}.0.0/16'),
        ipaddress.ip_network(f'10.{i}.0.0/22'),
        ipaddress.ip_network(f'10.{i+1}.0.0/16'),
        ipaddress.ip_network(f'10.{i+2}.0.0/16'),
    ]
    # The node subnet is intentionally INSIDE the VNet; the other two must be separate.
    if not address_blocks[1].subnet_of(address_blocks[0]):
        raise ValueError('Node subnet must fit within VNet')
    for other in address_blocks[2:]:
        if other.overlaps(address_blocks[0]):
            raise ValueError('Pod or service range overlaps VNet')
    if cfg['gateway_type'] not in ('internal', 'external'):
        raise ValueError('--gateway must be internal or external')
    if cfg['node_min'] < 1 or cfg['node_max'] > 100 or cfg['node_min'] > cfg['node_max']:
        raise ValueError('Use 1 <= node-min <= node-max <= 100')
    if (cfg['workload_node_min'] < 1 or cfg['workload_node_max'] > 100 or
            cfg['workload_node_min'] > cfg['workload_node_max']):
        raise ValueError('Use 1 <= workload-node-min <= workload-node-max <= 100')
    if cfg['sku_tier'] not in ('Free', 'Standard', 'Premium'):
        raise ValueError('--tier must be Free, Standard, or Premium')
    if cfg['private_cluster'] and cfg['authorized_ip_ranges']:
        raise ValueError('API IP allow-list applies to public clusters only; choose one or the other')
    for cidr in cfg['authorized_ip_ranges']:
        ipaddress.ip_network(cidr, strict=False)
    if cfg['gateway_type'] == 'external' and cfg['enable_demo'] and cfg['demo_host'] == '*':
        raise ValueError('External demo requires --demo-host your.example.org; wildcard public HTTP demo is forbidden')
    if any(not re.fullmatch(r'[1-9]\d*Gi', cfg[key]) for key in ('postgres_storage_size', 'keycloak_storage_size')):
        raise ValueError('PVC sizes must be like 20Gi or 5Gi')
    if cfg['subscription_id'] and not re.fullmatch(r'[a-fA-F0-9-]{36}', cfg['subscription_id']):
        raise ValueError('Subscription id must be a UUID')


def atomic_json_write(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')
    os.replace(temp, path)


def prepare(argv: list[str]) -> dict:
    args = parser().parse_args(argv)
    cfg = read_settings()
    args_dict = vars(args)
    old_name = cfg['cluster_name']
    for key in DEFAULTS:
        value = args_dict.get(key)
        if value is not None:
            cfg[key] = value
    # Set an appropriate RG for new labs when none was chosen yet.
    if args.cluster_name is not None and args.resource_group_name is None and not SETTINGS.exists():
        cfg['resource_group_name'] = f'rg-{cfg["cluster_name"]}'
    for key in ('authorized_ip_ranges', 'admin_group_object_ids', 'zones'):
        value = args_dict.get(key)
        if value is not None:
            cfg[key] = [x.strip() for x in value.split(',') if x.strip()]
    # Azure CLI login supplies the subscription at first configuration.
    if args.subscription_id is None and not cfg['subscription_id']:
        cfg['subscription_id'] = os.environ.get('AZURE_SUBSCRIPTION_ID', '')
    validate(cfg)
    if not cfg['subscription_id']:
        raise ValueError('No Azure subscription ID: run az login or pass --subscription UUID')
    atomic_json_write(SETTINGS, cfg)
    atomic_json_write(ROOT / 'infra' / 'terraform.auto.tfvars.json',
                      {k: cfg[k] for k in sorted(INFRA_KEYS)})
    platform = {k: cfg[k] for k in sorted(PLATFORM_KEYS)}
    platform['kube_context'] = cfg['cluster_name']
    platform['kubeconfig_path'] = os.path.abspath(os.path.expanduser(os.environ.get('KUBECONFIG', '~/.kube/config').split(os.pathsep)[0]))
    atomic_json_write(ROOT / 'platform' / 'terraform.auto.tfvars.json', platform)
    if args.show:
        print(json.dumps(cfg, indent=2, sort_keys=True))
    else:
        print(f'Saved configuration: {SETTINGS}')
        print(f'AKS {old_name} -> {cfg["cluster_name"]}; gateway={cfg["gateway_type"]}; IP base={cfg["ip_base"]}')
    return cfg


if __name__ == '__main__':
    try:
        prepare(sys.argv[1:])
    except (ValueError, argparse.ArgumentError) as exc:
        sys.exit(f'CONFIG ERROR: {exc}')
