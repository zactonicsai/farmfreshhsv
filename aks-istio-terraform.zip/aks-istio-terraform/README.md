# Azure AKS + Managed Istio + Ready-to-Use Storage — Terraform edition

> **Goal:** Stand up an Azure Kubernetes Service (AKS) 'school campus', give it an Istio entrance, and prepare disk/file storage for **future** services like PostgreSQL and Keycloak. Learn each piece without needing a Kubernetes engineering background.
>
> **Important:** These files are an educational infrastructure starter, not a complete production deployment. An Azure subscription, quotas, credentials, VPN for private networks, hardened TLS, backups, monitoring and cost controls are still your responsibility. Terraform code has not been provisioned in a real Azure subscription in this package.

## 1. Architecture

```text
Your Mac/Linux terminal
        |
        | az login / Terraform
        v
+-----------------------------------------------------------+
| Azure subscription                                         |
|  Resource group: rg-aks-school-lab                         |
|  VNet: 10.90.0.0/16                                        |
|     Node subnet: 10.90.0.0/22                             |
|  AKS: managed identity + Entra RBAC + Cilium Overlay       |
|     Pod addresses:     10.91.0.0/16                        |
|     Service addresses: 10.92.0.0/16                        |
|     DNS:               10.92.0.10                          |
|                                                           |
|  AKS-managed Istio add-on                                 |
|     Istio control plane                                   |
|     Istio ingress gateway (internal/private by default)   |
|                      |                                    |
|          +-----------+--------------+                     |
|          |           |              |                     |
|      demo app     Keycloak*      PostgreSQL*               |
|          |           |              |                     |
|      HTTP test  Shared-files*   Azure Disk PVC*            |
|                                                           |
|  Azure Disk CSI driver / Azure File CSI driver             |
+-----------------------------------------------------------+
* Future apps are not installed. Their PVCs are off by default.
```

**School analogy:** The Azure resource group is the school district folder; the VNet is the campus; the AKS nodes are classrooms; pods are activities running in classrooms; the Istio gateway is the visitor reception desk; persistent volumes are lockers that keep things even when a classroom closes.

## 2. What is in the ZIP?

```text
aks-istio-terraform/
├── infra/                           # Terraform stage 1 (Azure-only)
│   ├── main.tf                      # Resource group and module wiring
│   ├── versions.tf                  # Provider and Terraform versions
│   ├── variables.tf                 # Configurable inputs with checks
│   ├── outputs.tf                   # IP ranges, cluster name, etc.
│   ├── modules/network/             # VNet + AKS node subnet
│   ├── modules/aks/                 # Identity, RBAC, AKS, managed Istio, CSI
│   └── examples/                    # Remote-state backend examples
├── platform/                        # Terraform stage 2 (Kubernetes/Helm)
│   ├── main.tf                      # Helm releases, all optional except classes
│   ├── versions.tf                  # Helm provider 3.x
│   ├── variables.tf                 # PVC and demo switches
│   └── outputs.tf
├── charts/
│   ├── storage-classes/             # Reusable Retain storage classes
│   ├── service-volumes/             # Optional Postgres/Keycloak PVCs
│   └── hello-istio/                 # Optional hello demo + gateway routing
├── MIGRATION.md                     # How this maps to the original shell version
├── scripts/
│   ├── lab.sh                       # The command-line front door
│   ├── configure.py                 # Save/validate shared settings
│   └── bootstrap-state.sh           # Optional shared Azure state storage
├── docs/
│   ├── 01-terraform-and-cli.md
│   ├── 02-network-aks-istio.md
│   ├── 03-state-and-security.md
│   ├── 04-storage-services.md
│   ├── 05-troubleshooting.md
│   └── references.md
└── tests/                            # Local, offline tests
```

## 3. Prerequisites

- An Azure subscription and an identity allowed to create resource groups, VNet/AKS, managed identities and **role assignments** (Owner, or sufficient Contributor + User Access Administrator privileges). Role assignments are required by this starter.
- Azure CLI (`az`), Terraform **1.8+**, Python 3.9+, `kubectl`, **kubelogin** and Helm (recommended for inspecting charts).
- Log in and select your subscription: `az login` then `az account set --subscription YOUR-SUBSCRIPTION-ID`.
- Ensure AKS region, VM quota/size, chosen zones, Istio version and your subscriptions support the planned components.
- A reachable AKS API; if `--private-cluster`, run the platform stage from a connected VNet/VPN/bastion.

Official installation links are in [docs/references.md](docs/references.md).

## 4. Quick start — easiest route

From the unzipped folder:

```bash
az login
az account set --subscription "YOUR-SUBSCRIPTION-ID"

# A 'plan' is a shopping list: it does not create anything in Azure.
./scripts/lab.sh plan \
  --name aks-demo \
  --resource-group rg-aks-demo \
  --location eastus2 \
  --ip-base 10.90 \
  --gateway internal \
  --node-min 2 --node-max 3

# Review the plan. Apply just Azure resources first.
./scripts/lab.sh apply

# After AKS exists, get secure Entra credentials.
./scripts/lab.sh connect

# View the Helm/storage plan, then install the storage classes.
./scripts/lab.sh platform-plan
./scripts/lab.sh platform

# Ask Azure and Kubernetes what exists.
./scripts/lab.sh verify
```

Or use **one command for both stages** after reviewing a plan:

```bash
./scripts/lab.sh all --name aks-demo --ip-base 10.90 --gateway internal
```

**No credentials are automatically invented.** The first `plan` uses `az account show` to detect your subscription. `scripts/configure.py` saves the configuration into `.local/settings.json`, `infra/terraform.auto.tfvars.json`, and `platform/terraform.auto.tfvars.json`. These files are `.gitignore`d, and the same settings are reused for future actions.

**Important:** Changing `--name`, `--ip-base`, or `--resource-group` on an existing cluster can trigger *destructive replacement*. Always run `plan` and inspect changes. Use a separate checkout/state for a second cluster, and use remote state for team work.

## 5. Example: change the IP ranges

```bash
./scripts/lab.sh plan --name aks-lab-two --ip-base 10.110
```

The script derives **non-overlapping** blocks:

| Role | Formula | For `--ip-base 10.110` |
|---|---|---|
| VNet / campus | `10.X.0.0/16` | `10.110.0.0/16` |
| AKS node subnet | `10.X.0.0/22` | `10.110.0.0/22` |
| Pod / classroom addresses | `10.(X+1).0.0/16` | `10.111.0.0/16` |
| Services | `10.(X+2).0.0/16` | `10.112.0.0/16` |
| Kubernetes DNS | `10.(X+2).0.10` | `10.112.0.10` |

Use `X` from 0 to 253. The checker prevents overlaps **within this cluster**, but it cannot discover overlaps with your corporate VPN, VNet peering, on-premises, other clusters or cross-cloud networks. Coordinate that allocation before provisioning.

## 6. Optional changes: storage and demo

The storage **definitions** can be installed without allocating any volumes. Storage generally becomes billable when a claim is bound and Azure creates the disk or file share.

```bash
# Request disk for a future PostgreSQL StatefulSet, no database deployed:
./scripts/lab.sh platform --postgres-pvc --postgres-size 20Gi

# Also request shared files for Keycloak-managed assets (not user data):
./scripts/lab.sh platform --keycloak-pvc --keycloak-size 5Gi

# Optional internal HTTP routing demo:
./scripts/lab.sh platform --demo
```

Azure Disk with `ReadWriteOnce` suits a typical single PostgreSQL instance, but a real production Postgres environment needs a database operator, backups/PITR, replica/failover design, secrets, network policy and appropriate storage performance. **Do not share one Disk PVC across a multi-replica StatefulSet.** Keycloak's accounts and realms belong in a database; its RWX Azure File PVC here is only for auxiliary shared files. **PVCs are not backups.**

After enabling the demo, check your gateway's IP:

```bash
kubectl get svc -n aks-istio-ingress
kubectl get gateway,virtualservice -n demo
kubectl get pods -n demo
```

- An **internal** Istio gateway has a private load-balancer IP; test through a machine inside the connected VNet. `curl http://PRIVATE-IP/` from the laptop outside the VNet will usually not work.
- An **external** gateway has a public entry point. Do not expose workloads until you configure TLS, DNS, allowed source IPs, authorization and network policies. When choosing external + demo you must provide `--demo-host my.example.com`. The sample demo is HTTP and is for learning only.

## 7. Important Terraform options

| Argument | Example | What it controls |
|---|---|---|
| `--name` | `aks-team-lab` | AKS cluster name |
| `--resource-group` | `rg-aks-team-lab` | Azure resource group |
| `--location` | `eastus2` | Azure region |
| `--subscription` | UUID | Azure subscription |
| `--ip-base` | `10.90` | Creates all network CIDRs |
| `--gateway` | `internal` or `external` | Istio ingress type |
| `--private-cluster` | flag | Hide the Kubernetes API on a private IP |
| `--authorized-ip-ranges` | `198.51.100.5/32` | Allow-list for **public** API (not gateway) |
| `--node-min` | `2` | Lowest system node count |
| `--node-max` | `3` | Largest system node count |
| `--vm-size` | `Standard_D2s_v5` | System node compute and cost |
| `--user-pool` | flag | Optional user app node pool (adds VM cost) |
| `--workload-node-min` | `1` | User node pool minimum |
| `--workload-node-max` | `2` | User node pool maximum |
| `--workload-vm-size` | `Standard_D2s_v5` | User app VM size |
| `--tier` | `Free` | AKS control-plane tier |
| `--zones` | `1,2,3` | Optional multi-zone placement if supported |
| `--kubernetes-version` | `1.34` | Pin an available Kubernetes version |
| `--monitoring` | flag | Enable Log Analytics (additional cost) |
| `--demo` | flag | Optional HTTP test app |
| `--postgres-pvc` | flag | Optional Postgres data disk request |
| `--keycloak-pvc` | flag | Optional shared-file request |

Run `./scripts/lab.sh help` for more examples. You can also edit `.local/settings.json` and rerun `./scripts/lab.sh configure` to regenerate tfvars; validate with `plan` before applying.

## 8. How to delete safely

```bash
# See what will change first.
./scripts/lab.sh plan

# This deliberately requires the exact cluster name.
./scripts/lab.sh destroy --confirm-destroy aks-demo
```

The script destroys the **Helm/platform** state *first*, then the **Azure/infra** state. It checks for local platform Terraform state before attempting platform destruction. With a remote backend, inspect and destroy the platform stage manually if needed. **Never** delete a database cluster without first testing your backup restoration. `Retain` storage classes can intentionally leave Azure disks/shares/PVs behind after a claim or cluster is deleted; these may continue to cost money. Check Azure managed disks, storage shares and persistent volumes manually afterward. `--yes` suppresses Terraform's prompts, but not the exact-name delete guard.

## 9. Deep explanations and line-by-line learning

- [01: Terraform, configuration and execution](docs/01-terraform-and-cli.md)
- [02: Networking, AKS and Istio](docs/02-network-aks-istio.md)
- [03: Remote state and security](docs/03-state-and-security.md)
- [04: Persistent volumes for Postgres and Keycloak](docs/04-storage-services.md)
- [05: Troubleshooting](docs/05-troubleshooting.md)
- [Official sources](docs/references.md)
- [Migration from the Bash version](MIGRATION.md)

## 10. Scope and limitations

The design uses the Microsoft-supported AKS Istio add-on (`service_mesh_profile`) rather than attempting to install Istio itself with a third-party Helm chart. The Helm chart creates **Gateway** and **VirtualService** objects for a demo, not the Istio gateway's Azure LoadBalancer. It does **not** install PostgreSQL, Keycloak, TLS certificates, private DNS, a jump host, an application firewall, production network policies, secret management or a backup system. It uses one small system node pool by default for lab simplicity; use `--user-pool` for an optional application node pool. This adds VM charges.

The operator is granted the **Azure Kubernetes Service RBAC Cluster Admin** role for convenience in a lab. Use Entra groups and least-privilege roles for production. The AKS API is public by default even though the *Istio ingress* is internal; restrict public API IPs or choose a private cluster when the network design allows it. Upgrading the AKS version does **not** automatically ensure the Istio add-on revision is current; plan Istio revision upgrades separately.

**Testing status:** local Python and shell tests can run without Azure; Terraform `fmt`, `init`, `validate`, Helm renders and real deployment must run on a workstation/CI host with the tools and access installed. No real Azure deployment is claimed here.
